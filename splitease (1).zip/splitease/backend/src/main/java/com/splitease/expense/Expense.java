package com.splitease.expense;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

@Entity @Table(name = "expenses") @Getter @Setter @NoArgsConstructor
public class Expense {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "group_id", nullable = false) private Long groupId;
    @Column(nullable = false) private String title;
    private String description;
    private String notes;
    @Column(name = "total_amount", nullable = false, precision = 19, scale = 2) private BigDecimal totalAmount;
    @Column(name = "payer_id", nullable = false) private Long payerId;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private ExpenseEnums.Category category;
    @Enumerated(EnumType.STRING) @Column(name = "split_method", nullable = false) private SplitMethod splitMethod;
    @Column(name = "expense_date", nullable = false) private LocalDate expenseDate;
    @Column(name = "created_by", nullable = false) private Long createdBy;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private ExpenseStatus status = ExpenseStatus.ACTIVE;
    @Column(name = "created_at", nullable = false) private Instant createdAt = Instant.now();
    @Column(name = "updated_at", nullable = false) private Instant updatedAt = Instant.now();
    @PreUpdate void touch() { updatedAt = Instant.now(); }
}
