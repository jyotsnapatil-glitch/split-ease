package com.splitease.activity;

import com.splitease.common.PageResponse;
import com.splitease.expense.*;
import com.splitease.group.*;
import com.splitease.settlement.Settlement;
import com.splitease.settlement.SettlementRepository;
import com.splitease.user.UserNames;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.*;

/** Unified expense + settlement history with search, filters and pagination. */
@Service
public class TransactionService {
    public record TransactionDto(String type, Long id, Long groupId, String groupName, String currency, String title, String category,
                                 BigDecimal amount, LocalDate date, String status, String actorName, Instant createdAt) {}

    private final GroupMemberRepository members;
    private final ExpenseGroupRepository groups;
    private final ExpenseRepository expenses;
    private final SettlementRepository settlements;
    private final UserNames names;

    public TransactionService(GroupMemberRepository members, ExpenseGroupRepository groups, ExpenseRepository expenses, SettlementRepository settlements, UserNames names) {
        this.members = members; this.groups = groups; this.expenses = expenses; this.settlements = settlements; this.names = names;
    }

    @Transactional(readOnly = true)
    public PageResponse<TransactionDto> search(Long userId, String q, LocalDate from, LocalDate to, String category, Long groupId, String type, int page, int size) {
        return PageResponse.of(all(userId, q, from, to, category, groupId, type), page, size);
    }

    @Transactional(readOnly = true)
    public List<TransactionDto> all(Long userId, String q, LocalDate from, LocalDate to, String category, Long groupId, String type) {
        List<Long> gids = new ArrayList<>(members.findByUserIdAndStatus(userId, GroupEnums.MemberStatus.ACTIVE).stream().map(GroupMember::getGroupId).toList());
        if (groupId != null) gids.retainAll(List.of(groupId));
        if (gids.isEmpty()) return List.of();
        LocalDate f = from == null ? LocalDate.of(1970, 1, 1) : from, t = to == null ? LocalDate.of(2999, 12, 31) : to;
        String needle = q == null ? "" : q.trim().toLowerCase();
        Map<Long, ExpenseGroup> gmap = new HashMap<>();
        groups.findAllById(gids).forEach(g -> gmap.put(g.getId(), g));
        List<TransactionDto> out = new ArrayList<>();

        if (type == null || type.isBlank() || type.equalsIgnoreCase("EXPENSE")) {
            List<Expense> es = expenses.findActiveForGroups(gids, f, t);
            Map<Long, String> n = names.of(es.stream().map(Expense::getPayerId).toList());
            for (Expense e : es) {
                if (!needle.isEmpty() && !e.getTitle().toLowerCase().contains(needle)) continue;
                if (category != null && !category.isBlank() && !e.getCategory().name().equalsIgnoreCase(category)) continue;
                ExpenseGroup g = gmap.get(e.getGroupId());
                out.add(new TransactionDto("EXPENSE", e.getId(), g.getId(), g.getName(), g.getCurrency(), e.getTitle(), e.getCategory().name(),
                        e.getTotalAmount(), e.getExpenseDate(), e.getStatus().name(), "Paid by " + n.get(e.getPayerId()), e.getCreatedAt()));
            }
        }
        if ((type == null || type.isBlank() || type.equalsIgnoreCase("SETTLEMENT")) && (category == null || category.isBlank())) {
            List<Settlement> ss = settlements.findByGroupIdInOrderByCreatedAtDesc(gids);
            Set<Long> ids = new HashSet<>();
            ss.forEach(s -> { ids.add(s.getPayerId()); ids.add(s.getReceiverId()); });
            Map<Long, String> n = names.of(ids);
            for (Settlement s : ss) {
                if (s.getSettlementDate().isBefore(f) || s.getSettlementDate().isAfter(t)) continue;
                String title = n.get(s.getPayerId()) + " paid " + n.get(s.getReceiverId());
                if (!needle.isEmpty() && !title.toLowerCase().contains(needle)) continue;
                ExpenseGroup g = gmap.get(s.getGroupId());
                out.add(new TransactionDto("SETTLEMENT", s.getId(), g.getId(), g.getName(), g.getCurrency(), title, s.getPaymentMethod().name(),
                        s.getAmount(), s.getSettlementDate(), s.getStatus().name(), s.getPaymentMethod().name(), s.getCreatedAt()));
            }
        }
        out.sort(Comparator.comparing(TransactionDto::date).thenComparing(TransactionDto::createdAt).reversed());
        return out;
    }
}
