package com.splitease.settlement;

import com.splitease.balance.Transfer;

import java.math.BigDecimal;
import java.util.*;

/**
 * Greedy debtor/creditor matching. Deterministic: largest balances first, ties broken by userId.
 * Produces at most (n - 1) transfers and preserves total owed == total receivable.
 * The output is a SUGGESTION only; no money moves until a settlement is recorded and confirmed.
 */
public final class SettlementOptimizer {

    private SettlementOptimizer() {}

    public static List<Transfer> suggest(Map<Long, BigDecimal> net) {
        List<Map.Entry<Long, BigDecimal>> debtors = new ArrayList<>();
        List<Map.Entry<Long, BigDecimal>> creditors = new ArrayList<>();
        for (Map.Entry<Long, BigDecimal> e : net.entrySet()) {
            if (e.getValue().signum() < 0) debtors.add(new AbstractMap.SimpleEntry<>(e.getKey(), e.getValue().negate()));
            else if (e.getValue().signum() > 0) creditors.add(new AbstractMap.SimpleEntry<>(e.getKey(), e.getValue()));
        }
        Comparator<Map.Entry<Long, BigDecimal>> cmp = (a, b) -> {
            int c = b.getValue().compareTo(a.getValue());
            return c != 0 ? c : Long.compare(a.getKey(), b.getKey());
        };
        debtors.sort(cmp);
        creditors.sort(cmp);

        List<Transfer> out = new ArrayList<>();
        int d = 0, c = 0;
        while (d < debtors.size() && c < creditors.size()) {
            Map.Entry<Long, BigDecimal> debtor = debtors.get(d), creditor = creditors.get(c);
            BigDecimal amount = debtor.getValue().min(creditor.getValue());
            out.add(new Transfer(debtor.getKey(), creditor.getKey(), amount));
            debtor.setValue(debtor.getValue().subtract(amount));
            creditor.setValue(creditor.getValue().subtract(amount));
            if (debtor.getValue().signum() == 0) d++;
            if (creditor.getValue().signum() == 0) c++;
        }
        return out;
    }
}
