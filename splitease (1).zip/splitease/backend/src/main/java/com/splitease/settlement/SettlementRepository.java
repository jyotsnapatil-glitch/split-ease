package com.splitease.settlement;

import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface SettlementRepository extends JpaRepository<Settlement, Long> {
    List<Settlement> findByGroupIdAndStatus(Long groupId, SettlementEnums.Status status);
    List<Settlement> findByGroupIdOrderByCreatedAtDesc(Long groupId);
    List<Settlement> findByGroupIdInOrderByCreatedAtDesc(Collection<Long> groupIds);

    /** Row lock: two simultaneous confirmations serialize, the second sees CONFIRMED and gets 409. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select s from Settlement s where s.id = :id")
    Optional<Settlement> findForUpdate(@Param("id") Long id);
}
