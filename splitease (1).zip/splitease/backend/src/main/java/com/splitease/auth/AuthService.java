package com.splitease.auth;

import com.splitease.common.ApiException;
import com.splitease.user.User;
import com.splitease.user.UserDto;
import com.splitease.user.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {
    private final UserRepository users;
    private final PasswordEncoder encoder;
    public AuthService(UserRepository users, PasswordEncoder encoder) { this.users = users; this.encoder = encoder; }

    @Transactional
    public User register(AuthDtos.RegisterRequest r) {
        if (!r.password().equals(r.confirmPassword())) throw ApiException.badRequest("Passwords do not match");
        String email = r.email().trim().toLowerCase();
        if (users.existsByEmailIgnoreCase(email)) throw ApiException.conflict("An account with this email already exists");
        User u = new User();
        u.setFullName(r.fullName().trim()); u.setEmail(email); u.setPasswordHash(encoder.encode(r.password()));
        try { return users.saveAndFlush(u); }
        catch (org.springframework.dao.DataIntegrityViolationException e) { throw ApiException.conflict("An account with this email already exists"); }
    }

    @Transactional(readOnly = true)
    public User login(AuthDtos.LoginRequest r) {
        User u = users.findByEmailIgnoreCase(r.email().trim()).orElse(null);
        // same message for unknown email / wrong password / suspended: no account enumeration
        if (u == null || !encoder.matches(r.password(), u.getPasswordHash()) || u.getStatus() != User.Status.ACTIVE)
            throw new ApiException(HttpStatus.UNAUTHORIZED, "Invalid email or password");
        return u;
    }
}
