package com.splitease.analytics;

import com.splitease.expense.ExpenseEnums;

import java.math.BigDecimal;
import java.time.LocalDate;

/** One participant share of one active expense, used for personal analytics. */
public record ShareRow(Long groupId, String groupName, ExpenseEnums.Category category, LocalDate expenseDate, BigDecimal share) {}
