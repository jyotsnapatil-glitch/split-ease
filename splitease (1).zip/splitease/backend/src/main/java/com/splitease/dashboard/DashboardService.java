package com.splitease.dashboard;

import com.splitease.activity.TransactionService;
import com.splitease.analytics.AnalyticsService;
import com.splitease.expense.ExpenseRepository;
import com.splitease.group.GroupDtos;
import com.splitease.group.GroupService;
import com.splitease.settlement.SettlementDtos;
import com.splitease.settlement.SettlementEnums;
import com.splitease.settlement.SettlementService;
import com.splitease.user.User;
import com.splitease.user.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class DashboardService {
    public record Unsettled(Long groupId, String groupName, String currency, BigDecimal net) {}
    public record Dashboard(String currency, BigDecimal totalPaid, BigDecimal totalOwed, BigDecimal owedToMe, BigDecimal netBalance,
                            int otherCurrencyGroups, List<TransactionService.TransactionDto> recent, List<GroupDtos.GroupSummary> groups,
                            List<Unsettled> unsettled, List<SettlementDtos.SettlementDto> pendingSettlements,
                            List<AnalyticsService.MonthlyPoint> monthly, List<AnalyticsService.CategoryPoint> categories) {}

    private final GroupService groups;
    private final ExpenseRepository expenses;
    private final UserRepository users;
    private final TransactionService transactions;
    private final SettlementService settlements;
    private final AnalyticsService analytics;

    public DashboardService(GroupService groups, ExpenseRepository expenses, UserRepository users, TransactionService transactions,
                            SettlementService settlements, AnalyticsService analytics) {
        this.groups = groups; this.expenses = expenses; this.users = users; this.transactions = transactions; this.settlements = settlements; this.analytics = analytics;
    }

    /** Totals only include groups in the user's preferred currency; there is no FX conversion, so mixing would be wrong. */
    @Transactional(readOnly = true)
    public Dashboard build(Long uid) {
        User me = users.findById(uid).orElseThrow();
        String cur = me.getPreferredCurrency();
        List<GroupDtos.GroupSummary> all = groups.list(uid);
        List<GroupDtos.GroupSummary> same = all.stream().filter(g -> g.currency().equals(cur)).toList();
        BigDecimal owed = same.stream().map(GroupDtos.GroupSummary::myBalance).filter(b -> b.signum() < 0).map(BigDecimal::negate).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal toMe = same.stream().map(GroupDtos.GroupSummary::myBalance).filter(b -> b.signum() > 0).reduce(BigDecimal.ZERO, BigDecimal::add);
        List<Unsettled> unsettled = all.stream().filter(g -> g.myBalance().signum() != 0)
                .map(g -> new Unsettled(g.id(), g.name(), g.currency(), g.myBalance())).toList();
        var pending = settlements.listForUser(uid).stream().filter(s -> s.status() == SettlementEnums.Status.PENDING).limit(5).toList();
        var recent = transactions.all(uid, null, null, null, null, null, null).stream().limit(5).toList();
        return new Dashboard(cur, expenses.sumPaidBy(uid, cur), owed, toMe, toMe.subtract(owed), all.size() - same.size(), recent, all, unsettled, pending,
                analytics.monthly(uid, 6), analytics.categories(uid));
    }
}
