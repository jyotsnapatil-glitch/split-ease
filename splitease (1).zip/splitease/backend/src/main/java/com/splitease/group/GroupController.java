package com.splitease.group;

import com.splitease.balance.BalanceService;
import com.splitease.security.CurrentUser;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController @RequestMapping("/api/groups")
public class GroupController {
    private final GroupService groups;
    private final BalanceService balances;
    public GroupController(GroupService groups, BalanceService balances) { this.groups = groups; this.balances = balances; }

    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public GroupDtos.GroupDetail create(@Valid @RequestBody GroupDtos.CreateGroup r) { return groups.create(CurrentUser.id(), r); }

    @GetMapping public List<GroupDtos.GroupSummary> list() { return groups.list(CurrentUser.id()); }

    @GetMapping("/{id}") public GroupDtos.GroupDetail get(@PathVariable Long id) { return groups.detail(id, CurrentUser.id()); }

    @PutMapping("/{id}") public GroupDtos.GroupDetail update(@PathVariable Long id, @Valid @RequestBody GroupDtos.UpdateGroup r) { return groups.update(id, CurrentUser.id(), r); }

    @PostMapping("/{id}/members") @ResponseStatus(HttpStatus.CREATED)
    public GroupDtos.GroupDetail addMember(@PathVariable Long id, @Valid @RequestBody GroupDtos.AddMember r) { return groups.addMember(id, CurrentUser.id(), r); }

    @PostMapping("/{id}/leave") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void leave(@PathVariable Long id) { groups.leave(id, CurrentUser.id()); }

    @GetMapping("/{id}/balances")
    public BalanceService.GroupBalances balances(@PathVariable Long id) { return balances.balances(id, CurrentUser.id()); }

    /** Suggestions only: nothing here moves money. */
    @GetMapping("/{id}/settlement-suggestions")
    public List<BalanceService.SuggestedTransfer> suggestions(@PathVariable Long id) { return balances.balances(id, CurrentUser.id()).suggestions(); }
}
