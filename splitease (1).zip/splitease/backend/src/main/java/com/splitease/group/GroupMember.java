package com.splitease.group;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@Entity @Table(name = "group_members") @Getter @Setter @NoArgsConstructor
public class GroupMember {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "group_id", nullable = false) private Long groupId;
    @Column(name = "user_id", nullable = false) private Long userId;
    @Enumerated(EnumType.STRING) @Column(name = "membership_role", nullable = false) private GroupEnums.MembershipRole membershipRole = GroupEnums.MembershipRole.MEMBER;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private GroupEnums.MemberStatus status = GroupEnums.MemberStatus.ACTIVE;
    @Column(name = "joined_at", nullable = false) private Instant joinedAt = Instant.now();

    public boolean isAdmin() { return membershipRole != GroupEnums.MembershipRole.MEMBER; }
}
