package com.splitease.user;

import com.splitease.common.ApiException;
import com.splitease.common.Currencies;
import com.splitease.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/users/me")
public class UserController {
    public record UpdateProfile(@NotBlank @Size(max = 100) String fullName, @NotBlank String preferredCurrency) {}
    public record Onboarding(@NotBlank @Size(max = 100) String displayName, @NotBlank String currency) {}
    public record ChangePassword(@NotBlank String currentPassword,
                                 @NotBlank @Size(min = 8, max = 72) @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d).+$", message = "Password needs at least one letter and one number") String newPassword) {}

    private final UserRepository users;
    private final PasswordEncoder encoder;
    public UserController(UserRepository users, PasswordEncoder encoder) { this.users = users; this.encoder = encoder; }

    private User me() { return users.findById(CurrentUser.id()).orElseThrow(() -> ApiException.notFound("User not found")); }

    @GetMapping public UserDto get() { return UserDto.from(me()); }

    /** Only changes the user's display currency; existing group currencies are never rewritten. */
    @PutMapping @Transactional
    public UserDto update(@Valid @RequestBody UpdateProfile r) {
        User u = me();
        u.setFullName(r.fullName().trim()); u.setPreferredCurrency(Currencies.require(r.preferredCurrency()));
        return UserDto.from(users.save(u));
    }

    @PostMapping("/onboarding") @Transactional
    public UserDto onboarding(@Valid @RequestBody Onboarding r) {
        User u = me();
        u.setFullName(r.displayName().trim()); u.setPreferredCurrency(Currencies.require(r.currency())); u.setOnboarded(true);
        return UserDto.from(users.save(u));
    }

    /** Bumping tokenVersion revokes every previously issued JWT (all other devices are signed out). */
    @PostMapping("/password") @ResponseStatus(HttpStatus.NO_CONTENT) @Transactional
    public void changePassword(@Valid @RequestBody ChangePassword r, jakarta.servlet.http.HttpServletResponse res) {
        User u = me();
        if (!encoder.matches(r.currentPassword(), u.getPasswordHash())) throw ApiException.badRequest("Current password is incorrect");
        u.setPasswordHash(encoder.encode(r.newPassword()));
        u.setTokenVersion(u.getTokenVersion() + 1);
        users.save(u);
        res.addHeader("Clear-Site-Data", "\"cookies\"");
    }
}
