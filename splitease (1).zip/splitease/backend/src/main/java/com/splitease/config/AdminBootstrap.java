package com.splitease.config;

import com.splitease.user.User;
import com.splitease.user.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/** Creates the first admin from ADMIN_EMAIL / ADMIN_PASSWORD env vars. Nothing is hardcoded; skipped when unset. The password is never logged. */
@Component
public class AdminBootstrap implements ApplicationRunner {
    private static final Logger log = LoggerFactory.getLogger(AdminBootstrap.class);
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final String email, password, name;

    public AdminBootstrap(UserRepository users, PasswordEncoder encoder, @Value("${app.admin.email:}") String email,
                          @Value("${app.admin.password:}") String password, @Value("${app.admin.name:Admin}") String name) {
        this.users = users; this.encoder = encoder; this.email = email; this.password = password; this.name = name;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (email.isBlank() || password.isBlank()) return;
        if (password.length() < 12) { log.warn("ADMIN_PASSWORD is shorter than 12 characters; admin bootstrap skipped"); return; }
        if (users.existsByEmailIgnoreCase(email)) return;
        User u = new User();
        u.setFullName(name); u.setEmail(email.trim().toLowerCase()); u.setPasswordHash(encoder.encode(password)); u.setRole(User.Role.ADMIN); u.setOnboarded(true);
        users.save(u);
        log.info("Bootstrapped admin account {}", u.getEmail());
    }
}
