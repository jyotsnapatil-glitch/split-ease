package com.splitease.expense;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

public final class ExpenseDtos {
    private ExpenseDtos() {}

    /** value = exact amount (EXACT), percentage (PERCENTAGE) or share units (SHARES); ignored for EQUAL. */
    public record ParticipantInput(@NotNull Long userId, BigDecimal value) {}

    public record ExpenseRequest(
            @NotBlank @Size(max = 120) String title, @Size(max = 500) String description, @Size(max = 1000) String notes,
            @NotNull @DecimalMin(value = "0.01", message = "Amount must be positive") @Digits(integer = 15, fraction = 2) BigDecimal amount,
            @NotNull Long paidBy, @NotNull ExpenseEnums.Category category, @NotNull LocalDate date,
            @NotNull SplitMethod splitMethod, @NotEmpty List<@Valid ParticipantInput> participants) {}

    public record ParticipantDto(Long userId, String fullName, BigDecimal share, BigDecimal percentage, BigDecimal shareUnits) {}
    public record OwesDto(Long fromUserId, String fromName, Long toUserId, String toName, BigDecimal amount) {}

    public record ExpenseDto(Long id, Long groupId, String groupName, String title, String description, String notes, BigDecimal amount, String currency,
                             Long paidBy, String paidByName, ExpenseEnums.Category category, SplitMethod splitMethod, LocalDate date,
                             ExpenseStatus status, List<ParticipantDto> participants, List<OwesDto> owes, boolean canEdit, Instant createdAt) {}
}
