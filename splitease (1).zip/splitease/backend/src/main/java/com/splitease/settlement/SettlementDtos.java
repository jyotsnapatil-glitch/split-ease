package com.splitease.settlement;

import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

public final class SettlementDtos {
    private SettlementDtos() {}
    /** status may be PENDING (default) or CONFIRMED; CONFIRMED is only accepted when the receiver records it. */
    public record SettlementRequest(@NotNull Long payerId, @NotNull Long receiverId,
                                    @NotNull @DecimalMin(value = "0.01", message = "Amount must be positive") @Digits(integer = 15, fraction = 2) BigDecimal amount,
                                    @NotNull SettlementEnums.Method method, @NotNull LocalDate date, SettlementEnums.Status status) {}
    public record SettlementDto(Long id, Long groupId, String groupName, String currency, Long payerId, String payerName, Long receiverId, String receiverName,
                                BigDecimal amount, SettlementEnums.Method method, SettlementEnums.Status status, LocalDate date,
                                Long createdBy, Long confirmedBy, Instant createdAt, Instant confirmedAt, boolean canConfirm, boolean canReject) {}
}
