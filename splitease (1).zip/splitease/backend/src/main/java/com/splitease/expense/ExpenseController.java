package com.splitease.expense;

import com.splitease.common.PageResponse;
import com.splitease.security.CurrentUser;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api")
public class ExpenseController {
    private final ExpenseService service;
    public ExpenseController(ExpenseService s) { this.service = s; }

    @PostMapping("/groups/{groupId}/expenses") @ResponseStatus(HttpStatus.CREATED)
    public ExpenseDtos.ExpenseDto create(@PathVariable Long groupId, @Valid @RequestBody ExpenseDtos.ExpenseRequest r) { return service.create(groupId, CurrentUser.id(), r); }

    @GetMapping("/groups/{groupId}/expenses")
    public PageResponse<ExpenseDtos.ExpenseDto> list(@PathVariable Long groupId, @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "20") int size) {
        return service.list(groupId, CurrentUser.id(), Math.max(page, 0), Math.min(Math.max(size, 1), 100));
    }

    @GetMapping("/expenses/{id}") public ExpenseDtos.ExpenseDto get(@PathVariable Long id) { return service.get(id, CurrentUser.id()); }

    @PutMapping("/expenses/{id}")
    public ExpenseDtos.ExpenseDto update(@PathVariable Long id, @Valid @RequestBody ExpenseDtos.ExpenseRequest r) { return service.update(id, CurrentUser.id(), r); }

    @DeleteMapping("/expenses/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) { service.delete(id, CurrentUser.id()); }
}
