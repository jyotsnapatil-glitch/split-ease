package com.splitease.group;

import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

public final class GroupDtos {
    private GroupDtos() {}
    public record CreateGroup(@NotBlank @Size(max = 100) String name, @Size(max = 500) String description,
                              @NotNull GroupEnums.Category category, @NotBlank String currency, List<@Email String> memberEmails) {}
    public record UpdateGroup(@NotBlank @Size(max = 100) String name, @Size(max = 500) String description, @NotNull GroupEnums.Category category) {}
    public record AddMember(@NotBlank @Email String email) {}
    public record GroupSummary(Long id, String name, String description, GroupEnums.Category category, String currency, int memberCount, BigDecimal myBalance, Instant createdAt) {}
    public record MemberDto(Long userId, String fullName, String email, GroupEnums.MembershipRole role, BigDecimal balance) {}
    public record GroupDetail(Long id, String name, String description, GroupEnums.Category category, String currency,
                              GroupEnums.MembershipRole myRole, List<MemberDto> members, Instant createdAt) {}
}
