package com.splitease.expense;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

/**
 * Pure, framework-free split engine. All money is BigDecimal; allocation is done in minor units (cents)
 * with the largest-remainder method so shares ALWAYS sum exactly to the total. Ties are broken by userId,
 * which makes the result fully deterministic.
 */
public final class SplitCalculator {

    /** One participant's input. value: exact amount, percentage, or share units (ignored for EQUAL). */
    public record Input(long userId, BigDecimal value) {}

    private static final BigDecimal HUNDRED = new BigDecimal("100");

    private SplitCalculator() {}

    public static Map<Long, BigDecimal> compute(SplitMethod method, BigDecimal total, List<Input> inputs) {
        if (total == null || total.signum() <= 0) throw new IllegalArgumentException("Amount must be positive");
        if (total.stripTrailingZeros().scale() > 2) throw new IllegalArgumentException("Amount cannot have more than 2 decimal places");
        if (inputs == null || inputs.isEmpty()) throw new IllegalArgumentException("At least one participant is required");
        Set<Long> seen = new HashSet<>();
        for (Input i : inputs) if (!seen.add(i.userId())) throw new IllegalArgumentException("Duplicate participant: " + i.userId());

        long totalCents = total.movePointRight(2).setScale(0, RoundingMode.UNNECESSARY).longValueExact();
        List<Input> sorted = new ArrayList<>(inputs);
        sorted.sort(Comparator.comparingLong(Input::userId));

        return switch (method) {
            case EQUAL -> weighted(totalCents, sorted, i -> BigDecimal.ONE);
            case SHARES -> {
                for (Input i : sorted) if (i.value() == null || i.value().signum() <= 0)
                    throw new IllegalArgumentException("Share units must be positive");
                yield weighted(totalCents, sorted, Input::value);
            }
            case PERCENTAGE -> {
                BigDecimal sum = BigDecimal.ZERO;
                for (Input i : sorted) {
                    if (i.value() == null || i.value().signum() <= 0) throw new IllegalArgumentException("Percentages must be positive");
                    sum = sum.add(i.value());
                }
                if (sum.compareTo(HUNDRED) != 0) throw new IllegalArgumentException("Percentages must total 100 (got " + sum.stripTrailingZeros().toPlainString() + ")");
                yield weighted(totalCents, sorted, Input::value);
            }
            case EXACT -> {
                BigDecimal sum = BigDecimal.ZERO;
                Map<Long, BigDecimal> out = new LinkedHashMap<>();
                for (Input i : sorted) {
                    BigDecimal v = i.value();
                    if (v == null || v.signum() < 0) throw new IllegalArgumentException("Exact shares cannot be negative");
                    if (v.stripTrailingZeros().scale() > 2) throw new IllegalArgumentException("Shares cannot have more than 2 decimal places");
                    sum = sum.add(v);
                    out.put(i.userId(), v.setScale(2, RoundingMode.UNNECESSARY));
                }
                if (sum.compareTo(total) != 0) throw new IllegalArgumentException("Shares must total " + total.toPlainString() + " (got " + sum.toPlainString() + ")");
                yield out;
            }
        };
    }

    private static Map<Long, BigDecimal> weighted(long totalCents, List<Input> sorted, java.util.function.Function<Input, BigDecimal> weight) {
        BigDecimal weightSum = BigDecimal.ZERO;
        for (Input i : sorted) weightSum = weightSum.add(weight.apply(i));

        long[] floor = new long[sorted.size()];
        BigDecimal[] frac = new BigDecimal[sorted.size()];
        long allocated = 0;
        for (int k = 0; k < sorted.size(); k++) {
            BigDecimal raw = BigDecimal.valueOf(totalCents).multiply(weight.apply(sorted.get(k)))
                    .divide(weightSum, 12, RoundingMode.DOWN);
            floor[k] = raw.setScale(0, RoundingMode.DOWN).longValueExact();
            frac[k] = raw.subtract(BigDecimal.valueOf(floor[k]));
            allocated += floor[k];
        }
        long remainder = totalCents - allocated;
        Integer[] order = new Integer[sorted.size()];
        for (int k = 0; k < order.length; k++) order[k] = k;
        // largest fractional part first; ties -> lower userId first (sorted is by userId and Arrays.sort is stable)
        Arrays.sort(order, (a, b) -> frac[b].compareTo(frac[a]));
        for (int r = 0; r < remainder; r++) floor[order[r % order.length]]++;

        Map<Long, BigDecimal> out = new LinkedHashMap<>();
        for (int k = 0; k < sorted.size(); k++) out.put(sorted.get(k).userId(), BigDecimal.valueOf(floor[k], 2));
        return out;
    }
}
