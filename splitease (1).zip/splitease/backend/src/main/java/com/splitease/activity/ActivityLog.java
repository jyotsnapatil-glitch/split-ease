package com.splitease.activity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@Entity @Table(name = "activity_logs") @Getter @Setter @NoArgsConstructor
public class ActivityLog {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "actor_id", nullable = false) private Long actorId;
    @Column(name = "group_id") private Long groupId;
    @Column(name = "action_type", nullable = false) private String actionType;
    @Column(name = "entity_type", nullable = false) private String entityType;
    @Column(name = "entity_id") private Long entityId;
    @Column(nullable = false) private String summary;
    @Column(name = "created_at", nullable = false) private Instant createdAt = Instant.now();
}
