package com.splitease.settlement;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

/** A RECORD of a payment made outside the app. SplitEase never moves money. */
@Entity @Table(name = "settlements") @Getter @Setter @NoArgsConstructor
public class Settlement {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "group_id", nullable = false) private Long groupId;
    @Column(name = "payer_id", nullable = false) private Long payerId;
    @Column(name = "receiver_id", nullable = false) private Long receiverId;
    @Column(nullable = false, precision = 19, scale = 2) private BigDecimal amount;
    @Enumerated(EnumType.STRING) @Column(name = "payment_method", nullable = false) private SettlementEnums.Method paymentMethod;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private SettlementEnums.Status status = SettlementEnums.Status.PENDING;
    @Column(name = "settlement_date", nullable = false) private LocalDate settlementDate;
    @Column(name = "created_by", nullable = false) private Long createdBy;
    @Column(name = "confirmed_by") private Long confirmedBy;
    @Column(name = "created_at", nullable = false) private Instant createdAt = Instant.now();
    @Column(name = "confirmed_at") private Instant confirmedAt;
}
