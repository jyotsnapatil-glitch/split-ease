package com.splitease.expense;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;

public interface ExpenseRepository extends JpaRepository<Expense, Long> {
    Page<Expense> findByGroupIdAndStatusOrderByExpenseDateDescIdDesc(Long groupId, ExpenseStatus status, Pageable pageable);
    List<Expense> findByGroupIdAndStatus(Long groupId, ExpenseStatus status);

    @Query("select e from Expense e where e.groupId in :gids and e.status = com.splitease.expense.ExpenseStatus.ACTIVE " +
           "and e.expenseDate >= :from and e.expenseDate <= :to order by e.expenseDate desc, e.id desc")
    List<Expense> findActiveForGroups(@Param("gids") Collection<Long> gids, @Param("from") LocalDate from, @Param("to") LocalDate to);

    @Query("select coalesce(sum(e.totalAmount), 0) from Expense e, com.splitease.group.ExpenseGroup g " +
           "where e.groupId = g.id and e.payerId = :uid and e.status = com.splitease.expense.ExpenseStatus.ACTIVE and g.currency = :cur")
    BigDecimal sumPaidBy(@Param("uid") Long uid, @Param("cur") String currency);

    @Query("select count(e) from Expense e where e.status = com.splitease.expense.ExpenseStatus.ACTIVE")
    long countActive();
}
