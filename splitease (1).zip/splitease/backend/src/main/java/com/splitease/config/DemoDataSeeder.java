package com.splitease.config;

import com.splitease.expense.*;
import com.splitease.group.*;
import com.splitease.settlement.*;
import com.splitease.user.User;
import com.splitease.user.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/** Dev-only demo scenario (profile "dev" AND app.seed.enabled=true). Password comes from DEMO_PASSWORD; skipped if unset. */
@Component @Profile("dev") @ConditionalOnProperty(name = "app.seed.enabled", havingValue = "true")
public class DemoDataSeeder implements ApplicationRunner {
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final GroupService groups;
    private final ExpenseService expenseService;
    private final SettlementService settlementService;
    private final String demoPassword;

    public DemoDataSeeder(UserRepository users, PasswordEncoder encoder, GroupService groups, ExpenseService expenseService,
                          SettlementService settlementService, @Value("${DEMO_PASSWORD:}") String demoPassword) {
        this.users = users; this.encoder = encoder; this.groups = groups; this.expenseService = expenseService; this.settlementService = settlementService; this.demoPassword = demoPassword;
    }

    @Override @Transactional
    public void run(ApplicationArguments args) {
        if (demoPassword.length() < 8 || users.existsByEmailIgnoreCase("alice@demo.splitease.local")) return;
        User alice = user("Alice Demo", "alice@demo.splitease.local");
        User bob = user("Bob Demo", "bob@demo.splitease.local");
        User charlie = user("Charlie Demo", "charlie@demo.splitease.local");
        var g = groups.create(alice.getId(), new GroupDtos.CreateGroup("Goa Trip (demo)", "Sample data", GroupEnums.Category.TRIP, "INR", List.of(bob.getEmail(), charlie.getEmail())));
        var all = List.of(new ExpenseDtos.ParticipantInput(alice.getId(), null), new ExpenseDtos.ParticipantInput(bob.getId(), null), new ExpenseDtos.ParticipantInput(charlie.getId(), null));
        expenseService.create(g.id(), alice.getId(), new ExpenseDtos.ExpenseRequest("Dinner", null, null, new BigDecimal("900"), alice.getId(), ExpenseEnums.Category.FOOD, LocalDate.now(), SplitMethod.EQUAL, all));
        expenseService.create(g.id(), bob.getId(), new ExpenseDtos.ExpenseRequest("Groceries", null, null, new BigDecimal("600"), bob.getId(), ExpenseEnums.Category.GROCERIES, LocalDate.now(), SplitMethod.EQUAL, all));
        // Charlie owes 500 (net -500). He pays Alice 400, recorded as pending, then Alice (receiver) confirms.
        var s = settlementService.create(g.id(), charlie.getId(), new SettlementDtos.SettlementRequest(charlie.getId(), alice.getId(), new BigDecimal("400"), SettlementEnums.Method.UPI, LocalDate.now(), null));
        settlementService.confirm(s.id(), alice.getId());
    }

    private User user(String name, String email) {
        User u = new User(); u.setFullName(name); u.setEmail(email); u.setPasswordHash(encoder.encode(demoPassword)); u.setOnboarded(true);
        return users.save(u);
    }
}
