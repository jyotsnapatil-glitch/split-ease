package com.splitease.expense;

public enum SplitMethod { EQUAL, EXACT, PERCENTAGE, SHARES }
