package com.splitease.settlement;

import com.splitease.security.CurrentUser;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController @RequestMapping("/api")
public class SettlementController {
    private final SettlementService service;
    public SettlementController(SettlementService s) { this.service = s; }

    @PostMapping("/groups/{groupId}/settlements") @ResponseStatus(HttpStatus.CREATED)
    public SettlementDtos.SettlementDto create(@PathVariable Long groupId, @Valid @RequestBody SettlementDtos.SettlementRequest r) { return service.create(groupId, CurrentUser.id(), r); }

    @GetMapping("/groups/{groupId}/settlements")
    public List<SettlementDtos.SettlementDto> forGroup(@PathVariable Long groupId) { return service.listForGroup(groupId, CurrentUser.id()); }

    @GetMapping("/settlements") public List<SettlementDtos.SettlementDto> mine() { return service.listForUser(CurrentUser.id()); }

    @PostMapping("/settlements/{id}/confirm") public SettlementDtos.SettlementDto confirm(@PathVariable Long id) { return service.confirm(id, CurrentUser.id()); }

    @PostMapping("/settlements/{id}/reject") public SettlementDtos.SettlementDto reject(@PathVariable Long id) { return service.reject(id, CurrentUser.id()); }
}
