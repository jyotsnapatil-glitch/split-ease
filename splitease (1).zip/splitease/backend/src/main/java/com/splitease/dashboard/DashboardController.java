package com.splitease.dashboard;

import com.splitease.security.CurrentUser;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController @RequestMapping("/api/dashboard")
public class DashboardController {
    private final DashboardService service;
    public DashboardController(DashboardService s) { this.service = s; }
    @GetMapping public DashboardService.Dashboard get() { return service.build(CurrentUser.id()); }
}
