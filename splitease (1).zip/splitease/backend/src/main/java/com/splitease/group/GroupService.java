package com.splitease.group;

import com.splitease.activity.ActivityService;
import com.splitease.balance.BalanceService;
import com.splitease.common.ApiException;
import com.splitease.common.Currencies;
import com.splitease.user.User;
import com.splitease.user.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

@Service
public class GroupService {
    private final ExpenseGroupRepository groups;
    private final GroupMemberRepository members;
    private final UserRepository users;
    private final GroupAccess access;
    private final BalanceService balances;
    private final ActivityService activity;

    public GroupService(ExpenseGroupRepository groups, GroupMemberRepository members, UserRepository users,
                        GroupAccess access, BalanceService balances, ActivityService activity) {
        this.groups = groups; this.members = members; this.users = users; this.access = access; this.balances = balances; this.activity = activity;
    }

    @Transactional
    public GroupDtos.GroupDetail create(Long userId, GroupDtos.CreateGroup r) {
        // resolve every invited email first: unknown emails are rejected, never silently "invited"
        List<User> invitees = new ArrayList<>();
        List<String> unknown = new ArrayList<>();
        if (r.memberEmails() != null) for (String email : new LinkedHashSet<>(r.memberEmails())) {
            Optional<User> u = users.findByEmailIgnoreCase(email.trim());
            if (u.isEmpty()) unknown.add(email); else if (!u.get().getId().equals(userId)) invitees.add(u.get());
        }
        if (!unknown.isEmpty()) throw ApiException.badRequest("No SplitEase account found for: " + String.join(", ", unknown));

        ExpenseGroup g = new ExpenseGroup();
        g.setName(r.name().trim()); g.setDescription(r.description()); g.setCategory(r.category());
        g.setCurrency(Currencies.require(r.currency())); g.setCreatedBy(userId);
        groups.save(g);
        addMember(g.getId(), userId, GroupEnums.MembershipRole.OWNER);
        for (User u : invitees) addMember(g.getId(), u.getId(), GroupEnums.MembershipRole.MEMBER);
        activity.log(userId, g.getId(), "GROUP_CREATED", "GROUP", g.getId(), "Created group " + g.getName());
        return detail(g.getId(), userId);
    }

    private void addMember(Long groupId, Long userId, GroupEnums.MembershipRole role) {
        GroupMember m = members.findByGroupIdAndUserId(groupId, userId).orElseGet(GroupMember::new);
        m.setGroupId(groupId); m.setUserId(userId); m.setMembershipRole(role);
        m.setStatus(GroupEnums.MemberStatus.ACTIVE); m.setJoinedAt(java.time.Instant.now());
        members.save(m);
    }

    @Transactional(readOnly = true)
    public List<GroupDtos.GroupSummary> list(Long userId) {
        List<GroupDtos.GroupSummary> out = new ArrayList<>();
        for (GroupMember m : members.findByUserIdAndStatus(userId, GroupEnums.MemberStatus.ACTIVE)) {
            ExpenseGroup g = access.group(m.getGroupId());
            int count = members.findByGroupIdAndStatus(g.getId(), GroupEnums.MemberStatus.ACTIVE).size();
            BigDecimal mine = balances.net(g.getId()).getOrDefault(userId, BigDecimal.ZERO);
            out.add(new GroupDtos.GroupSummary(g.getId(), g.getName(), g.getDescription(), g.getCategory(), g.getCurrency(), count, mine, g.getCreatedAt()));
        }
        out.sort(Comparator.comparing(GroupDtos.GroupSummary::createdAt).reversed());
        return out;
    }

    @Transactional(readOnly = true)
    public GroupDtos.GroupDetail detail(Long groupId, Long userId) {
        GroupMember me = access.requireMember(groupId, userId);
        ExpenseGroup g = access.group(groupId);
        Map<Long, BigDecimal> net = balances.net(groupId);
        List<GroupDtos.MemberDto> ms = new ArrayList<>();
        for (GroupMember m : members.findByGroupIdAndStatus(groupId, GroupEnums.MemberStatus.ACTIVE)) {
            User u = users.findById(m.getUserId()).orElseThrow();
            ms.add(new GroupDtos.MemberDto(u.getId(), u.getFullName(), u.getEmail(), m.getMembershipRole(), net.getOrDefault(u.getId(), BigDecimal.ZERO)));
        }
        return new GroupDtos.GroupDetail(g.getId(), g.getName(), g.getDescription(), g.getCategory(), g.getCurrency(), me.getMembershipRole(), ms, g.getCreatedAt());
    }

    @Transactional
    public GroupDtos.GroupDetail update(Long groupId, Long userId, GroupDtos.UpdateGroup r) {
        access.requireAdmin(groupId, userId);
        ExpenseGroup g = access.group(groupId);
        g.setName(r.name().trim()); g.setDescription(r.description()); g.setCategory(r.category()); // currency is immutable by design
        groups.save(g);
        activity.log(userId, groupId, "GROUP_UPDATED", "GROUP", groupId, "Updated group details");
        return detail(groupId, userId);
    }

    @Transactional
    public GroupDtos.GroupDetail addMember(Long groupId, Long userId, GroupDtos.AddMember r) {
        access.requireAdmin(groupId, userId);
        User u = users.findByEmailIgnoreCase(r.email().trim())
                .orElseThrow(() -> ApiException.badRequest("No SplitEase account found for " + r.email()));
        if (u.getStatus() != User.Status.ACTIVE) throw ApiException.badRequest("That account is not active");
        Optional<GroupMember> existing = members.findByGroupIdAndUserId(groupId, u.getId());
        if (existing.isPresent() && existing.get().getStatus() == GroupEnums.MemberStatus.ACTIVE) throw ApiException.conflict("Already a member of this group");
        addMember(groupId, u.getId(), GroupEnums.MembershipRole.MEMBER);
        activity.log(userId, groupId, "MEMBER_ADDED", "GROUP", groupId, "Added " + u.getFullName() + " to the group");
        return detail(groupId, userId);
    }

    /** Leaving requires a zero confirmed balance so nobody can walk away from (or with) money. */
    @Transactional
    public void leave(Long groupId, Long userId) {
        GroupMember me = access.requireMember(groupId, userId);
        BigDecimal net = balances.net(groupId).getOrDefault(userId, BigDecimal.ZERO);
        if (net.signum() != 0) throw ApiException.conflict("Settle your balance of " + net.toPlainString() + " before leaving this group");
        boolean others = members.findByGroupIdAndStatus(groupId, GroupEnums.MemberStatus.ACTIVE).size() > 1;
        if (me.getMembershipRole() == GroupEnums.MembershipRole.OWNER && others) throw ApiException.conflict("Owners cannot leave while other members remain");
        me.setStatus(GroupEnums.MemberStatus.LEFT);
        members.save(me);
        activity.log(userId, groupId, "MEMBER_LEFT", "GROUP", groupId, "Left the group");
    }
}
