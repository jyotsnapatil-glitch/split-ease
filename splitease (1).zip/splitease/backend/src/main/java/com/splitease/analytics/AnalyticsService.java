package com.splitease.analytics;

import com.splitease.common.ApiException;
import com.splitease.expense.ExpenseParticipantRepository;
import com.splitease.expense.ExpenseRepository;
import com.splitease.settlement.SettlementEnums;
import com.splitease.settlement.SettlementRepository;
import com.splitease.group.GroupEnums;
import com.splitease.group.GroupMemberRepository;
import com.splitease.user.User;
import com.splitease.user.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Personal analytics, always in the user's preferred currency (groups in other currencies are excluded, never converted).
 * Aggregation runs in Java over the user's share rows: simple and correct at student/friend-group scale.
 */
@Service
public class AnalyticsService {
    public record MonthlyPoint(String month, BigDecimal amount) {}
    public record CategoryPoint(String category, BigDecimal amount) {}
    public record GroupPoint(Long groupId, String groupName, BigDecimal amount) {}
    public record Overview(String currency, BigDecimal totalPaid, BigDecimal personalSpend, BigDecimal netContribution,
                           int groups, long confirmedSettlements, long pendingSettlements) {}

    private final ExpenseParticipantRepository participants;
    private final ExpenseRepository expenses;
    private final UserRepository users;
    private final GroupMemberRepository members;
    private final SettlementRepository settlements;

    public AnalyticsService(ExpenseParticipantRepository participants, ExpenseRepository expenses, UserRepository users,
                            GroupMemberRepository members, SettlementRepository settlements) {
        this.participants = participants; this.expenses = expenses; this.users = users; this.members = members; this.settlements = settlements;
    }

    private String currency(Long uid) { return users.findById(uid).map(User::getPreferredCurrency).orElseThrow(() -> ApiException.notFound("User not found")); }

    @Transactional(readOnly = true)
    public List<MonthlyPoint> monthly(Long uid, int months) {
        Map<YearMonth, BigDecimal> m = new TreeMap<>();
        for (ShareRow r : participants.shareRows(uid, currency(uid))) m.merge(YearMonth.from(r.expenseDate()), r.share(), BigDecimal::add);
        YearMonth now = YearMonth.now();
        List<MonthlyPoint> out = new ArrayList<>();
        for (int i = months - 1; i >= 0; i--) { YearMonth ym = now.minusMonths(i); out.add(new MonthlyPoint(ym.toString(), m.getOrDefault(ym, BigDecimal.ZERO))); }
        return out;
    }

    @Transactional(readOnly = true)
    public List<CategoryPoint> categories(Long uid) {
        return participants.shareRows(uid, currency(uid)).stream()
                .collect(Collectors.groupingBy(r -> r.category().name(), Collectors.reducing(BigDecimal.ZERO, ShareRow::share, BigDecimal::add)))
                .entrySet().stream().map(e -> new CategoryPoint(e.getKey(), e.getValue()))
                .sorted(Comparator.comparing(CategoryPoint::amount).reversed()).toList();
    }

    @Transactional(readOnly = true)
    public List<GroupPoint> groups(Long uid) {
        Map<Long, GroupPoint> m = new HashMap<>();
        for (ShareRow r : participants.shareRows(uid, currency(uid)))
            m.merge(r.groupId(), new GroupPoint(r.groupId(), r.groupName(), r.share()), (a, b) -> new GroupPoint(a.groupId(), a.groupName(), a.amount().add(b.amount())));
        return m.values().stream().sorted(Comparator.comparing(GroupPoint::amount).reversed()).toList();
    }

    @Transactional(readOnly = true)
    public Overview overview(Long uid) {
        String cur = currency(uid);
        BigDecimal paid = expenses.sumPaidBy(uid, cur);
        BigDecimal spend = participants.shareRows(uid, cur).stream().map(ShareRow::share).reduce(BigDecimal.ZERO, BigDecimal::add);
        var gids = members.findByUserIdAndStatus(uid, GroupEnums.MemberStatus.ACTIVE).stream().map(m -> m.getGroupId()).toList();
        var all = gids.isEmpty() ? List.<com.splitease.settlement.Settlement>of() : settlements.findByGroupIdInOrderByCreatedAtDesc(gids);
        long confirmed = all.stream().filter(s -> s.getStatus() == SettlementEnums.Status.CONFIRMED).count();
        long pending = all.stream().filter(s -> s.getStatus() == SettlementEnums.Status.PENDING).count();
        return new Overview(cur, paid, spend, paid.subtract(spend), gids.size(), confirmed, pending);
    }
}
