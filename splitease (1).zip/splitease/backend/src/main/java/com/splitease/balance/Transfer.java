package com.splitease.balance;

import java.math.BigDecimal;

/** A directed money movement: {@code from} pays {@code to}. */
public record Transfer(long from, long to, BigDecimal amount) {}
