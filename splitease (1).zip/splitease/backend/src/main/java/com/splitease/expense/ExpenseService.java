package com.splitease.expense;

import com.splitease.activity.ActivityService;
import com.splitease.common.ApiException;
import com.splitease.common.PageResponse;
import com.splitease.group.*;
import com.splitease.user.UserNames;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

@Service
public class ExpenseService {
    private final ExpenseRepository expenses;
    private final ExpenseParticipantRepository participants;
    private final GroupAccess access;
    private final GroupMemberRepository members;
    private final ActivityService activity;
    private final UserNames names;

    public ExpenseService(ExpenseRepository expenses, ExpenseParticipantRepository participants, GroupAccess access,
                          GroupMemberRepository members, ActivityService activity, UserNames names) {
        this.expenses = expenses; this.participants = participants; this.access = access; this.members = members; this.activity = activity; this.names = names;
    }

    @Transactional
    public ExpenseDtos.ExpenseDto create(Long groupId, Long userId, ExpenseDtos.ExpenseRequest r) {
        access.requireMember(groupId, userId);
        Expense e = new Expense();
        e.setGroupId(groupId); e.setCreatedBy(userId);
        apply(e, r, groupId);
        expenses.save(e);
        saveParticipants(e, r, groupId);
        activity.log(userId, groupId, "EXPENSE_CREATED", "EXPENSE", e.getId(), "Added expense \"" + e.getTitle() + "\" (" + e.getTotalAmount() + ")");
        return toDto(e, userId);
    }

    /** Edit = replace the participant rows and update the header inside one transaction; balances are derived, so they stay correct. */
    @Transactional
    public ExpenseDtos.ExpenseDto update(Long expenseId, Long userId, ExpenseDtos.ExpenseRequest r) {
        Expense e = loadActive(expenseId);
        requireEditor(e, userId);
        apply(e, r, e.getGroupId());
        participants.deleteByExpenseId(e.getId());
        participants.flush();
        saveParticipants(e, r, e.getGroupId());
        expenses.save(e);
        activity.log(userId, e.getGroupId(), "EXPENSE_UPDATED", "EXPENSE", e.getId(), "Edited expense \"" + e.getTitle() + "\"");
        return toDto(e, userId);
    }

    /** Soft delete keeps the financial history; the balance engine ignores DELETED expenses. */
    @Transactional
    public void delete(Long expenseId, Long userId) {
        Expense e = loadActive(expenseId);
        requireEditor(e, userId);
        e.setStatus(ExpenseStatus.DELETED);
        expenses.save(e);
        activity.log(userId, e.getGroupId(), "EXPENSE_DELETED", "EXPENSE", e.getId(), "Deleted expense \"" + e.getTitle() + "\"");
    }

    @Transactional(readOnly = true)
    public ExpenseDtos.ExpenseDto get(Long expenseId, Long userId) {
        Expense e = loadActive(expenseId);
        access.requireMember(e.getGroupId(), userId);
        return toDto(e, userId);
    }

    @Transactional(readOnly = true)
    public PageResponse<ExpenseDtos.ExpenseDto> list(Long groupId, Long userId, int page, int size) {
        access.requireMember(groupId, userId);
        var p = expenses.findByGroupIdAndStatusOrderByExpenseDateDescIdDesc(groupId, ExpenseStatus.ACTIVE, PageRequest.of(page, size));
        return new PageResponse<>(p.getContent().stream().map(e -> toDto(e, userId)).toList(), page, size, p.getTotalElements(), p.getTotalPages());
    }

    // ---- helpers ----
    private Expense loadActive(Long id) {
        Expense e = expenses.findById(id).orElseThrow(() -> ApiException.notFound("Expense not found"));
        if (e.getStatus() != ExpenseStatus.ACTIVE) throw ApiException.notFound("Expense not found");
        return e;
    }

    private void requireEditor(Expense e, Long userId) {
        GroupMember m = access.requireMember(e.getGroupId(), userId);   // unrelated group -> 404
        if (!(m.isAdmin() || e.getCreatedBy().equals(userId) || e.getPayerId().equals(userId)))
            throw ApiException.forbidden("Only the creator, the payer or a group admin can change this expense");
    }

    private Set<Long> activeMemberIds(Long groupId) {
        Set<Long> ids = new HashSet<>();
        members.findByGroupIdAndStatus(groupId, GroupEnums.MemberStatus.ACTIVE).forEach(m -> ids.add(m.getUserId()));
        return ids;
    }

    private void apply(Expense e, ExpenseDtos.ExpenseRequest r, Long groupId) {
        Set<Long> active = activeMemberIds(groupId);
        if (!active.contains(r.paidBy())) throw ApiException.badRequest("The payer must be a member of this group");
        for (var p : r.participants()) if (!active.contains(p.userId())) throw ApiException.badRequest("Every participant must be a member of this group");
        e.setTitle(r.title().trim()); e.setDescription(r.description()); e.setNotes(r.notes());
        e.setTotalAmount(r.amount().setScale(2)); e.setPayerId(r.paidBy()); e.setCategory(r.category());
        e.setSplitMethod(r.splitMethod()); e.setExpenseDate(r.date());
    }

    private void saveParticipants(Expense e, ExpenseDtos.ExpenseRequest r, Long groupId) {
        var inputs = r.participants().stream().map(p -> new SplitCalculator.Input(p.userId(), p.value())).toList();
        Map<Long, BigDecimal> shares = SplitCalculator.compute(r.splitMethod(), e.getTotalAmount(), inputs); // IllegalArgumentException -> 400
        for (var in : r.participants()) {
            ExpenseParticipant p = new ExpenseParticipant();
            p.setExpenseId(e.getId()); p.setUserId(in.userId()); p.setShareAmount(shares.get(in.userId()));
            if (r.splitMethod() == SplitMethod.PERCENTAGE) p.setPercentage(in.value());
            if (r.splitMethod() == SplitMethod.SHARES) p.setShareUnits(in.value());
            participants.save(p);
        }
    }

    ExpenseDtos.ExpenseDto toDto(Expense e, Long viewerId) {
        List<ExpenseParticipant> ps = participants.findByExpenseId(e.getId());
        Set<Long> ids = new HashSet<>(); ids.add(e.getPayerId()); ps.forEach(p -> ids.add(p.getUserId()));
        Map<Long, String> n = names.of(ids);
        ExpenseGroup g = access.group(e.getGroupId());
        List<ExpenseDtos.ParticipantDto> pd = ps.stream().sorted(Comparator.comparing(ExpenseParticipant::getUserId))
                .map(p -> new ExpenseDtos.ParticipantDto(p.getUserId(), n.get(p.getUserId()), p.getShareAmount(), p.getPercentage(), p.getShareUnits())).toList();
        List<ExpenseDtos.OwesDto> owes = ps.stream().filter(p -> !p.getUserId().equals(e.getPayerId()) && p.getShareAmount().signum() > 0)
                .map(p -> new ExpenseDtos.OwesDto(p.getUserId(), n.get(p.getUserId()), e.getPayerId(), n.get(e.getPayerId()), p.getShareAmount())).toList();
        boolean canEdit = members.findByGroupIdAndUserId(e.getGroupId(), viewerId)
                .map(m -> m.getStatus() == GroupEnums.MemberStatus.ACTIVE && (m.isAdmin() || e.getCreatedBy().equals(viewerId) || e.getPayerId().equals(viewerId))).orElse(false);
        return new ExpenseDtos.ExpenseDto(e.getId(), e.getGroupId(), g.getName(), e.getTitle(), e.getDescription(), e.getNotes(), e.getTotalAmount(), g.getCurrency(),
                e.getPayerId(), n.get(e.getPayerId()), e.getCategory(), e.getSplitMethod(), e.getExpenseDate(), e.getStatus(), pd, owes, canEdit, e.getCreatedAt());
    }
}
