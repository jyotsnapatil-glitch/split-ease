package com.splitease.user;

public record UserDto(Long id, String fullName, String email, String role, String preferredCurrency, boolean onboarded) {
    public static UserDto from(User u) {
        return new UserDto(u.getId(), u.getFullName(), u.getEmail(), u.getRole().name(), u.getPreferredCurrency(), u.isOnboarded());
    }
}
