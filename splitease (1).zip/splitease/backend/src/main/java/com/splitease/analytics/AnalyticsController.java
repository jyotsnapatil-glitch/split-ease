package com.splitease.analytics;

import com.splitease.security.CurrentUser;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController @RequestMapping("/api/analytics")
public class AnalyticsController {
    private final AnalyticsService service;
    public AnalyticsController(AnalyticsService s) { this.service = s; }

    @GetMapping("/overview") public AnalyticsService.Overview overview() { return service.overview(CurrentUser.id()); }
    @GetMapping("/monthly") public List<AnalyticsService.MonthlyPoint> monthly(@RequestParam(defaultValue = "6") int months) { return service.monthly(CurrentUser.id(), Math.min(Math.max(months, 1), 24)); }
    @GetMapping("/categories") public List<AnalyticsService.CategoryPoint> categories() { return service.categories(CurrentUser.id()); }
    @GetMapping("/groups") public List<AnalyticsService.GroupPoint> groups() { return service.groups(CurrentUser.id()); }
}
