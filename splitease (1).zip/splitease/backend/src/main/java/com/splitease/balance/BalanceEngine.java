package com.splitease.balance;

import java.math.BigDecimal;
import java.util.*;

/**
 * Net balance = paid - allocated shares + confirmed settlements paid - confirmed settlements received.
 * Positive => member should receive money. Negative => member owes money.
 * Balances are always derived from financial records, never stored.
 */
public final class BalanceEngine {

    public record ExpenseRecord(long payerId, BigDecimal total, Map<Long, BigDecimal> shares) {}

    private BalanceEngine() {}

    public static Map<Long, BigDecimal> compute(Collection<Long> memberIds,
                                                Collection<ExpenseRecord> activeExpenses,
                                                Collection<Transfer> confirmedSettlements) {
        Map<Long, BigDecimal> net = new TreeMap<>();
        for (Long id : memberIds) net.put(id, BigDecimal.ZERO.setScale(2));
        for (ExpenseRecord e : activeExpenses) {
            add(net, e.payerId(), e.total());
            e.shares().forEach((user, share) -> add(net, user, share.negate()));
        }
        for (Transfer t : confirmedSettlements) {
            add(net, t.from(), t.amount());
            add(net, t.to(), t.amount().negate());
        }
        return net;
    }

    private static void add(Map<Long, BigDecimal> m, long id, BigDecimal v) {
        m.merge(id, v.setScale(2), BigDecimal::add);
    }
}
