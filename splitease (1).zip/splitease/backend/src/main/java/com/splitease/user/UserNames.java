package com.splitease.user;

import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

@Component
public class UserNames {
    private final UserRepository users;
    public UserNames(UserRepository users) { this.users = users; }
    public Map<Long, String> of(Collection<Long> ids) {
        Map<Long, String> m = new HashMap<>();
        users.findAllById(ids.stream().distinct().toList()).forEach(u -> m.put(u.getId(), u.getFullName()));
        return m;
    }
}
