package com.splitease.settlement;

import com.splitease.activity.ActivityService;
import com.splitease.balance.BalanceService;
import com.splitease.common.ApiException;
import com.splitease.group.*;
import com.splitease.user.UserNames;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;

@Service
public class SettlementService {
    private final SettlementRepository settlements;
    private final GroupAccess access;
    private final BalanceService balances;
    private final ActivityService activity;
    private final UserNames names;
    private final GroupMemberRepository members;

    public SettlementService(SettlementRepository settlements, GroupAccess access, BalanceService balances,
                             ActivityService activity, UserNames names, GroupMemberRepository members) {
        this.settlements = settlements; this.access = access; this.balances = balances; this.activity = activity; this.names = names; this.members = members;
    }

    @Transactional
    public SettlementDtos.SettlementDto create(Long groupId, Long userId, SettlementDtos.SettlementRequest r) {
        access.requireMember(groupId, userId);
        if (r.payerId().equals(r.receiverId())) throw ApiException.badRequest("Payer and receiver must be different people");
        if (!userId.equals(r.payerId()) && !userId.equals(r.receiverId())) throw ApiException.forbidden("You can only record settlements you are part of");
        access.requireMember(groupId, r.payerId());
        access.requireMember(groupId, r.receiverId());
        if (r.amount().stripTrailingZeros().scale() > 2) throw ApiException.badRequest("Amount cannot have more than 2 decimal places");
        validateOutstanding(groupId, r.payerId(), r.receiverId(), r.amount());

        SettlementEnums.Status status = r.status() == null ? SettlementEnums.Status.PENDING : r.status();
        if (status == SettlementEnums.Status.REJECTED) throw ApiException.badRequest("A new settlement cannot start as rejected");
        if (status == SettlementEnums.Status.CONFIRMED && !userId.equals(r.receiverId()))
            throw ApiException.forbidden("Only the receiver can record a settlement as already confirmed");

        Settlement s = new Settlement();
        s.setGroupId(groupId); s.setPayerId(r.payerId()); s.setReceiverId(r.receiverId()); s.setAmount(r.amount().setScale(2));
        s.setPaymentMethod(r.method()); s.setSettlementDate(r.date()); s.setCreatedBy(userId); s.setStatus(status);
        if (status == SettlementEnums.Status.CONFIRMED) { s.setConfirmedBy(userId); s.setConfirmedAt(Instant.now()); }
        settlements.save(s);
        activity.log(userId, groupId, status == SettlementEnums.Status.CONFIRMED ? "SETTLEMENT_CONFIRMED" : "SETTLEMENT_RECORDED", "SETTLEMENT", s.getId(),
                "Recorded a " + r.method() + " settlement of " + s.getAmount() + " (" + status + ")");
        return toDto(s, userId);
    }

    /** Row-locks the settlement so concurrent confirms serialize; the loser sees CONFIRMED and gets 409. */
    @Transactional
    public SettlementDtos.SettlementDto confirm(Long id, Long userId) {
        Settlement s = settlements.findForUpdate(id).orElseThrow(() -> ApiException.notFound("Settlement not found"));
        GroupMember m = access.requireMember(s.getGroupId(), userId);
        if (s.getStatus() != SettlementEnums.Status.PENDING) throw ApiException.conflict("This settlement is already " + s.getStatus().name().toLowerCase());
        if (!canConfirm(s, m, userId)) throw ApiException.forbidden("Only the receiver (or a group admin who is not the payer) can confirm this settlement");
        validateOutstanding(s.getGroupId(), s.getPayerId(), s.getReceiverId(), s.getAmount());
        s.setStatus(SettlementEnums.Status.CONFIRMED); s.setConfirmedBy(userId); s.setConfirmedAt(Instant.now());
        settlements.save(s);
        activity.log(userId, s.getGroupId(), "SETTLEMENT_CONFIRMED", "SETTLEMENT", s.getId(), "Confirmed a settlement of " + s.getAmount());
        return toDto(s, userId);
    }

    @Transactional
    public SettlementDtos.SettlementDto reject(Long id, Long userId) {
        Settlement s = settlements.findForUpdate(id).orElseThrow(() -> ApiException.notFound("Settlement not found"));
        GroupMember m = access.requireMember(s.getGroupId(), userId);
        if (s.getStatus() != SettlementEnums.Status.PENDING) throw ApiException.conflict("This settlement is already " + s.getStatus().name().toLowerCase());
        if (!(m.isAdmin() || userId.equals(s.getReceiverId()) || userId.equals(s.getPayerId()))) throw ApiException.forbidden("You cannot reject this settlement");
        s.setStatus(SettlementEnums.Status.REJECTED);
        settlements.save(s);
        activity.log(userId, s.getGroupId(), "SETTLEMENT_REJECTED", "SETTLEMENT", s.getId(), "Rejected a settlement of " + s.getAmount());
        return toDto(s, userId);
    }

    @Transactional(readOnly = true)
    public List<SettlementDtos.SettlementDto> listForGroup(Long groupId, Long userId) {
        access.requireMember(groupId, userId);
        return settlements.findByGroupIdOrderByCreatedAtDesc(groupId).stream().map(s -> toDto(s, userId)).toList();
    }

    @Transactional(readOnly = true)
    public List<SettlementDtos.SettlementDto> listForUser(Long userId) {
        List<Long> gids = members.findByUserIdAndStatus(userId, GroupEnums.MemberStatus.ACTIVE).stream().map(GroupMember::getGroupId).toList();
        if (gids.isEmpty()) return List.of();
        return settlements.findByGroupIdInOrderByCreatedAtDesc(gids).stream().map(s -> toDto(s, userId)).toList();
    }

    /** A payment is only valid against real, confirmed debt: payer must owe >= amount and receiver must be owed >= amount. */
    private void validateOutstanding(Long groupId, Long payer, Long receiver, BigDecimal amount) {
        Map<Long, BigDecimal> net = balances.net(groupId);
        BigDecimal owed = net.getOrDefault(payer, BigDecimal.ZERO).negate();
        BigDecimal due = net.getOrDefault(receiver, BigDecimal.ZERO);
        if (owed.compareTo(amount) < 0) throw ApiException.badRequest("The payer only owes " + owed.max(BigDecimal.ZERO).toPlainString() + " in this group");
        if (due.compareTo(amount) < 0) throw ApiException.badRequest("The receiver is only owed " + due.max(BigDecimal.ZERO).toPlainString() + " in this group");
    }

    private boolean canConfirm(Settlement s, GroupMember m, Long userId) {
        if (userId.equals(s.getReceiverId())) return true;
        return m.isAdmin() && !userId.equals(s.getPayerId());
    }

    SettlementDtos.SettlementDto toDto(Settlement s, Long viewer) {
        Map<Long, String> n = names.of(List.of(s.getPayerId(), s.getReceiverId()));
        ExpenseGroup g = access.group(s.getGroupId());
        GroupMember m = members.findByGroupIdAndUserId(s.getGroupId(), viewer).orElse(null);
        boolean active = m != null && m.getStatus() == GroupEnums.MemberStatus.ACTIVE;
        boolean pending = s.getStatus() == SettlementEnums.Status.PENDING;
        boolean canConfirm = active && pending && canConfirm(s, m, viewer);
        boolean canReject = active && pending && (m.isAdmin() || viewer.equals(s.getReceiverId()) || viewer.equals(s.getPayerId()));
        return new SettlementDtos.SettlementDto(s.getId(), s.getGroupId(), g.getName(), g.getCurrency(), s.getPayerId(), n.get(s.getPayerId()),
                s.getReceiverId(), n.get(s.getReceiverId()), s.getAmount(), s.getPaymentMethod(), s.getStatus(), s.getSettlementDate(),
                s.getCreatedBy(), s.getConfirmedBy(), s.getCreatedAt(), s.getConfirmedAt(), canConfirm, canReject);
    }
}
