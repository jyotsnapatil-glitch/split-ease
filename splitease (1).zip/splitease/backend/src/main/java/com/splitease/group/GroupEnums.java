package com.splitease.group;

public final class GroupEnums {
    private GroupEnums() {}
    public enum Category { TRIP, HOME, COLLEGE, COUPLE, OTHER }
    public enum MembershipRole { OWNER, ADMIN, MEMBER }
    public enum MemberStatus { ACTIVE, LEFT }
}
