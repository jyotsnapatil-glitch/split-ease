package com.splitease.common;

import java.util.Set;

public final class Currencies {
    public static final Set<String> SUPPORTED = Set.of("INR", "USD", "EUR", "GBP", "AED", "SGD", "AUD", "CAD", "JPY");
    private Currencies() {}
    public static String require(String c) {
        if (c == null || !SUPPORTED.contains(c.toUpperCase())) throw ApiException.badRequest("Unsupported currency. Use one of " + new java.util.TreeSet<>(SUPPORTED));
        return c.toUpperCase();
    }
}
