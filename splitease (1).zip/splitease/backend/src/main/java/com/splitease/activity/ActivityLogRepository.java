package com.splitease.activity;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;

public interface ActivityLogRepository extends JpaRepository<ActivityLog, Long> {
    @Query("select a from ActivityLog a where a.groupId in :gids or a.actorId = :uid order by a.createdAt desc, a.id desc")
    Page<ActivityLog> feed(@Param("gids") Collection<Long> gids, @Param("uid") Long uid, Pageable pageable);
}
