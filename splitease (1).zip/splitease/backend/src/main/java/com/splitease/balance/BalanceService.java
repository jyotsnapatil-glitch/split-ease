package com.splitease.balance;

import com.splitease.expense.*;
import com.splitease.group.*;
import com.splitease.settlement.SettlementEnums;
import com.splitease.settlement.SettlementOptimizer;
import com.splitease.settlement.SettlementRepository;
import com.splitease.user.UserNames;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class BalanceService {
    public record MemberBalance(Long userId, String fullName, BigDecimal net) {}
    public record SuggestedTransfer(Long fromUserId, String fromName, Long toUserId, String toName, BigDecimal amount) {}
    public record GroupBalances(Long groupId, String currency, List<MemberBalance> members, List<SuggestedTransfer> suggestions) {}

    private final GroupAccess access;
    private final GroupMemberRepository members;
    private final ExpenseRepository expenses;
    private final ExpenseParticipantRepository participants;
    private final SettlementRepository settlements;
    private final UserNames names;

    public BalanceService(GroupAccess access, GroupMemberRepository members, ExpenseRepository expenses,
                          ExpenseParticipantRepository participants, SettlementRepository settlements, UserNames names) {
        this.access = access; this.members = members; this.expenses = expenses; this.participants = participants;
        this.settlements = settlements; this.names = names;
    }

    /** Derived from active expenses + CONFIRMED settlements only. Deleted expenses and pending/rejected settlements are ignored. */
    @Transactional(readOnly = true)
    public Map<Long, BigDecimal> net(Long groupId) {
        List<Long> memberIds = members.findByGroupId(groupId).stream().map(GroupMember::getUserId).toList();
        List<Expense> active = expenses.findByGroupIdAndStatus(groupId, ExpenseStatus.ACTIVE);
        Map<Long, List<ExpenseParticipant>> byExpense = participants
                .findByExpenseIdIn(active.stream().map(Expense::getId).toList()).stream()
                .collect(Collectors.groupingBy(ExpenseParticipant::getExpenseId));
        List<BalanceEngine.ExpenseRecord> records = active.stream().map(e -> {
            Map<Long, BigDecimal> shares = new HashMap<>();
            byExpense.getOrDefault(e.getId(), List.of()).forEach(p -> shares.put(p.getUserId(), p.getShareAmount()));
            return new BalanceEngine.ExpenseRecord(e.getPayerId(), e.getTotalAmount(), shares);
        }).toList();
        List<Transfer> confirmed = settlements.findByGroupIdAndStatus(groupId, SettlementEnums.Status.CONFIRMED).stream()
                .map(s -> new Transfer(s.getPayerId(), s.getReceiverId(), s.getAmount())).toList();
        return BalanceEngine.compute(memberIds, records, confirmed);
    }

    @Transactional(readOnly = true)
    public GroupBalances balances(Long groupId, Long userId) {
        access.requireMember(groupId, userId);
        ExpenseGroup g = access.group(groupId);
        Map<Long, BigDecimal> net = net(groupId);
        Map<Long, String> n = names.of(net.keySet());
        List<MemberBalance> mb = net.entrySet().stream()
                .map(e -> new MemberBalance(e.getKey(), n.get(e.getKey()), e.getValue())).toList();
        List<SuggestedTransfer> sug = SettlementOptimizer.suggest(net).stream()
                .map(t -> new SuggestedTransfer(t.from(), n.get(t.from()), t.to(), n.get(t.to()), t.amount())).toList();
        return new GroupBalances(groupId, g.getCurrency(), mb, sug);
    }
}
