package com.splitease.admin;

import com.splitease.common.ApiException;
import com.splitease.common.PageResponse;
import com.splitease.expense.ExpenseRepository;
import com.splitease.group.ExpenseGroupRepository;
import com.splitease.security.CurrentUser;
import com.splitease.settlement.SettlementRepository;
import com.splitease.user.User;
import com.splitease.user.UserDto;
import com.splitease.user.UserRepository;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Map;

/** Double-gated: URL rule in SecurityConfig plus @PreAuthorize here. */
@RestController @RequestMapping("/api/admin") @PreAuthorize("hasRole('ADMIN')")
public class AdminController {
    public record AdminUser(Long id, String fullName, String email, String role, String status, Instant createdAt) {}
    public record StatusChange(@NotNull User.Status status) {}

    private final UserRepository users;
    private final ExpenseGroupRepository groups;
    private final ExpenseRepository expenses;
    private final SettlementRepository settlements;

    public AdminController(UserRepository users, ExpenseGroupRepository groups, ExpenseRepository expenses, SettlementRepository settlements) {
        this.users = users; this.groups = groups; this.expenses = expenses; this.settlements = settlements;
    }

    @GetMapping("/stats")
    public Map<String, Object> stats() {
        return Map.of("users", users.count(), "activeUsers", users.countByStatus(User.Status.ACTIVE), "suspendedUsers", users.countByStatus(User.Status.SUSPENDED),
                "groups", groups.count(), "activeExpenses", expenses.countActive(), "settlements", settlements.count());
    }

    @GetMapping("/users")
    public PageResponse<AdminUser> users(@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "20") int size) {
        var p = users.findAll(PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100), Sort.by("id")));
        return new PageResponse<>(p.getContent().stream().map(u -> new AdminUser(u.getId(), u.getFullName(), u.getEmail(), u.getRole().name(), u.getStatus().name(), u.getCreatedAt())).toList(),
                page, size, p.getTotalElements(), p.getTotalPages());
    }

    /** Suspending bumps tokenVersion, so the user's existing sessions stop working immediately. */
    @PutMapping("/users/{id}/status") @Transactional
    public UserDto setStatus(@PathVariable Long id, @Valid @RequestBody StatusChange r) {
        if (id.equals(CurrentUser.id())) throw ApiException.badRequest("You cannot change your own status");
        User u = users.findById(id).orElseThrow(() -> ApiException.notFound("User not found"));
        if (u.getRole() == User.Role.ADMIN) throw ApiException.forbidden("Admin accounts cannot be suspended here");
        u.setStatus(r.status()); u.setTokenVersion(u.getTokenVersion() + 1);
        return UserDto.from(users.save(u));
    }
}
