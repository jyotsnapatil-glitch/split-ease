package com.splitease.auth;

import com.splitease.security.JwtService;
import com.splitease.user.User;
import com.splitease.user.UserDto;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;

@RestController @RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;
    private final JwtService jwt;
    private final String cookieName, sameSite;
    private final boolean secure;

    public AuthController(AuthService auth, JwtService jwt, @Value("${app.cookie.name}") String cookieName,
                          @Value("${app.cookie.same-site}") String sameSite, @Value("${app.cookie.secure}") boolean secure) {
        this.auth = auth; this.jwt = jwt; this.cookieName = cookieName; this.sameSite = sameSite; this.secure = secure;
    }

    @PostMapping("/register") @ResponseStatus(HttpStatus.CREATED)
    public AuthDtos.AuthResponse register(@Valid @RequestBody AuthDtos.RegisterRequest r, HttpServletResponse res) {
        return respond(auth.register(r), res);
    }

    @PostMapping("/login")
    public AuthDtos.AuthResponse login(@Valid @RequestBody AuthDtos.LoginRequest r, HttpServletResponse res) {
        return respond(auth.login(r), res);
    }

    @PostMapping("/logout") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void logout(HttpServletResponse res) { setCookie(res, "", Duration.ZERO); }

    public AuthDtos.AuthResponse respond(User u, HttpServletResponse res) {
        String token = jwt.issue(u);
        setCookie(res, token, jwt.ttl());
        return new AuthDtos.AuthResponse(UserDto.from(u), token);
    }

    private void setCookie(HttpServletResponse res, String value, Duration age) {
        res.addHeader(HttpHeaders.SET_COOKIE, ResponseCookie.from(cookieName, value).httpOnly(true).secure(secure)
                .sameSite(sameSite).path("/").maxAge(age).build().toString());
    }
}
