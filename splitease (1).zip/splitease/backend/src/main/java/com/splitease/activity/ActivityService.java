package com.splitease.activity;

import com.splitease.common.PageResponse;
import com.splitease.group.GroupEnums;
import com.splitease.group.GroupMemberRepository;
import com.splitease.user.User;
import com.splitease.user.UserRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.*;

@Service
public class ActivityService {
    public record ActivityDto(Long id, Long actorId, String actorName, Long groupId, String actionType, String entityType, Long entityId, String summary, Instant createdAt) {}

    private final ActivityLogRepository logs;
    private final GroupMemberRepository members;
    private final UserRepository users;

    public ActivityService(ActivityLogRepository logs, GroupMemberRepository members, UserRepository users) {
        this.logs = logs; this.members = members; this.users = users;
    }

    /** Joins the caller's transaction so an audit row commits or rolls back with the financial change. Never log secrets here. */
    @Transactional(propagation = Propagation.MANDATORY)
    public void log(Long actorId, Long groupId, String action, String entityType, Long entityId, String summary) {
        ActivityLog l = new ActivityLog();
        l.setActorId(actorId); l.setGroupId(groupId); l.setActionType(action);
        l.setEntityType(entityType); l.setEntityId(entityId); l.setSummary(summary);
        logs.save(l);
    }

    @Transactional(readOnly = true)
    public PageResponse<ActivityDto> feed(Long userId, int page, int size) {
        List<Long> gids = new ArrayList<>(members.findByUserIdAndStatus(userId, GroupEnums.MemberStatus.ACTIVE).stream().map(m -> m.getGroupId()).toList());
        if (gids.isEmpty()) gids.add(-1L);
        var p = logs.feed(gids, userId, PageRequest.of(page, size));
        Map<Long, String> names = new HashMap<>();
        users.findAllById(p.getContent().stream().map(ActivityLog::getActorId).distinct().toList()).forEach(u -> names.put(u.getId(), u.getFullName()));
        var items = p.getContent().stream().map(a -> new ActivityDto(a.getId(), a.getActorId(), names.get(a.getActorId()), a.getGroupId(),
                a.getActionType(), a.getEntityType(), a.getEntityId(), a.getSummary(), a.getCreatedAt())).toList();
        return new PageResponse<>(items, page, size, p.getTotalElements(), p.getTotalPages());
    }
}
