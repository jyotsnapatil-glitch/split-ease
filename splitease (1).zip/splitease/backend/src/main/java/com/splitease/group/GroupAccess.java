package com.splitease.group;

import com.splitease.common.ApiException;
import org.springframework.stereotype.Component;

/** Central authorization for group-scoped data. Non-members get 404, so group ids cannot be probed (IDOR). */
@Component
public class GroupAccess {
    private final GroupMemberRepository members;
    private final ExpenseGroupRepository groups;

    public GroupAccess(GroupMemberRepository members, ExpenseGroupRepository groups) { this.members = members; this.groups = groups; }

    public GroupMember requireMember(Long groupId, Long userId) {
        return members.findByGroupIdAndUserId(groupId, userId)
                .filter(m -> m.getStatus() == GroupEnums.MemberStatus.ACTIVE)
                .orElseThrow(() -> ApiException.notFound("Group not found"));
    }

    public GroupMember requireAdmin(Long groupId, Long userId) {
        GroupMember m = requireMember(groupId, userId);
        if (!m.isAdmin()) throw ApiException.forbidden("Only group admins can do that");
        return m;
    }

    public ExpenseGroup group(Long id) { return groups.findById(id).orElseThrow(() -> ApiException.notFound("Group not found")); }
}
