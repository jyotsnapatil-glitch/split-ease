package com.splitease.activity;

import com.splitease.common.PageResponse;
import com.splitease.security.CurrentUser;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController @RequestMapping("/api/transactions")
public class TransactionController {
    private final TransactionService service;
    public TransactionController(TransactionService s) { this.service = s; }

    @GetMapping
    public PageResponse<TransactionService.TransactionDto> search(
            @RequestParam(required = false) String q,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            @RequestParam(required = false) String category, @RequestParam(required = false) Long groupId,
            @RequestParam(required = false) String type,
            @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "10") int size) {
        return service.search(CurrentUser.id(), q, from, to, category, groupId, type, Math.max(page, 0), Math.min(Math.max(size, 1), 100));
    }
}
