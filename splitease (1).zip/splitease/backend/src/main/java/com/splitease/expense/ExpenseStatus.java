package com.splitease.expense;

public enum ExpenseStatus { ACTIVE, DELETED }
