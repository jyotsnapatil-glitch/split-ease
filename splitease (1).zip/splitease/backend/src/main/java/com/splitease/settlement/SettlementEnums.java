package com.splitease.settlement;

public final class SettlementEnums {
    private SettlementEnums() {}
    public enum Status { PENDING, CONFIRMED, REJECTED }
    public enum Method { CASH, BANK_TRANSFER, UPI }
}
