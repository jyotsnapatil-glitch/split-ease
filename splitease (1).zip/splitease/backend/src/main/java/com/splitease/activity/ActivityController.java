package com.splitease.activity;

import com.splitease.common.PageResponse;
import com.splitease.security.CurrentUser;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController @RequestMapping("/api/activity")
public class ActivityController {
    private final ActivityService service;
    public ActivityController(ActivityService s) { this.service = s; }

    @GetMapping
    public PageResponse<ActivityService.ActivityDto> feed(@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "20") int size) {
        return service.feed(CurrentUser.id(), Math.max(page, 0), Math.min(Math.max(size, 1), 100));
    }
}
