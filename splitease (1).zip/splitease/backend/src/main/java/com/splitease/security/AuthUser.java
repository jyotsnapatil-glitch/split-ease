package com.splitease.security;

/** Authenticated principal placed in the SecurityContext. */
public record AuthUser(Long id, String email, String role) {}
