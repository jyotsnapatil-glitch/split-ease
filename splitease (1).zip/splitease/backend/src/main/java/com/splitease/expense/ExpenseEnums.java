package com.splitease.expense;

public final class ExpenseEnums {
    private ExpenseEnums() {}
    public enum Category { FOOD, GROCERIES, RENT, TRAVEL, TRANSPORT, SHOPPING, ENTERTAINMENT, UTILITIES, EDUCATION, OTHER }
}
