package com.splitease.security;

import com.splitease.user.User;
import com.splitease.user.UserRepository;
import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;
import java.util.Set;

/**
 * Reads the JWT from the HttpOnly cookie (or an Authorization: Bearer header for API tools like Swagger).
 * CSRF defence for cookie auth: state-changing requests must carry X-Requested-With, a custom header that
 * browsers will not attach to cross-site form posts and that triggers a CORS preflight for other origins.
 */
@Component
public class JwtAuthFilter extends OncePerRequestFilter {
    private static final Set<String> SAFE = Set.of("GET", "HEAD", "OPTIONS");
    private final JwtService jwt;
    private final UserRepository users;
    private final String cookieName;

    public JwtAuthFilter(JwtService jwt, UserRepository users, @Value("${app.cookie.name}") String cookieName) {
        this.jwt = jwt; this.users = users; this.cookieName = cookieName;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain) throws ServletException, IOException {
        String token = null;
        boolean fromCookie = false;
        String header = req.getHeader("Authorization");
        if (header != null && header.startsWith("Bearer ")) token = header.substring(7);
        else if (req.getCookies() != null) {
            for (Cookie c : req.getCookies()) if (cookieName.equals(c.getName())) { token = c.getValue(); fromCookie = true; }
        }
        if (token != null) {
            if (fromCookie && !SAFE.contains(req.getMethod()) && req.getHeader("X-Requested-With") == null) {
                res.sendError(HttpServletResponse.SC_FORBIDDEN, "Missing X-Requested-With header");
                return;
            }
            Claims claims = jwt.parse(token).orElse(null);
            if (claims != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                User u = users.findById(Long.valueOf(claims.getSubject())).orElse(null);
                Integer tv = claims.get("tv", Integer.class);
                if (u != null && u.getStatus() == User.Status.ACTIVE && tv != null && tv == u.getTokenVersion()) {
                    var auth = new UsernamePasswordAuthenticationToken(new AuthUser(u.getId(), u.getEmail(), u.getRole().name()), null,
                            List.of(new SimpleGrantedAuthority("ROLE_" + u.getRole().name())));
                    SecurityContextHolder.getContext().setAuthentication(auth);
                }
            }
        }
        chain.doFilter(req, res);
    }
}
