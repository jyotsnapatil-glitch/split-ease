package com.splitease.auth;

import com.splitease.user.UserDto;
import jakarta.validation.constraints.*;

public final class AuthDtos {
    private AuthDtos() {}

    public record RegisterRequest(
            @NotBlank @Size(max = 100) String fullName,
            @NotBlank @Email @Size(max = 190) String email,
            @NotBlank @Size(min = 8, max = 72, message = "Password must be 8-72 characters")
            @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d).+$", message = "Password needs at least one letter and one number") String password,
            @NotBlank String confirmPassword) {}

    public record LoginRequest(@NotBlank @Email String email, @NotBlank String password) {}

    /** token is returned so API tools (Swagger, Postman) can use Bearer auth; the browser app relies on the HttpOnly cookie. */
    public record AuthResponse(UserDto user, String token) {}
}
