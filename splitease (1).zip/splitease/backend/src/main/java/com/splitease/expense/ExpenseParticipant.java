package com.splitease.expense;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity @Table(name = "expense_participants") @Getter @Setter @NoArgsConstructor
public class ExpenseParticipant {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "expense_id", nullable = false) private Long expenseId;
    @Column(name = "user_id", nullable = false) private Long userId;
    @Column(name = "share_amount", nullable = false, precision = 19, scale = 2) private BigDecimal shareAmount;
    @Column(precision = 9, scale = 4) private BigDecimal percentage;
    @Column(name = "share_units", precision = 12, scale = 4) private BigDecimal shareUnits;
}
