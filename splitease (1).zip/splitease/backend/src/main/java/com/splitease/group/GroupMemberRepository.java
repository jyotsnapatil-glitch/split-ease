package com.splitease.group;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface GroupMemberRepository extends JpaRepository<GroupMember, Long> {
    Optional<GroupMember> findByGroupIdAndUserId(Long groupId, Long userId);
    List<GroupMember> findByGroupId(Long groupId);
    List<GroupMember> findByGroupIdAndStatus(Long groupId, GroupEnums.MemberStatus status);
    List<GroupMember> findByUserIdAndStatus(Long userId, GroupEnums.MemberStatus status);
}
