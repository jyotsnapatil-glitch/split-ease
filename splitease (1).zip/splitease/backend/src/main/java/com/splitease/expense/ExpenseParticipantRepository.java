package com.splitease.expense;

import com.splitease.analytics.ShareRow;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

public interface ExpenseParticipantRepository extends JpaRepository<ExpenseParticipant, Long> {
    List<ExpenseParticipant> findByExpenseId(Long expenseId);
    List<ExpenseParticipant> findByExpenseIdIn(Collection<Long> expenseIds);
    void deleteByExpenseId(Long expenseId);

    @Query("select new com.splitease.analytics.ShareRow(g.id, g.name, e.category, e.expenseDate, p.shareAmount) " +
           "from ExpenseParticipant p, Expense e, com.splitease.group.ExpenseGroup g " +
           "where p.expenseId = e.id and e.groupId = g.id and p.userId = :uid " +
           "and e.status = com.splitease.expense.ExpenseStatus.ACTIVE and g.currency = :cur")
    List<ShareRow> shareRows(@Param("uid") Long uid, @Param("cur") String currency);
}
