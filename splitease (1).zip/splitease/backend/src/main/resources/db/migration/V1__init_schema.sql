CREATE TABLE users (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL,
  password_hash VARCHAR(100) NOT NULL,
  role VARCHAR(20) NOT NULL,
  status VARCHAR(20) NOT NULL,
  preferred_currency VARCHAR(3) NOT NULL DEFAULT 'INR',
  onboarded BOOLEAN NOT NULL DEFAULT FALSE,
  token_version INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP(6) NOT NULL,
  updated_at TIMESTAMP(6) NOT NULL,
  CONSTRAINT uk_users_email UNIQUE (email)
);

CREATE TABLE expense_groups (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description VARCHAR(500),
  category VARCHAR(20) NOT NULL,
  currency VARCHAR(3) NOT NULL,
  created_by BIGINT NOT NULL,
  created_at TIMESTAMP(6) NOT NULL,
  updated_at TIMESTAMP(6) NOT NULL,
  CONSTRAINT fk_groups_creator FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE TABLE group_members (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  group_id BIGINT NOT NULL,
  user_id BIGINT NOT NULL,
  membership_role VARCHAR(20) NOT NULL,
  status VARCHAR(20) NOT NULL,
  joined_at TIMESTAMP(6) NOT NULL,
  CONSTRAINT uk_group_member UNIQUE (group_id, user_id),
  CONSTRAINT fk_gm_group FOREIGN KEY (group_id) REFERENCES expense_groups(id),
  CONSTRAINT fk_gm_user FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE INDEX idx_gm_user ON group_members(user_id, status);

CREATE TABLE expenses (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  group_id BIGINT NOT NULL,
  title VARCHAR(120) NOT NULL,
  description VARCHAR(500),
  notes VARCHAR(1000),
  total_amount DECIMAL(19,2) NOT NULL,
  payer_id BIGINT NOT NULL,
  category VARCHAR(20) NOT NULL,
  split_method VARCHAR(20) NOT NULL,
  expense_date DATE NOT NULL,
  created_by BIGINT NOT NULL,
  status VARCHAR(20) NOT NULL,
  created_at TIMESTAMP(6) NOT NULL,
  updated_at TIMESTAMP(6) NOT NULL,
  CONSTRAINT ck_expense_amount CHECK (total_amount > 0),
  CONSTRAINT fk_exp_group FOREIGN KEY (group_id) REFERENCES expense_groups(id),
  CONSTRAINT fk_exp_payer FOREIGN KEY (payer_id) REFERENCES users(id),
  CONSTRAINT fk_exp_creator FOREIGN KEY (created_by) REFERENCES users(id)
);
CREATE INDEX idx_exp_group_status_date ON expenses(group_id, status, expense_date);
CREATE INDEX idx_exp_payer ON expenses(payer_id);

CREATE TABLE expense_participants (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  expense_id BIGINT NOT NULL,
  user_id BIGINT NOT NULL,
  share_amount DECIMAL(19,2) NOT NULL,
  percentage DECIMAL(9,4),
  share_units DECIMAL(12,4),
  CONSTRAINT uk_exp_participant UNIQUE (expense_id, user_id),
  CONSTRAINT fk_ep_expense FOREIGN KEY (expense_id) REFERENCES expenses(id),
  CONSTRAINT fk_ep_user FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE INDEX idx_ep_user ON expense_participants(user_id);

CREATE TABLE settlements (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  group_id BIGINT NOT NULL,
  payer_id BIGINT NOT NULL,
  receiver_id BIGINT NOT NULL,
  amount DECIMAL(19,2) NOT NULL,
  payment_method VARCHAR(20) NOT NULL,
  status VARCHAR(20) NOT NULL,
  settlement_date DATE NOT NULL,
  created_by BIGINT NOT NULL,
  confirmed_by BIGINT,
  created_at TIMESTAMP(6) NOT NULL,
  confirmed_at TIMESTAMP(6),
  CONSTRAINT ck_settle_amount CHECK (amount > 0),
  CONSTRAINT ck_settle_parties CHECK (payer_id <> receiver_id),
  CONSTRAINT fk_set_group FOREIGN KEY (group_id) REFERENCES expense_groups(id),
  CONSTRAINT fk_set_payer FOREIGN KEY (payer_id) REFERENCES users(id),
  CONSTRAINT fk_set_receiver FOREIGN KEY (receiver_id) REFERENCES users(id)
);
CREATE INDEX idx_set_group_status ON settlements(group_id, status);
CREATE INDEX idx_set_payer ON settlements(payer_id);
CREATE INDEX idx_set_receiver ON settlements(receiver_id);

CREATE TABLE activity_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  actor_id BIGINT NOT NULL,
  group_id BIGINT,
  action_type VARCHAR(40) NOT NULL,
  entity_type VARCHAR(30) NOT NULL,
  entity_id BIGINT,
  summary VARCHAR(300) NOT NULL,
  created_at TIMESTAMP(6) NOT NULL,
  CONSTRAINT fk_log_actor FOREIGN KEY (actor_id) REFERENCES users(id)
);
CREATE INDEX idx_log_group_created ON activity_logs(group_id, created_at);
CREATE INDEX idx_log_actor ON activity_logs(actor_id);
