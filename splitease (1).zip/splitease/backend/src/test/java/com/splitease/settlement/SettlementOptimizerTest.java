package com.splitease.settlement;

import com.splitease.balance.Transfer;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import static org.junit.jupiter.api.Assertions.*;

class SettlementOptimizerTest {
    private static BigDecimal b(String s) { return new BigDecimal(s); }

    @Test void chainCollapsesToSingleTransfer() {
        // Alice owes Bob 300, Bob owes Charlie 300  =>  net: A -300, B 0, C +300
        var t = SettlementOptimizer.suggest(new TreeMap<>(Map.of(1L, b("-300.00"), 2L, b("0.00"), 3L, b("300.00"))));
        assertEquals(1, t.size());
        assertEquals(1, t.get(0).from()); assertEquals(3, t.get(0).to());
        assertEquals(0, t.get(0).amount().compareTo(b("300")));
    }
    @Test void multipleDebtorsAndCreditorsPreserveTotals() {
        var net = new TreeMap<>(Map.of(1L, b("400.00"), 2L, b("100.00"), 3L, b("-500.00")));
        var t = SettlementOptimizer.suggest(net);
        assertTrue(t.size() <= net.size() - 1);
        BigDecimal moved = t.stream().map(Transfer::amount).reduce(BigDecimal.ZERO, BigDecimal::add);
        assertEquals(0, moved.compareTo(b("500")));
    }
    @Test void zeroBalancesProduceNothing() {
        assertTrue(SettlementOptimizer.suggest(new TreeMap<>(Map.of(1L, b("0.00"), 2L, b("0.00")))).isEmpty());
    }
    @Test void applyingSuggestionsZeroesEveryBalance() {
        var net = new TreeMap<>(Map.of(1L, b("70.00"), 2L, b("-20.00"), 3L, b("-50.00"), 4L, b("0.00")));
        var work = new TreeMap<>(net);
        for (Transfer t : SettlementOptimizer.suggest(net)) {
            work.merge(t.from(), t.amount(), BigDecimal::add);
            work.merge(t.to(), t.amount().negate(), BigDecimal::add);
        }
        work.values().forEach(v -> assertEquals(0, v.signum()));
    }
}
