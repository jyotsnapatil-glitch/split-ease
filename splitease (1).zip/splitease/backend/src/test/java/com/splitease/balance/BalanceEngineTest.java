package com.splitease.balance;

import com.splitease.expense.SplitCalculator;
import com.splitease.expense.SplitMethod;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class BalanceEngineTest {
    private static BigDecimal b(String s) { return new BigDecimal(s); }
    private static SplitCalculator.Input in(long id) { return new SplitCalculator.Input(id, null); }
    private final List<Long> members = List.of(1L, 2L, 3L);

    private BalanceEngine.ExpenseRecord equal(long payer, String total) {
        return new BalanceEngine.ExpenseRecord(payer, b(total), SplitCalculator.compute(SplitMethod.EQUAL, b(total), List.of(in(1), in(2), in(3))));
    }

    @Test void singleExpenseNetPositions() {
        var net = BalanceEngine.compute(members, List.of(equal(1, "900")), List.of());
        assertEquals(0, net.get(1L).compareTo(b("600")));
        assertEquals(0, net.get(2L).compareTo(b("-300")));
        assertEquals(0, net.get(3L).compareTo(b("-300")));
    }
    @Test void multipleExpensesAndPayers() {
        var net = BalanceEngine.compute(members, List.of(equal(1, "900"), equal(2, "600")), List.of());
        assertEquals(0, net.get(1L).compareTo(b("400")));
        assertEquals(0, net.get(2L).compareTo(b("100")));
        assertEquals(0, net.get(3L).compareTo(b("-500")));
    }
    @Test void confirmedSettlementReducesDebt() {
        var net = BalanceEngine.compute(members, List.of(equal(1, "900"), equal(2, "600")), List.of(new Transfer(3, 1, b("400"))));
        assertEquals(0, net.get(1L).compareTo(b("0")));
        assertEquals(0, net.get(3L).compareTo(b("-100")));
    }
    @Test void balancesAlwaysSumToZero() {
        Map<Long, BigDecimal> net = BalanceEngine.compute(members, List.of(equal(1, "100.01"), equal(3, "77.77")), List.of(new Transfer(2, 1, b("10.10"))));
        assertEquals(0, net.values().stream().reduce(BigDecimal.ZERO, BigDecimal::add).compareTo(BigDecimal.ZERO));
    }
}
