package com.splitease.expense;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class SplitCalculatorTest {
    private static BigDecimal b(String s) { return new BigDecimal(s); }
    private static SplitCalculator.Input in(long id, String v) { return new SplitCalculator.Input(id, v == null ? null : b(v)); }
    private static BigDecimal sum(Map<Long, BigDecimal> m) { return m.values().stream().reduce(BigDecimal.ZERO, BigDecimal::add); }

    @Test void equalSplit() {
        var r = SplitCalculator.compute(SplitMethod.EQUAL, b("900"), List.of(in(1, null), in(2, null), in(3, null)));
        r.values().forEach(v -> assertEquals(0, v.compareTo(b("300"))));
    }
    @Test void equalSplitRemainderGoesToLowestIdDeterministically() {
        var r = SplitCalculator.compute(SplitMethod.EQUAL, b("100"), List.of(in(3, null), in(1, null), in(2, null)));
        assertEquals("33.34", r.get(1L).toString());
        assertEquals("33.33", r.get(2L).toString());
        assertEquals("33.33", r.get(3L).toString());
        assertEquals(0, sum(r).compareTo(b("100")));
    }
    @Test void exactSplit() {
        var r = SplitCalculator.compute(SplitMethod.EXACT, b("50"), List.of(in(1, "20"), in(2, "30")));
        assertEquals(0, r.get(2L).compareTo(b("30")));
    }
    @Test void exactSplitMustMatchTotal() {
        assertThrows(IllegalArgumentException.class, () -> SplitCalculator.compute(SplitMethod.EXACT, b("50"), List.of(in(1, "20"), in(2, "20"))));
    }
    @Test void percentageSplitSumsExactlyEvenWithAwkwardPercentages() {
        var r = SplitCalculator.compute(SplitMethod.PERCENTAGE, b("100.01"), List.of(in(1, "33.3333"), in(2, "33.3333"), in(3, "33.3334")));
        assertEquals(0, sum(r).compareTo(b("100.01")));
    }
    @Test void percentagesMustTotal100() {
        assertThrows(IllegalArgumentException.class, () -> SplitCalculator.compute(SplitMethod.PERCENTAGE, b("50"), List.of(in(1, "50"), in(2, "40"))));
    }
    @Test void sharesSplit() {
        var r = SplitCalculator.compute(SplitMethod.SHARES, b("400"), List.of(in(1, "1"), in(2, "2"), in(3, "1")));
        assertEquals(0, r.get(2L).compareTo(b("200")));
        assertEquals(0, r.get(1L).compareTo(b("100")));
    }
    @Test void rejectsNonPositiveAmountAndTooManyDecimals() {
        assertThrows(IllegalArgumentException.class, () -> SplitCalculator.compute(SplitMethod.EQUAL, b("-5"), List.of(in(1, null))));
        assertThrows(IllegalArgumentException.class, () -> SplitCalculator.compute(SplitMethod.EQUAL, b("10.005"), List.of(in(1, null))));
    }
    @Test void rejectsDuplicateParticipantsAndEmptyList() {
        assertThrows(IllegalArgumentException.class, () -> SplitCalculator.compute(SplitMethod.EQUAL, b("10"), List.of(in(1, null), in(1, null))));
        assertThrows(IllegalArgumentException.class, () -> SplitCalculator.compute(SplitMethod.EQUAL, b("10"), List.of()));
    }
}
