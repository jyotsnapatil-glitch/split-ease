package com.splitease.integration;

import com.jayway.jsonpath.JsonPath;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/** End-to-end API flow against H2 (MySQL mode) with the real Flyway migration and real security chain. */
@SpringBootTest @AutoConfigureMockMvc @ActiveProfiles("test")
class SplitEaseFlowIT {
    @Autowired MockMvc mvc;

    record Acct(long id, String email, String token) {}

    private Acct register(String name) throws Exception {
        String email = name.toLowerCase() + "-" + UUID.randomUUID().toString().substring(0, 8) + "@test.local";
        String body = mvc.perform(post("/api/auth/register").contentType(MediaType.APPLICATION_JSON)
                .content("{\"fullName\":\"" + name + "\",\"email\":\"" + email + "\",\"password\":\"Passw0rdOK\",\"confirmPassword\":\"Passw0rdOK\"}"))
                .andExpect(status().isCreated()).andReturn().getResponse().getContentAsString();
        return new Acct(((Number) JsonPath.read(body, "$.user.id")).longValue(), email, JsonPath.read(body, "$.token"));
    }

    private ResultActions send(org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder b, Acct who, String json) throws Exception {
        if (who != null) b.header("Authorization", "Bearer " + who.token());
        if (json != null) b.contentType(MediaType.APPLICATION_JSON).content(json);
        return mvc.perform(b);
    }

    private long group(Acct owner, Acct... others) throws Exception {
        StringBuilder emails = new StringBuilder();
        for (Acct o : others) emails.append(emails.length() > 0 ? "," : "").append("\"").append(o.email()).append("\"");
        String r = send(post("/api/groups"), owner, "{\"name\":\"Trip\",\"category\":\"TRIP\",\"currency\":\"INR\",\"memberEmails\":[" + emails + "]}")
                .andExpect(status().isCreated()).andReturn().getResponse().getContentAsString();
        return ((Number) JsonPath.read(r, "$.id")).longValue();
    }

    private String equalExpense(String title, String amount, long payer, long... participants) {
        StringBuilder p = new StringBuilder();
        for (long id : participants) p.append(p.length() > 0 ? "," : "").append("{\"userId\":").append(id).append("}");
        return "{\"title\":\"" + title + "\",\"amount\":" + amount + ",\"paidBy\":" + payer + ",\"category\":\"FOOD\",\"date\":\"2026-10-01\",\"splitMethod\":\"EQUAL\",\"participants\":[" + p + "]}";
    }

    private double net(Acct viewer, long groupId, long userId) throws Exception {
        String r = send(get("/api/groups/" + groupId + "/balances"), viewer, null).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        java.util.List<Number> v = JsonPath.read(r, "$.members[?(@.userId==" + userId + ")].net");
        return v.get(0).doubleValue();
    }

    // ---- authentication ----
    @Test void duplicateRegistrationAndBadLoginAreRejected() throws Exception {
        Acct a = register("Dup");
        mvc.perform(post("/api/auth/register").contentType(MediaType.APPLICATION_JSON)
                .content("{\"fullName\":\"Dup\",\"email\":\"" + a.email() + "\",\"password\":\"Passw0rdOK\",\"confirmPassword\":\"Passw0rdOK\"}")).andExpect(status().isConflict());
        mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"" + a.email() + "\",\"password\":\"wrong-pass1\"}")).andExpect(status().isUnauthorized());
    }
    @Test void protectedRoutesNeedAuthentication() throws Exception {
        mvc.perform(get("/api/groups")).andExpect(status().isUnauthorized());
        mvc.perform(get("/api/dashboard")).andExpect(status().isUnauthorized());
    }
    @Test void weakPasswordGetsFieldError() throws Exception {
        mvc.perform(post("/api/auth/register").contentType(MediaType.APPLICATION_JSON)
                .content("{\"fullName\":\"X\",\"email\":\"x@test.local\",\"password\":\"short\",\"confirmPassword\":\"short\"}"))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.fieldErrors.password").exists());
    }

    // ---- groups & authorization ----
    @Test void nonMemberCannotSeeGroupOrItsExpenses() throws Exception {
        Acct alice = register("Alice"), eve = register("Eve");
        long g = group(alice);
        send(get("/api/groups/" + g), eve, null).andExpect(status().isNotFound());
        send(get("/api/groups/" + g + "/expenses"), eve, null).andExpect(status().isNotFound());
        send(get("/api/groups/" + g + "/balances"), eve, null).andExpect(status().isNotFound());
    }
    @Test void unknownEmailIsRejectedNotFakeInvited() throws Exception {
        Acct alice = register("Alice");
        long g = group(alice);
        send(post("/api/groups/" + g + "/members"), alice, "{\"email\":\"nobody-" + UUID.randomUUID() + "@test.local\"}").andExpect(status().isBadRequest());
    }

    // ---- expenses & balances ----
    @Test void demoScenarioBalancesSuggestionsAndSettlementLifecycle() throws Exception {
        Acct alice = register("Alice"), bob = register("Bob"), charlie = register("Charlie");
        long g = group(alice, bob, charlie);

        send(post("/api/groups/" + g + "/expenses"), alice, equalExpense("Dinner", "900", alice.id(), alice.id(), bob.id(), charlie.id())).andExpect(status().isCreated());
        send(post("/api/groups/" + g + "/expenses"), bob, equalExpense("Groceries", "600", bob.id(), alice.id(), bob.id(), charlie.id())).andExpect(status().isCreated());
        assertEquals(400.0, net(alice, g, alice.id()));
        assertEquals(100.0, net(alice, g, bob.id()));
        assertEquals(-500.0, net(alice, g, charlie.id()));

        send(get("/api/groups/" + g + "/settlement-suggestions"), alice, null).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(2));

        // pending settlement must NOT change confirmed balances
        String s = send(post("/api/groups/" + g + "/settlements"), charlie,
                "{\"payerId\":" + charlie.id() + ",\"receiverId\":" + alice.id() + ",\"amount\":400,\"method\":\"UPI\",\"date\":\"2026-10-02\"}")
                .andExpect(status().isCreated()).andExpect(jsonPath("$.status").value("PENDING")).andReturn().getResponse().getContentAsString();
        long sid = ((Number) JsonPath.read(s, "$.id")).longValue();
        assertEquals(-500.0, net(alice, g, charlie.id()));

        // payer cannot confirm own payment; an unrelated user cannot either
        send(post("/api/settlements/" + sid + "/confirm"), charlie, null).andExpect(status().isForbidden());
        Acct eve = register("Eve");
        send(post("/api/settlements/" + sid + "/confirm"), eve, null).andExpect(status().isNotFound());

        // receiver confirms -> balances move; second confirm is a conflict
        send(post("/api/settlements/" + sid + "/confirm"), alice, null).andExpect(status().isOk()).andExpect(jsonPath("$.status").value("CONFIRMED"));
        send(post("/api/settlements/" + sid + "/confirm"), alice, null).andExpect(status().isConflict());
        assertEquals(0.0, net(alice, g, alice.id()));
        assertEquals(-100.0, net(alice, g, charlie.id()));
    }
    @Test void invalidSplitTotalsAreRejected() throws Exception {
        Acct alice = register("Alice"), bob = register("Bob");
        long g = group(alice, bob);
        String bad = "{\"title\":\"X\",\"amount\":100,\"paidBy\":" + alice.id() + ",\"category\":\"FOOD\",\"date\":\"2026-10-01\",\"splitMethod\":\"EXACT\","
                + "\"participants\":[{\"userId\":" + alice.id() + ",\"value\":30},{\"userId\":" + bob.id() + ",\"value\":30}]}";
        send(post("/api/groups/" + g + "/expenses"), alice, bad).andExpect(status().isBadRequest());
    }
    @Test void editAndDeleteRecalculateBalances() throws Exception {
        Acct alice = register("Alice"), bob = register("Bob");
        long g = group(alice, bob);
        String r = send(post("/api/groups/" + g + "/expenses"), alice, equalExpense("Lunch", "200", alice.id(), alice.id(), bob.id())).andExpect(status().isCreated()).andReturn().getResponse().getContentAsString();
        long eid = ((Number) JsonPath.read(r, "$.id")).longValue();
        assertEquals(100.0, net(alice, g, alice.id()));
        send(put("/api/expenses/" + eid), alice, equalExpense("Lunch", "400", alice.id(), alice.id(), bob.id())).andExpect(status().isOk());
        assertEquals(200.0, net(alice, g, alice.id()));
        send(delete("/api/expenses/" + eid), alice, null).andExpect(status().isNoContent());
        assertEquals(0.0, net(alice, g, alice.id()));
    }
    @Test void userCannotEditExpenseInUnrelatedGroup() throws Exception {
        Acct alice = register("Alice"), bob = register("Bob"), eve = register("Eve");
        long g = group(alice, bob);
        String r = send(post("/api/groups/" + g + "/expenses"), alice, equalExpense("Lunch", "200", alice.id(), alice.id(), bob.id())).andReturn().getResponse().getContentAsString();
        long eid = ((Number) JsonPath.read(r, "$.id")).longValue();
        send(put("/api/expenses/" + eid), eve, equalExpense("Hack", "1", eve.id(), eve.id())).andExpect(status().isNotFound());
        send(delete("/api/expenses/" + eid), eve, null).andExpect(status().isNotFound());
    }

    // ---- admin ----
    @Test void normalUsersCannotUseAdminEndpoints() throws Exception {
        Acct alice = register("Alice");
        send(get("/api/admin/stats"), alice, null).andExpect(status().isForbidden());
        send(get("/api/admin/users"), alice, null).andExpect(status().isForbidden());
    }
}
