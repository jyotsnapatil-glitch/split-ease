import com.splitease.expense.*; import com.splitease.balance.*; import com.splitease.settlement.*;
import java.math.BigDecimal; import java.util.*;
public class CoreCheck { static int f=0; static void ok(boolean c,String m){ if(!c){f++;System.out.println("FAIL "+m);} else System.out.println("ok   "+m);}
 static BigDecimal b(String s){return new BigDecimal(s);}
 static SplitCalculator.Input in(long u,String v){return new SplitCalculator.Input(u,v==null?null:b(v));}
 public static void main(String[] a){
  var eq=SplitCalculator.compute(SplitMethod.EQUAL,b("900"),List.of(in(1,null),in(2,null),in(3,null)));
  ok(eq.values().stream().allMatch(v->v.compareTo(b("300"))==0),"equal 900/3");
  var r=SplitCalculator.compute(SplitMethod.EQUAL,b("100"),List.of(in(3,null),in(1,null),in(2,null)));
  ok(r.get(1L).toString().equals("33.34")&&r.get(2L).toString().equals("33.33")&&r.get(3L).toString().equals("33.33"),"equal 100/3 remainder to lowest id "+r);
  ok(r.values().stream().reduce(BigDecimal.ZERO,BigDecimal::add).compareTo(b("100"))==0,"sum exact");
  var p=SplitCalculator.compute(SplitMethod.PERCENTAGE,b("100.01"),List.of(in(1,"33.3333"),in(2,"33.3333"),in(3,"33.3334")));
  ok(p.values().stream().reduce(BigDecimal.ZERO,BigDecimal::add).compareTo(b("100.01"))==0,"pct sum "+p);
  var s=SplitCalculator.compute(SplitMethod.SHARES,b("400"),List.of(in(1,"1"),in(2,"2"),in(3,"1")));
  ok(s.get(2L).compareTo(b("200"))==0&&s.get(1L).compareTo(b("100"))==0,"shares 1:2:1");
  var x=SplitCalculator.compute(SplitMethod.EXACT,b("50"),List.of(in(1,"20"),in(2,"30")));
  ok(x.get(2L).compareTo(b("30"))==0,"exact");
  List<Runnable> bads=List.of(
    ()->SplitCalculator.compute(SplitMethod.EXACT,b("50"),List.of(in(1,"20"),in(2,"20"))),
    ()->SplitCalculator.compute(SplitMethod.PERCENTAGE,b("50"),List.of(in(1,"50"),in(2,"40"))),
    ()->SplitCalculator.compute(SplitMethod.EQUAL,b("-5"),List.of(in(1,null))),
    ()->SplitCalculator.compute(SplitMethod.EQUAL,b("10.005"),List.of(in(1,null))));
  for (Runnable bad: bads) { try{bad.run();ok(false,"should throw");}catch(IllegalArgumentException e){ok(true,"rejects: "+e.getMessage());}}
  var dinner=new BalanceEngine.ExpenseRecord(1,b("900"),eq);
  var groc=new BalanceEngine.ExpenseRecord(2,b("600"),SplitCalculator.compute(SplitMethod.EQUAL,b("600"),List.of(in(1,null),in(2,null),in(3,null))));
  var net=BalanceEngine.compute(List.of(1L,2L,3L),List.of(dinner,groc),List.of());
  ok(net.get(1L).compareTo(b("400"))==0&&net.get(2L).compareTo(b("100"))==0&&net.get(3L).compareTo(b("-500"))==0,"net "+net);
  var sug=SettlementOptimizer.suggest(net);
  ok(sug.size()==2&&sug.get(0).from()==3&&sug.get(0).to()==1&&sug.get(0).amount().compareTo(b("400"))==0,"suggest "+sug);
  var net2=BalanceEngine.compute(List.of(1L,2L,3L),List.of(dinner,groc),List.of(new Transfer(3,1,b("400"))));
  ok(net2.get(3L).compareTo(b("-100"))==0&&net2.get(1L).compareTo(BigDecimal.ZERO)==0,"after settlement "+net2);
  var chain=SettlementOptimizer.suggest(new TreeMap<>(Map.of(1L,b("-300.00"),2L,b("0.00"),3L,b("300.00"))));
  ok(chain.size()==1&&chain.get(0).from()==1&&chain.get(0).to()==3,"A->C simplification");
  ok(SettlementOptimizer.suggest(new TreeMap<>(Map.of(1L,b("0.00")))).isEmpty(),"zero balance");
  System.out.println(f==0?"ALL PASS":"FAILURES "+f); System.exit(f);}}
