import { useEffect, useState } from 'react'
import { api, errMsg } from '../lib/api'
import { PayMethod } from '../lib/types'
import { today } from '../lib/format'
import { Modal, Select, Spinner, TextInput } from './ui'
import { useToast } from './Toast'

export interface Preset { payerId: number; receiverId: number; amount: number }
interface Props { open: boolean; groupId: number; currency: string; me: number; people: { userId: number; fullName: string }[]; preset?: Preset | null; onClose: () => void; onSaved: () => void }

export default function SettleModal({ open, groupId, currency, me, people, preset, onClose, onSaved }: Props) {
  const toast = useToast()
  const [payer, setPayer] = useState(''), [receiver, setReceiver] = useState(''), [amount, setAmount] = useState('')
  const [method, setMethod] = useState<PayMethod>('UPI'), [date, setDate] = useState(today()), [received, setReceived] = useState(false)
  const [err, setErr] = useState(''), [busy, setBusy] = useState(false)

  useEffect(() => {
    if (!open) return
    setErr(''); setReceived(false); setDate(today()); setMethod('UPI')
    setPayer(String(preset?.payerId ?? me)); setReceiver(String(preset?.receiverId ?? people.find((p) => p.userId !== me)?.userId ?? '')); setAmount(preset ? String(preset.amount) : '')
  }, [open, preset, me, people])

  const iAmReceiver = Number(receiver) === me
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setErr('')
    if (!/^\d+(\.\d{1,2})?$/.test(amount) || Number(amount) <= 0) { setErr('Enter a positive amount with up to 2 decimals'); return }
    if (payer === receiver) { setErr('Payer and receiver must be different'); return }
    setBusy(true)
    try {
      await api.post(`/groups/${groupId}/settlements`, { payerId: Number(payer), receiverId: Number(receiver), amount: Number(amount), method, date, status: iAmReceiver && received ? 'CONFIRMED' : 'PENDING' })
      toast.push(iAmReceiver && received ? 'Settlement recorded and confirmed' : 'Settlement recorded. Waiting for confirmation'); onSaved(); onClose()
    } catch (e2) { setErr(errMsg(e2)) } finally { setBusy(false) }
  }

  return (
    <Modal open={open} onClose={onClose} title="Record a settlement">
      <form onSubmit={submit} className="space-y-4" noValidate>
        <p className="rounded-xl bg-slate-50 p-3 text-xs text-ink-soft">SplitEase does not move money. Pay outside the app (cash, bank transfer or UPI), then record it here. Balances change only after the receiver confirms.</p>
        {err && <p role="alert" className="rounded-xl bg-rose-50 p-3 text-sm font-medium text-rose-700">{err}</p>}
        <Select label="Payer" value={payer} onChange={(e) => setPayer(e.target.value)}>{people.map((p) => <option key={p.userId} value={p.userId}>{p.fullName}</option>)}</Select>
        <Select label="Receiver" value={receiver} onChange={(e) => setReceiver(e.target.value)}>{people.map((p) => <option key={p.userId} value={p.userId}>{p.fullName}</option>)}</Select>
        <TextInput label={`Amount (${currency})`} inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} />
        <div className="grid grid-cols-2 gap-3">
          <Select label="Method" value={method} onChange={(e) => setMethod(e.target.value as PayMethod)}><option value="UPI">UPI</option><option value="BANK_TRANSFER">Bank transfer</option><option value="CASH">Cash</option></Select>
          <TextInput label="Date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>
        {iAmReceiver && <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-emerald-600" checked={received} onChange={(e) => setReceived(e.target.checked)} />I have received this payment (confirm now)</label>}
        <div className="flex justify-end gap-2"><button type="button" className="btn-ghost" onClick={onClose}>Cancel</button><button className="btn-primary" disabled={busy}>{busy && <Spinner />}Record settlement</button></div>
      </form>
    </Modal>
  )
}
