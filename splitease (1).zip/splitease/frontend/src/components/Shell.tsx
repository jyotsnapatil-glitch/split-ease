import { ReactNode, useEffect, useState } from 'react'
import { NavLink, useLocation, useNavigate } from 'react-router-dom'
import { Bell, LayoutDashboard, Users, Receipt, Scale, HandCoins, PieChart, History, Settings as Cog, Menu, X, Search, LogOut, ShieldCheck } from 'lucide-react'
import { Logo } from './Logo'
import { useAuth } from '../lib/auth'
import { api } from '../lib/api'
import { Settlement } from '../lib/types'

const NAV = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard }, { to: '/groups', label: 'My Groups', icon: Users },
  { to: '/expenses', label: 'Expenses', icon: Receipt }, { to: '/balances', label: 'Balances', icon: Scale },
  { to: '/settlements', label: 'Settlements', icon: HandCoins }, { to: '/analytics', label: 'Analytics', icon: PieChart },
  { to: '/activity', label: 'Activity', icon: History }, { to: '/settings', label: 'Settings', icon: Cog },
]

export default function Shell({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth()
  const nav = useNavigate()
  const loc = useLocation()
  const [open, setOpen] = useState(false)
  const [menu, setMenu] = useState(false)
  const [q, setQ] = useState('')
  const [pending, setPending] = useState(0)

  useEffect(() => { setOpen(false); setMenu(false) }, [loc.pathname])
  useEffect(() => {
    api.get<Settlement[]>('/settlements').then((r) => setPending(r.data.filter((s) => s.canConfirm).length)).catch(() => setPending(0))
  }, [loc.pathname])

  const items = user?.role === 'ADMIN' ? [...NAV, { to: '/admin', label: 'Admin', icon: ShieldCheck }] : NAV
  const links = (
    <nav aria-label="Main" className="flex flex-col gap-1">
      {items.map(({ to, label, icon: I }) => (
        <NavLink key={to} to={to} className={({ isActive }) => `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold ${isActive ? 'bg-mint-50 text-mint-700' : 'text-ink-soft hover:bg-slate-100'}`}>
          <I className="h-4 w-4" aria-hidden />{label}
        </NavLink>
      ))}
    </nav>
  )

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[15rem_1fr]">
      <aside className="hidden border-r border-slate-200 bg-white p-4 lg:block"><div className="mb-6 px-2"><Logo to="/dashboard" /></div>{links}</aside>
      {open && (
        <div className="fixed inset-0 z-40 bg-ink/40 lg:hidden" onClick={() => setOpen(false)}>
          <aside className="h-full w-64 bg-white p-4" onClick={(e) => e.stopPropagation()}>
            <div className="mb-6 flex items-center justify-between px-2"><Logo to="/dashboard" /><button aria-label="Close menu" onClick={() => setOpen(false)}><X className="h-5 w-5" /></button></div>{links}
          </aside>
        </div>
      )}
      <div className="min-w-0">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-slate-200 bg-white/90 px-4 py-3 backdrop-blur">
          <button className="lg:hidden" aria-label="Open menu" onClick={() => setOpen(true)}><Menu className="h-5 w-5" /></button>
          <form className="relative max-w-md flex-1" role="search" onSubmit={(e) => { e.preventDefault(); nav(`/expenses?q=${encodeURIComponent(q)}`) }}>
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" aria-hidden />
            <input className="input pl-9" placeholder="Search expenses and settlements" aria-label="Search transactions" value={q} onChange={(e) => setQ(e.target.value)} />
          </form>
          <div className="ml-auto flex items-center gap-2">
            <button className="btn-ghost relative !p-2.5" aria-label={`Notifications: ${pending} settlements waiting for you`} onClick={() => nav('/settlements')}>
              <Bell className="h-4 w-4" />{pending > 0 && <span className="absolute -right-1 -top-1 rounded-full bg-rose-600 px-1.5 text-[10px] font-bold text-white">{pending}</span>}
            </button>
            <div className="relative">
              <button className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white py-1.5 pl-1.5 pr-3 text-sm font-semibold" aria-haspopup="menu" aria-expanded={menu} onClick={() => setMenu((m) => !m)}>
                <span className="grid h-7 w-7 place-items-center rounded-lg bg-ink text-xs font-bold text-white">{user?.fullName.slice(0, 1).toUpperCase()}</span>
                <span className="hidden sm:inline">{user?.fullName.split(' ')[0]}</span>
              </button>
              {menu && (
                <div role="menu" className="card absolute right-0 mt-2 w-48 p-1">
                  <button role="menuitem" className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm hover:bg-slate-100" onClick={() => nav('/settings')}><Cog className="h-4 w-4" />Settings</button>
                  <button role="menuitem" className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm hover:bg-slate-100" onClick={async () => { await logout(); nav('/') }}><LogOut className="h-4 w-4" />Log out</button>
                </div>
              )}
            </div>
          </div>
        </header>
        <main className="mx-auto max-w-6xl p-4 sm:p-6">{children}</main>
      </div>
    </div>
  )
}
