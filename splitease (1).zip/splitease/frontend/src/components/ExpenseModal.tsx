import { useEffect, useMemo, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { api, errMsg } from '../lib/api'
import { CATEGORIES, Expense, Member, SplitMethod } from '../lib/types'
import { label, money, previewEqual, today } from '../lib/format'
import { Modal, Select, Spinner, TextInput } from './ui'
import { useToast } from './Toast'

const schema = z.object({
  title: z.string().trim().min(1, 'Give the expense a title').max(120),
  amount: z.string().refine((v) => /^\d+(\.\d{1,2})?$/.test(v) && Number(v) > 0, 'Enter a positive amount with up to 2 decimals'),
  paidBy: z.string().min(1, 'Choose who paid'),
  category: z.string().min(1),
  date: z.string().min(1, 'Choose a date'),
  splitMethod: z.enum(['EQUAL', 'EXACT', 'PERCENTAGE', 'SHARES']),
  notes: z.string().max(1000).optional(),
})
type Form = z.infer<typeof schema>

const HINT: Record<SplitMethod, string> = {
  EQUAL: 'Everyone selected pays the same.', EXACT: 'Enter each person’s amount. They must add up to the total.',
  PERCENTAGE: 'Enter each person’s percentage. They must add up to 100.', SHARES: 'Enter relative shares, for example 1, 2, 1.',
}

interface Props { open: boolean; groupId: number; members: Member[]; currency: string; initial?: Expense | null; onClose: () => void; onSaved: () => void }

export default function ExpenseModal({ open, groupId, members, currency, initial, onClose, onSaved }: Props) {
  const toast = useToast()
  const [sel, setSel] = useState<Record<number, { on: boolean; value: string }>>({})
  const [serverErr, setServerErr] = useState('')
  const { register, handleSubmit, watch, reset, formState: { errors, isSubmitting } } = useForm<Form>({
    resolver: zodResolver(schema),
    defaultValues: { title: '', amount: '', paidBy: '', category: 'FOOD', date: today(), splitMethod: 'EQUAL', notes: '' },
  })
  const method = watch('splitMethod'), amountStr = watch('amount')
  const total = Number(amountStr) || 0

  useEffect(() => {
    if (!open) return
    setServerErr('')
    const base: Record<number, { on: boolean; value: string }> = {}
    members.forEach((m) => { base[m.userId] = { on: !initial, value: '' } })
    if (initial) {
      initial.participants.forEach((p) => {
        base[p.userId] = { on: true, value: String(initial.splitMethod === 'EXACT' ? p.share : initial.splitMethod === 'PERCENTAGE' ? p.percentage ?? '' : initial.splitMethod === 'SHARES' ? p.shareUnits ?? '' : '') }
      })
      reset({ title: initial.title, amount: String(initial.amount), paidBy: String(initial.paidBy), category: initial.category, date: initial.date, splitMethod: initial.splitMethod, notes: initial.notes ?? '' })
    } else reset({ title: '', amount: '', paidBy: String(members[0]?.userId ?? ''), category: 'FOOD', date: today(), splitMethod: 'EQUAL', notes: '' })
    setSel(base)
  }, [open, initial, members, reset])

  const chosen = useMemo(() => members.filter((m) => sel[m.userId]?.on), [members, sel])
  const allocated = useMemo(() => {
    if (method === 'EQUAL') return total
    return chosen.reduce((s, m) => s + (Number(sel[m.userId]?.value) || 0), 0)
  }, [method, chosen, sel, total])
  const preview = method === 'EQUAL' && total > 0 && chosen.length ? previewEqual(total, chosen.map((m) => m.userId)) : null

  const submit = handleSubmit(async (v) => {
    setServerErr('')
    if (!chosen.length) { setServerErr('Select at least one participant'); return }
    if (method === 'EXACT' && Math.abs(allocated - total) > 0.001) { setServerErr(`Shares add up to ${money(allocated, currency)}, but the total is ${money(total, currency)}`); return }
    if (method === 'PERCENTAGE' && Math.abs(allocated - 100) > 0.0001) { setServerErr(`Percentages add up to ${allocated}%. They must total 100%`); return }
    if (method === 'SHARES' && chosen.some((m) => !(Number(sel[m.userId].value) > 0))) { setServerErr('Enter a share greater than zero for everyone selected'); return }
    const body = {
      title: v.title, notes: v.notes || undefined, amount: Number(v.amount), paidBy: Number(v.paidBy), category: v.category, date: v.date, splitMethod: v.splitMethod,
      participants: chosen.map((m) => ({ userId: m.userId, value: method === 'EQUAL' ? undefined : Number(sel[m.userId].value) })),
    }
    try {
      if (initial) await api.put(`/expenses/${initial.id}`, body); else await api.post(`/groups/${groupId}/expenses`, body)
      toast.push(initial ? 'Expense updated' : 'Expense added'); onSaved(); onClose()
    } catch (e) { setServerErr(errMsg(e)) }
  })

  return (
    <Modal open={open} onClose={onClose} title={initial ? 'Edit expense' : 'Add expense'} wide>
      <form onSubmit={submit} className="space-y-4" noValidate>
        {serverErr && <p role="alert" className="rounded-xl bg-rose-50 p-3 text-sm font-medium text-rose-700">{serverErr}</p>}
        <div className="grid gap-4 sm:grid-cols-2">
          <TextInput label="Title" placeholder="Dinner at Toit" error={errors.title?.message} {...register('title')} />
          <TextInput label={`Amount (${currency})`} inputMode="decimal" placeholder="900.00" error={errors.amount?.message} {...register('amount')} />
          <Select label="Paid by" error={errors.paidBy?.message} {...register('paidBy')}>{members.map((m) => <option key={m.userId} value={m.userId}>{m.fullName}</option>)}</Select>
          <Select label="Category" {...register('category')}>{CATEGORIES.map((c) => <option key={c} value={c}>{label(c)}</option>)}</Select>
          <TextInput label="Date" type="date" error={errors.date?.message} {...register('date')} />
          <Select label="Split method" {...register('splitMethod')}>
            <option value="EQUAL">Equally</option><option value="EXACT">Exact amounts</option><option value="PERCENTAGE">Percentages</option><option value="SHARES">Shares</option>
          </Select>
        </div>
        <fieldset>
          <legend className="label">Split between</legend>
          <p className="mb-2 text-xs text-ink-soft">{HINT[method]}</p>
          <ul className="divide-y divide-slate-100 rounded-xl border border-slate-200">
            {members.map((m) => {
              const s = sel[m.userId] ?? { on: false, value: '' }
              return (
                <li key={m.userId} className="flex items-center gap-3 px-3 py-2">
                  <input id={`p-${m.userId}`} type="checkbox" className="h-4 w-4 accent-emerald-600" checked={s.on} onChange={(e) => setSel({ ...sel, [m.userId]: { ...s, on: e.target.checked } })} />
                  <label htmlFor={`p-${m.userId}`} className="flex-1 text-sm font-medium">{m.fullName}</label>
                  {method !== 'EQUAL' && s.on && (
                    <input aria-label={`${m.fullName} ${method === 'EXACT' ? 'amount' : method === 'PERCENTAGE' ? 'percentage' : 'shares'}`} className="input !w-28 text-right" inputMode="decimal" value={s.value}
                           onChange={(e) => setSel({ ...sel, [m.userId]: { ...s, value: e.target.value } })} placeholder={method === 'PERCENTAGE' ? '%' : method === 'SHARES' ? 'units' : '0.00'} />
                  )}
                  {preview && s.on && <span className="text-sm font-bold tabular-nums">{money(preview[m.userId], currency)}</span>}
                </li>
              )
            })}
          </ul>
          {method !== 'EQUAL' && (
            <p className="mt-2 text-xs font-semibold text-ink-soft">
              {method === 'EXACT' && `Allocated ${money(allocated, currency)} of ${money(total, currency)}`}
              {method === 'PERCENTAGE' && `Allocated ${allocated}% of 100%`}
              {method === 'SHARES' && `${allocated} shares in total`}
            </p>
          )}
        </fieldset>
        <TextInput label="Notes (optional)" {...register('notes')} />
        <div className="flex justify-end gap-2"><button type="button" className="btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn-primary" disabled={isSubmitting}>{isSubmitting && <Spinner />}{initial ? 'Save changes' : 'Add expense'}</button></div>
      </form>
    </Modal>
  )
}
