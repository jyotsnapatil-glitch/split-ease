import { Link } from 'react-router-dom'

export function Logo({ to = '/', light }: { to?: string; light?: boolean }) {
  return (
    <Link to={to} className="inline-flex items-center gap-2 font-extrabold tracking-tight" aria-label="SplitEase home">
      <svg viewBox="0 0 32 32" className="h-8 w-8" aria-hidden><rect width="32" height="32" rx="8" fill="#0b1f3a" /><path d="M9 21c0-5 14-2 14-8" stroke="#34d399" strokeWidth="3" fill="none" strokeLinecap="round" /><circle cx="9" cy="21" r="2.5" fill="#34d399" /><circle cx="23" cy="13" r="2.5" fill="#fff" /></svg>
      <span className={`text-lg ${light ? 'text-white' : 'text-ink'}`}>SplitEase</span>
    </Link>
  )
}
