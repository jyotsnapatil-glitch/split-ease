import { ReactNode, useEffect, useRef, forwardRef, InputHTMLAttributes, SelectHTMLAttributes } from 'react'
import { Loader2, X, Inbox } from 'lucide-react'

export function Spinner({ className = '' }: { className?: string }) { return <Loader2 className={`h-4 w-4 animate-spin ${className}`} aria-label="Loading" /> }

export function Skeleton({ className = '' }: { className?: string }) { return <div className={`animate-pulse rounded-xl bg-slate-200/70 ${className}`} aria-hidden /> }

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div><h1 className="text-2xl font-extrabold tracking-tight">{title}</h1>{subtitle && <p className="mt-1 text-sm text-ink-soft">{subtitle}</p>}</div>
      {action}
    </div>
  )
}

export function EmptyState({ title, body, action }: { title: string; body: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-2xl border border-dashed border-slate-300 bg-white/60 px-6 py-10 text-center">
      <Inbox className="h-8 w-8 text-ink-mute" aria-hidden />
      <h3 className="font-bold">{title}</h3><p className="max-w-sm text-sm text-ink-soft">{body}</p>{action}
    </div>
  )
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="rounded-2xl border border-rose-200 bg-rose-50 p-5 text-sm text-rose-800">
      <p className="font-semibold">{message}</p>
      {onRetry && <button className="btn-ghost mt-3" onClick={onRetry}>Try again</button>}
    </div>
  )
}

export function Badge({ tone, children }: { tone: 'green' | 'amber' | 'red' | 'slate'; children: ReactNode }) {
  const c = { green: 'bg-mint-50 text-mint-700', amber: 'bg-amber-50 text-amber-700', red: 'bg-rose-50 text-rose-700', slate: 'bg-slate-100 text-ink-soft' }[tone]
  return <span className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-bold ${c}`}>{children}</span>
}

export function Modal({ open, title, onClose, children, wide }: { open: boolean; title: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!open) return
    const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', h)
    ref.current?.focus()
    return () => document.removeEventListener('keydown', h)
  }, [open, onClose])
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-0 sm:items-center sm:p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div ref={ref} tabIndex={-1} role="dialog" aria-modal="true" aria-label={title}
           className={`card max-h-[92vh] w-full overflow-y-auto rounded-b-none p-5 sm:rounded-b-2xl ${wide ? 'sm:max-w-2xl' : 'sm:max-w-md'}`}>
        <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-extrabold">{title}</h2>
          <button aria-label="Close" onClick={onClose} className="rounded-lg p-1 hover:bg-slate-100"><X className="h-5 w-5" /></button></div>
        {children}
      </div>
    </div>
  )
}

export function ConfirmDialog({ open, title, body, confirmLabel, danger, busy, onConfirm, onClose }:
  { open: boolean; title: string; body: string; confirmLabel: string; danger?: boolean; busy?: boolean; onConfirm: () => void; onClose: () => void }) {
  return (
    <Modal open={open} title={title} onClose={onClose}>
      <p className="mb-5 text-sm text-ink-soft">{body}</p>
      <div className="flex justify-end gap-2">
        <button className="btn-ghost" onClick={onClose}>Cancel</button>
        <button className={danger ? 'btn-danger' : 'btn-primary'} disabled={busy} onClick={onConfirm}>{busy && <Spinner />}{confirmLabel}</button>
      </div>
    </Modal>
  )
}

export function Tabs<T extends string>({ tabs, value, onChange }: { tabs: { id: T; label: string }[]; value: T; onChange: (t: T) => void }) {
  return (
    <div role="tablist" className="mb-5 flex gap-1 overflow-x-auto rounded-xl bg-slate-100 p-1">
      {tabs.map((t) => (
        <button key={t.id} role="tab" aria-selected={value === t.id} onClick={() => onChange(t.id)}
                className={`whitespace-nowrap rounded-lg px-4 py-2 text-sm font-semibold ${value === t.id ? 'bg-white shadow-card' : 'text-ink-soft hover:text-ink'}`}>{t.label}</button>
      ))}
    </div>
  )
}

interface FieldProps { label: string; error?: string; children: ReactNode; htmlFor?: string }
export function Field({ label, error, children, htmlFor }: FieldProps) {
  return <div><label htmlFor={htmlFor} className="label">{label}</label>{children}{error && <p className="err" role="alert">{error}</p>}</div>
}

export const TextInput = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string }>(
  ({ label, error, id, ...p }, ref) => {
    const fid = id ?? `f-${label.replace(/\W+/g, '-').toLowerCase()}`
    return <Field label={label} error={error} htmlFor={fid}><input id={fid} ref={ref} className="input" aria-invalid={!!error} {...p} /></Field>
  })
TextInput.displayName = 'TextInput'

export const Select = forwardRef<HTMLSelectElement, SelectHTMLAttributes<HTMLSelectElement> & { label: string; error?: string }>(
  ({ label, error, id, children, ...p }, ref) => {
    const fid = id ?? `f-${label.replace(/\W+/g, '-').toLowerCase()}`
    return <Field label={label} error={error} htmlFor={fid}><select id={fid} ref={ref} className="input" aria-invalid={!!error} {...p}>{children}</select></Field>
  })
Select.displayName = 'Select'

export function Amount({ value, currency, signed }: { value: number; currency: string; signed?: boolean }) {
  const tone = value > 0 ? 'text-mint-700' : value < 0 ? 'text-rose-600' : 'text-ink-soft'
  const s = new Intl.NumberFormat('en-IN', { style: 'currency', currency, maximumFractionDigits: 2 }).format(Math.abs(value))
  return <span className={`font-bold tabular-nums ${signed ? tone : ''}`}>{signed && value > 0 ? '+' : ''}{signed && value < 0 ? '−' : ''}{s}</span>
}
