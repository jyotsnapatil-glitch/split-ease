import { createContext, useCallback, useContext, useMemo, useState, ReactNode } from 'react'
import { CheckCircle2, AlertCircle, X } from 'lucide-react'

type Kind = 'success' | 'error'
interface T { id: number; msg: string; kind: Kind }
interface Ctx { push: (msg: string, kind?: Kind) => void }
const C = createContext<Ctx>({ push: () => {} })
export const useToast = () => useContext(C)

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<T[]>([])
  const push = useCallback((msg: string, kind: Kind = 'success') => {
    const id = Date.now() + Math.random()
    setItems((x) => [...x, { id, msg, kind }])
    setTimeout(() => setItems((x) => x.filter((t) => t.id !== id)), 4500)
  }, [])
  const value = useMemo(() => ({ push }), [push])
  return (
    <C.Provider value={value}>
      {children}
      <div className="fixed bottom-4 right-4 z-[60] flex w-[min(92vw,22rem)] flex-col gap-2" role="status" aria-live="polite">
        {items.map((t) => (
          <div key={t.id} className={`card flex items-start gap-3 p-3 text-sm ${t.kind === 'error' ? 'border-rose-200' : 'border-mint-100'}`}>
            {t.kind === 'error' ? <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-rose-600" /> : <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-mint-600" />}
            <span className="flex-1">{t.msg}</span>
            <button aria-label="Dismiss" onClick={() => setItems((x) => x.filter((i) => i.id !== t.id))}><X className="h-4 w-4 text-ink-mute" /></button>
          </div>
        ))}
      </div>
    </C.Provider>
  )
}
