import { Navigate, Outlet, Route, Routes } from 'react-router-dom'
import { useAuth } from './lib/auth'
import Shell from './components/Shell'
import { Skeleton } from './components/ui'
import Landing from './pages/Landing'
import { Login, Register } from './pages/AuthPages'
import Onboarding from './pages/Onboarding'
import Dashboard from './pages/Dashboard'
import { Groups, GroupDetailPage } from './pages/Groups'
import Expenses from './pages/Expenses'
import { Balances, Settlements } from './pages/Money'
import Analytics from './pages/Analytics'
import ActivityPage from './pages/ActivityPage'
import Settings from './pages/Settings'
import Admin from './pages/Admin'

function Protected({ admin }: { admin?: boolean }) {
  const { user, loading } = useAuth()
  if (loading) return <div className="mx-auto max-w-3xl space-y-3 p-8"><Skeleton className="h-10" /><Skeleton className="h-40" /></div>
  if (!user) return <Navigate to="/login" replace />
  if (!user.onboarded && user.role !== 'ADMIN') return <Navigate to="/onboarding" replace />
  if (admin && user.role !== 'ADMIN') return <Navigate to="/dashboard" replace />
  return <Shell><Outlet /></Shell>
}

function GuestOnly() {
  const { user, loading } = useAuth()
  if (loading) return null
  return user ? <Navigate to="/dashboard" replace /> : <Outlet />
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route element={<GuestOnly />}>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Route>
      <Route path="/onboarding" element={<Onboarding />} />
      <Route element={<Protected />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/groups" element={<Groups />} />
        <Route path="/groups/:id" element={<GroupDetailPage />} />
        <Route path="/expenses" element={<Expenses />} />
        <Route path="/balances" element={<Balances />} />
        <Route path="/settlements" element={<Settlements />} />
        <Route path="/analytics" element={<Analytics />} />
        <Route path="/activity" element={<ActivityPage />} />
        <Route path="/settings" element={<Settings />} />
      </Route>
      <Route element={<Protected admin />}><Route path="/admin" element={<Admin />} /></Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
