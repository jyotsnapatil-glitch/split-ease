import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import { vi, describe, it, expect, beforeEach } from 'vitest'
import { Login, Register } from '../pages/AuthPages'
import { ToastProvider } from '../components/Toast'
import { AuthProvider } from '../lib/auth'
import { api } from '../lib/api'

vi.mock('../lib/api', async (orig) => {
  const m = await orig<typeof import('../lib/api')>()
  return { ...m, api: { get: vi.fn(), post: vi.fn(), put: vi.fn(), delete: vi.fn() } }
})

const wrap = (ui: React.ReactNode) => render(<MemoryRouter><ToastProvider><AuthProvider>{ui}</AuthProvider></ToastProvider></MemoryRouter>)
beforeEach(() => { vi.clearAllMocks(); (api.get as any).mockRejectedValue({ response: { status: 401 } }) })

describe('Register form', () => {
  it('shows field-level validation errors without calling the API', async () => {
    wrap(<Register />)
    await userEvent.click(screen.getByRole('button', { name: /create account/i }))
    expect(await screen.findByText(/enter your full name/i)).toBeInTheDocument()
    expect(screen.getByText(/enter a valid email/i)).toBeInTheDocument()
    expect(api.post).not.toHaveBeenCalled()
  })
  it('flags mismatched passwords', async () => {
    wrap(<Register />)
    await userEvent.type(screen.getByLabelText('Full name'), 'Jo')
    await userEvent.type(screen.getByLabelText('Email'), 'jo@test.dev')
    await userEvent.type(screen.getByLabelText('Password'), 'Passw0rdOK')
    await userEvent.type(screen.getByLabelText('Confirm password'), 'different1')
    await userEvent.click(screen.getByRole('button', { name: /create account/i }))
    expect(await screen.findByText(/passwords do not match/i)).toBeInTheDocument()
  })
  it('maps a duplicate-email 409 onto the email field', async () => {
    ;(api.post as any).mockRejectedValue({ response: { status: 409, data: { message: 'An account with this email already exists' } } })
    wrap(<Register />)
    await userEvent.type(screen.getByLabelText('Full name'), 'Jo')
    await userEvent.type(screen.getByLabelText('Email'), 'jo@test.dev')
    await userEvent.type(screen.getByLabelText('Password'), 'Passw0rdOK')
    await userEvent.type(screen.getByLabelText('Confirm password'), 'Passw0rdOK')
    await userEvent.click(screen.getByRole('button', { name: /create account/i }))
    expect(await screen.findByText(/email already exists/i)).toBeInTheDocument()
  })
})

describe('Login form', () => {
  it('shows the server error for bad credentials', async () => {
    ;(api.post as any).mockRejectedValue({ response: { status: 401, data: { message: 'Invalid email or password' } } })
    wrap(<Login />)
    await userEvent.type(screen.getByLabelText('Email'), 'a@b.co')
    await userEvent.type(screen.getByLabelText('Password'), 'nope')
    await userEvent.click(screen.getByRole('button', { name: /sign in/i }))
    await waitFor(() => expect(screen.getByRole('alert')).toHaveTextContent(/invalid email or password/i))
  })
})
