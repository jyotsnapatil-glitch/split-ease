import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { vi, describe, it, expect } from 'vitest'
import { EmptyState, ErrorState, ConfirmDialog } from '../components/ui'
import Landing from '../pages/Landing'
import { AuthProvider } from '../lib/auth'
import { ToastProvider } from '../components/Toast'

vi.mock('../lib/api', async (orig) => ({ ...(await orig<typeof import('../lib/api')>()), api: { get: vi.fn().mockRejectedValue({}), post: vi.fn() } }))

describe('UI states', () => {
  it('renders an empty state with guidance', () => {
    render(<EmptyState title="No groups yet" body="Create a group to begin" />)
    expect(screen.getByText('No groups yet')).toBeInTheDocument()
  })
  it('error state offers retry', async () => {
    const retry = vi.fn(); render(<ErrorState message="Cannot reach the server" onRetry={retry} />)
    await userEvent.click(screen.getByRole('button', { name: /try again/i })); expect(retry).toHaveBeenCalled()
  })
  it('confirm dialog calls back on confirm', async () => {
    const ok = vi.fn(); render(<ConfirmDialog open title="Delete?" body="Sure?" confirmLabel="Delete" onConfirm={ok} onClose={() => {}} />)
    await userEvent.click(screen.getByRole('button', { name: 'Delete' })); expect(ok).toHaveBeenCalled()
  })
  it('landing Get started navigates to registration', async () => {
    render(<MemoryRouter><ToastProvider><AuthProvider><Routes><Route path="/" element={<Landing />} /><Route path="/register" element={<p>register page</p>} /></Routes></AuthProvider></ToastProvider></MemoryRouter>)
    await userEvent.click(screen.getAllByRole('link', { name: /get started/i })[0])
    expect(await screen.findByText('register page')).toBeInTheDocument()
  })
})
