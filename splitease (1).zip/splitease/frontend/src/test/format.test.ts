import { describe, expect, it } from 'vitest'
import { money, previewEqual, label } from '../lib/format'

describe('format helpers', () => {
  it('formats rupees', () => { expect(money(900, 'INR')).toContain('900.00') })
  it('labels enums', () => { expect(label('BANK_TRANSFER')).toBe('Bank transfer') })
  it('previews equal split with deterministic remainder', () => {
    const p = previewEqual(100, [3, 1, 2])
    expect(p[1]).toBe(33.34); expect(p[2]).toBe(33.33); expect(p[3]).toBe(33.33)
    expect(Object.values(p).reduce((a, b) => a + b, 0)).toBeCloseTo(100, 2)
  })
})
