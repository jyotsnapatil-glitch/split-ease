import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts'
import { useFetch } from '../lib/useFetch'
import { Amount, EmptyState, ErrorState, PageHeader, Skeleton } from '../components/ui'
import { label, money } from '../lib/format'
import { PALETTE } from './Dashboard'

interface Overview { currency: string; totalPaid: number; personalSpend: number; netContribution: number; groups: number; confirmedSettlements: number; pendingSettlements: number }

export default function Analytics() {
  const o = useFetch<Overview>('/analytics/overview'); const m = useFetch<{ month: string; amount: number }[]>('/analytics/monthly?months=12')
  const c = useFetch<{ category: string; amount: number }[]>('/analytics/categories'); const g = useFetch<{ groupId: number; groupName: string; amount: number }[]>('/analytics/groups')
  if (o.loading || m.loading || c.loading || g.loading) return <div className="space-y-4"><Skeleton className="h-10 w-48" /><Skeleton className="h-72" /></div>
  if (o.error || !o.data) return <ErrorState message={o.error || 'Could not load analytics'} onRetry={() => { o.reload(); m.reload(); c.reload(); g.reload() }} />
  const cur = o.data.currency
  if (!c.data?.length) return <><PageHeader title="Analytics" /><EmptyState title="No data to analyse yet" body="Charts use your share of real expenses. Add an expense in any group and they will fill in." /></>
  return (<>
    <PageHeader title="Analytics" subtitle={`Your share of spending in ${cur}. Groups in other currencies are not mixed in.`} />
    <div className="mb-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {[['You paid', <Amount value={o.data.totalPaid} currency={cur} />], ['Your share of spending', <Amount value={o.data.personalSpend} currency={cur} />],
        ['Contribution vs share', <Amount value={o.data.netContribution} currency={cur} signed />], ['Settlements', <span className="font-bold">{o.data.confirmedSettlements} confirmed · {o.data.pendingSettlements} pending</span>]]
        .map(([t, v], i) => <div key={i} className="card p-4"><p className="text-xs font-semibold text-ink-soft">{t}</p><p className="mt-1 text-lg">{v}</p></div>)}
    </div>
    <div className="grid gap-4 lg:grid-cols-2">
      <section className="card p-5 lg:col-span-2"><h2 className="mb-3 font-bold">Monthly expenditure</h2><div className="h-64" role="img" aria-label="Monthly expenditure bar chart"><ResponsiveContainer><BarChart data={m.data ?? []}><XAxis dataKey="month" tick={{ fontSize: 12 }} /><YAxis width={52} tick={{ fontSize: 12 }} /><Tooltip formatter={(v: number) => money(v, cur)} /><Bar dataKey="amount" fill="#059669" radius={[6, 6, 0, 0]} /></BarChart></ResponsiveContainer></div></section>
      <section className="card p-5"><h2 className="mb-3 font-bold">Spending by category</h2><div className="h-64" role="img" aria-label="Category spending pie chart"><ResponsiveContainer><PieChart><Pie data={c.data} dataKey="amount" nameKey="category" outerRadius={85} innerRadius={40}>{c.data.map((_, i) => <Cell key={i} fill={PALETTE[i % PALETTE.length]} />)}</Pie><Tooltip formatter={(v: number, n: string) => [money(v, cur), label(n)]} /><Legend formatter={(v: string) => label(v)} /></PieChart></ResponsiveContainer></div></section>
      <section className="card p-5"><h2 className="mb-3 font-bold">Spending by group</h2><div className="h-64" role="img" aria-label="Group spending bar chart"><ResponsiveContainer><BarChart data={g.data ?? []} layout="vertical"><XAxis type="number" tick={{ fontSize: 12 }} /><YAxis type="category" dataKey="groupName" width={90} tick={{ fontSize: 12 }} /><Tooltip formatter={(v: number) => money(v, cur)} /><Bar dataKey="amount" fill="#0b1f3a" radius={[0, 6, 6, 0]} /></BarChart></ResponsiveContainer></div></section>
    </div>
  </>)
}
