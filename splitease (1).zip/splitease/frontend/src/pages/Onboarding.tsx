import { useState } from 'react'
import { Navigate, useNavigate } from 'react-router-dom'
import { api, errMsg } from '../lib/api'
import { useAuth } from '../lib/auth'
import { Logo } from '../components/Logo'
import { Spinner, TextInput, Select } from '../components/ui'
import { CURRENCIES, GROUP_CATEGORIES, User } from '../lib/types'
import { label } from '../lib/format'
import { useToast } from '../components/Toast'

export default function Onboarding() {
  const { user, loading, setUser } = useAuth(); const nav = useNavigate(); const toast = useToast()
  const [step, setStep] = useState(0)
  const [name, setName] = useState(user?.fullName ?? ''); const [cur, setCur] = useState(user?.preferredCurrency ?? 'INR')
  const [gName, setGName] = useState(''); const [gCat, setGCat] = useState('TRIP'); const [busy, setBusy] = useState(false); const [err, setErr] = useState('')
  if (loading) return null
  if (!user) return <Navigate to="/login" replace />

  const finish = async () => {
    setBusy(true); setErr('')
    try {
      const r = await api.post<User>('/users/me/onboarding', { displayName: name, currency: cur })
      setUser(r.data); nav('/dashboard')
    } catch (e) { setErr(errMsg(e)); setBusy(false) }
  }
  const saveProfile = async () => {
    if (!name.trim()) { setErr('Enter a display name'); return }
    setErr(''); setStep(1)
  }
  const createGroup = async () => {
    if (!gName.trim()) { setErr('Name your group or skip this step'); return }
    setBusy(true); setErr('')
    try { await api.post('/groups', { name: gName, category: gCat, currency: cur, memberEmails: [] }); toast.push('Group created'); setStep(2) }
    catch (e) { setErr(errMsg(e)) } finally { setBusy(false) }
  }

  return (
    <div className="grid min-h-screen place-items-center px-4 py-10">
      <div className="w-full max-w-lg">
        <div className="mb-6 flex justify-center"><Logo /></div>
        <div className="card p-6 sm:p-8">
          <p className="mb-4 text-sm font-semibold text-ink-soft">Step {step + 1} of 3</p>
          {err && <p role="alert" className="mb-4 rounded-xl bg-rose-50 p-3 text-sm font-medium text-rose-700">{err}</p>}
          {step === 0 && (
            <div className="space-y-4">
              <h1 className="text-2xl font-extrabold">What should we call you?</h1>
              <TextInput label="Display name" value={name} onChange={(e) => setName(e.target.value)} />
              <Select label="Preferred currency" value={cur} onChange={(e) => setCur(e.target.value)}>{CURRENCIES.map((c) => <option key={c}>{c}</option>)}</Select>
              <p className="text-xs text-ink-soft">Used for your dashboard totals. Each group keeps its own currency.</p>
              <button className="btn-primary w-full" onClick={saveProfile}>Continue</button>
            </div>
          )}
          {step === 1 && (
            <div className="space-y-4">
              <h1 className="text-2xl font-extrabold">Start your first group</h1>
              <TextInput label="Group name" placeholder="Goa trip, Flat 4B, Lab partners" value={gName} onChange={(e) => setGName(e.target.value)} />
              <Select label="Category" value={gCat} onChange={(e) => setGCat(e.target.value)}>{GROUP_CATEGORIES.map((c) => <option key={c} value={c}>{label(c)}</option>)}</Select>
              <div className="flex gap-2"><button className="btn-ghost flex-1" onClick={() => { setErr(''); setStep(2) }}>Skip for now</button>
                <button className="btn-primary flex-1" disabled={busy} onClick={createGroup}>{busy && <Spinner />}Create group</button></div>
            </div>
          )}
          {step === 2 && (
            <div className="space-y-4">
              <h1 className="text-2xl font-extrabold">How SplitEase works</h1>
              <ol className="space-y-3 text-sm text-ink-soft">
                <li><b className="text-ink">Add an expense.</b> Say who paid and how to split it: equally, by amount, percentage or shares.</li>
                <li><b className="text-ink">See who owes whom.</b> Balances update from every expense, and we suggest the fewest payments to settle up.</li>
                <li><b className="text-ink">Record the payment.</b> Pay outside the app, then record it. The receiver confirms before balances change.</li>
              </ol>
              <button className="btn-primary w-full" disabled={busy} onClick={finish}>{busy && <Spinner />}Go to dashboard</button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
