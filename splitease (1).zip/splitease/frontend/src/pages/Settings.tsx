import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api, errMsg } from '../lib/api'
import { useAuth } from '../lib/auth'
import { CURRENCIES, User } from '../lib/types'
import { PageHeader, Select, Spinner, TextInput } from '../components/ui'
import { useToast } from '../components/Toast'

export default function Settings() {
  const { user, setUser, logout } = useAuth(); const toast = useToast(); const nav = useNavigate()
  const [name, setName] = useState(user!.fullName); const [cur, setCur] = useState(user!.preferredCurrency); const [pBusy, setPBusy] = useState(false); const [pErr, setPErr] = useState('')
  const [curPw, setCurPw] = useState(''); const [newPw, setNewPw] = useState(''); const [confirm, setConfirm] = useState(''); const [wBusy, setWBusy] = useState(false); const [wErr, setWErr] = useState('')

  const saveProfile = async (e: React.FormEvent) => {
    e.preventDefault(); setPErr('')
    if (!name.trim()) { setPErr('Display name cannot be empty'); return }
    setPBusy(true)
    try { const r = await api.put<User>('/users/me', { fullName: name, preferredCurrency: cur }); setUser(r.data); toast.push('Profile saved') } catch (er) { setPErr(errMsg(er)) } finally { setPBusy(false) }
  }
  const changePw = async (e: React.FormEvent) => {
    e.preventDefault(); setWErr('')
    if (newPw.length < 8 || !/[A-Za-z]/.test(newPw) || !/\d/.test(newPw)) { setWErr('New password needs 8+ characters with a letter and a number'); return }
    if (newPw !== confirm) { setWErr('New passwords do not match'); return }
    setWBusy(true)
    try { await api.post('/users/me/password', { currentPassword: curPw, newPassword: newPw }); toast.push('Password changed. Sign in again.'); setUser(null); nav('/login') } catch (er) { setWErr(errMsg(er)) } finally { setWBusy(false) }
  }
  return (<>
    <PageHeader title="Settings" />
    <div className="grid max-w-3xl gap-5">
      <form onSubmit={saveProfile} className="card space-y-4 p-5"><h2 className="font-bold">Profile</h2>
        {pErr && <p role="alert" className="rounded-xl bg-rose-50 p-3 text-sm font-medium text-rose-700">{pErr}</p>}
        <TextInput label="Display name" value={name} onChange={(e) => setName(e.target.value)} />
        <TextInput label="Email" value={user!.email} disabled readOnly />
        <Select label="Preferred currency" value={cur} onChange={(e) => setCur(e.target.value)}>{CURRENCIES.map((c) => <option key={c}>{c}</option>)}</Select>
        <p className="text-xs text-ink-soft">This only changes how your dashboard and analytics are totalled. Group currencies are never converted.</p>
        <button className="btn-primary" disabled={pBusy}>{pBusy && <Spinner />}Save profile</button></form>
      <form onSubmit={changePw} className="card space-y-4 p-5"><h2 className="font-bold">Change password</h2>
        {wErr && <p role="alert" className="rounded-xl bg-rose-50 p-3 text-sm font-medium text-rose-700">{wErr}</p>}
        <TextInput label="Current password" type="password" autoComplete="current-password" value={curPw} onChange={(e) => setCurPw(e.target.value)} />
        <TextInput label="New password" type="password" autoComplete="new-password" value={newPw} onChange={(e) => setNewPw(e.target.value)} />
        <TextInput label="Confirm new password" type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
        <p className="text-xs text-ink-soft">Changing your password signs you out on every device.</p>
        <button className="btn-primary" disabled={wBusy}>{wBusy && <Spinner />}Change password</button></form>
      <div className="card flex items-center justify-between p-5"><div><h2 className="font-bold">Log out</h2><p className="text-sm text-ink-soft">End your session on this device.</p></div><button className="btn-dark" onClick={async () => { await logout(); nav('/') }}>Log out</button></div>
    </div>
  </>)
}
