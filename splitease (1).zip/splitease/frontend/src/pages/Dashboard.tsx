import { Link, useNavigate } from 'react-router-dom'
import { Plus, Wallet, ArrowDownLeft, ArrowUpRight, Scale, HandCoins } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import { useFetch } from '../lib/useFetch'
import { Dashboard as D } from '../lib/types'
import { Amount, EmptyState, ErrorState, PageHeader, Skeleton } from '../components/ui'
import { label, money, shortDate } from '../lib/format'

export const PALETTE = ['#059669', '#0b1f3a', '#14b8a6', '#6366f1', '#f59e0b', '#e11d48', '#0ea5e9', '#84cc16', '#a855f7', '#64748b']

function Stat({ title, value, icon: I, tone }: { title: string; value: React.ReactNode; icon: typeof Wallet; tone?: string }) {
  return <div className="card flex items-center gap-4 p-4"><span className={`grid h-11 w-11 place-items-center rounded-xl ${tone ?? 'bg-mint-50 text-mint-700'}`}><I className="h-5 w-5" aria-hidden /></span>
    <div><p className="text-xs font-semibold text-ink-soft">{title}</p><p className="text-xl">{value}</p></div></div>
}

export default function Dashboard() {
  const { data, loading, error, reload } = useFetch<D>('/dashboard')
  const nav = useNavigate()
  if (loading) return <div className="space-y-4"><Skeleton className="h-10 w-60" /><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-20" />)}</div><Skeleton className="h-64" /></div>
  if (error || !data) return <ErrorState message={error || 'Could not load your dashboard'} onRetry={reload} />
  const c = data.currency
  const hasData = data.groups.length > 0
  return (
    <>
      <PageHeader title="Dashboard" subtitle={`Totals are shown in ${c}.`} action={
        <div className="flex flex-wrap gap-2">
          <Link to="/groups?new=1" className="btn-ghost"><Plus className="h-4 w-4" />Create group</Link>
          <button className="btn-ghost" onClick={() => nav(hasData ? `/groups/${data.groups[0].id}?add=1` : '/groups?new=1')}><Plus className="h-4 w-4" />Add expense</button>
          <button className="btn-primary" onClick={() => nav('/settlements')}><HandCoins className="h-4 w-4" />Settle up</button>
        </div>} />
      {data.otherCurrencyGroups > 0 && <p className="mb-4 rounded-xl bg-amber-50 p-3 text-sm text-amber-800">{data.otherCurrencyGroups} group{data.otherCurrencyGroups > 1 ? 's use' : ' uses'} a different currency and {data.otherCurrencyGroups > 1 ? 'are' : 'is'} left out of these totals. Open the group to see its balance.</p>}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat title="Total paid" icon={Wallet} value={<Amount value={data.totalPaid} currency={c} />} />
        <Stat title="You owe" icon={ArrowUpRight} tone="bg-rose-50 text-rose-600" value={<Amount value={data.totalOwed} currency={c} />} />
        <Stat title="Others owe you" icon={ArrowDownLeft} value={<Amount value={data.owedToMe} currency={c} />} />
        <Stat title="Net balance" icon={Scale} tone="bg-slate-100 text-ink" value={<Amount value={data.netBalance} currency={c} signed />} />
      </div>

      {!hasData ? (
        <div className="mt-6"><EmptyState title="No groups yet" body="Create a group, add your friends by email, and log the first expense. Your totals and charts will appear here." action={<Link to="/groups?new=1" className="btn-primary mt-2">Create your first group</Link>} /></div>
      ) : (
        <div className="mt-6 grid gap-4 lg:grid-cols-3">
          <section className="card p-5 lg:col-span-2"><h2 className="mb-3 font-bold">Your spending by month</h2>
            <div className="h-56" role="img" aria-label="Bar chart of your share of expenses per month">
              <ResponsiveContainer><BarChart data={data.monthly}><XAxis dataKey="month" tick={{ fontSize: 12 }} /><YAxis tick={{ fontSize: 12 }} width={48} /><Tooltip formatter={(v: number) => money(v, c)} /><Bar dataKey="amount" fill="#059669" radius={[6, 6, 0, 0]} /></BarChart></ResponsiveContainer></div></section>
          <section className="card p-5"><h2 className="mb-3 font-bold">By category</h2>
            {data.categories.length === 0 ? <p className="text-sm text-ink-soft">Add an expense to see your categories.</p> :
              <div className="h-56" role="img" aria-label="Pie chart of spending by category"><ResponsiveContainer><PieChart><Pie data={data.categories} dataKey="amount" nameKey="category" innerRadius={42} outerRadius={80}>{data.categories.map((_, i) => <Cell key={i} fill={PALETTE[i % PALETTE.length]} />)}</Pie><Tooltip formatter={(v: number, n: string) => [money(v, c), label(n)]} /></PieChart></ResponsiveContainer></div>}</section>

          <section className="card p-5 lg:col-span-2"><div className="mb-3 flex items-center justify-between"><h2 className="font-bold">Recent transactions</h2><Link className="text-sm font-semibold text-mint-700" to="/expenses">View all</Link></div>
            {data.recent.length === 0 ? <p className="text-sm text-ink-soft">Nothing yet. Add your first expense from a group.</p> :
              <ul className="divide-y divide-slate-100">{data.recent.map((t) => (
                <li key={`${t.type}-${t.id}`} className="flex items-center justify-between gap-3 py-2.5"><div className="min-w-0"><p className="truncate font-semibold">{t.title}</p><p className="text-xs text-ink-soft">{t.groupName} · {shortDate(t.date)} · {t.type === 'SETTLEMENT' ? label(t.status) : t.actorName}</p></div><Amount value={t.amount} currency={t.currency} /></li>))}</ul>}</section>

          <section className="card p-5"><h2 className="mb-3 font-bold">Unsettled</h2>
            {data.unsettled.length === 0 && data.pendingSettlements.length === 0 ? <p className="text-sm text-ink-soft">You are all square.</p> : (
              <ul className="space-y-2">
                {data.unsettled.map((u) => <li key={u.groupId}><Link to={`/groups/${u.groupId}`} className="flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2 text-sm hover:bg-slate-100"><span className="truncate font-semibold">{u.groupName}</span><Amount value={u.net} currency={u.currency} signed /></Link></li>)}
                {data.pendingSettlements.map((s) => <li key={s.id}><Link to="/settlements" className="block rounded-xl bg-amber-50 px-3 py-2 text-sm text-amber-800">Pending: {s.payerName} → {s.receiverName}, {money(s.amount, s.currency)}</Link></li>)}
              </ul>)}</section>

          <section className="card p-5 lg:col-span-3"><div className="mb-3 flex items-center justify-between"><h2 className="font-bold">My groups</h2><Link className="text-sm font-semibold text-mint-700" to="/groups">Manage</Link></div>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{data.groups.slice(0, 6).map((g) => (
              <Link key={g.id} to={`/groups/${g.id}`} className="rounded-xl border border-slate-200 p-4 hover:border-mint-600"><p className="font-bold">{g.name}</p><p className="text-xs text-ink-soft">{label(g.category)} · {g.memberCount} members</p><p className="mt-2 text-sm"><Amount value={g.myBalance} currency={g.currency} signed /></p></Link>))}</div></section>
        </div>
      )}
    </>
  )
}
