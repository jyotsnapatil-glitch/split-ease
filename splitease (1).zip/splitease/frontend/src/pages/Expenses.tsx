import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { api } from '../lib/api'
import { useFetch } from '../lib/useFetch'
import { CATEGORIES, Expense, GroupSummary, Page, Txn } from '../lib/types'
import { Amount, Badge, EmptyState, ErrorState, Modal, PageHeader, Select, Skeleton, TextInput } from '../components/ui'
import { label, money, shortDate } from '../lib/format'

export default function Expenses() {
  const [params, setParams] = useSearchParams()
  const q = params.get('q') ?? ''
  const [from, setFrom] = useState(''); const [to, setTo] = useState(''); const [cat, setCat] = useState(''); const [gid, setGid] = useState(''); const [type, setType] = useState(''); const [page, setPage] = useState(0)
  const [text, setText] = useState(q)
  useEffect(() => { setText(q); setPage(0) }, [q])
  const groups = useFetch<GroupSummary[]>('/groups')
  const qs = new URLSearchParams({ page: String(page), size: '10' })
  if (q) qs.set('q', q); if (from) qs.set('from', from); if (to) qs.set('to', to); if (cat) qs.set('category', cat); if (gid) qs.set('groupId', gid); if (type) qs.set('type', type)
  const { data, loading, error, reload } = useFetch<Page<Txn>>(`/transactions?${qs}`)
  const [detail, setDetail] = useState<Expense | null>(null); const [detailTxn, setDetailTxn] = useState<Txn | null>(null)

  const open = async (t: Txn) => {
    setDetailTxn(t); setDetail(null)
    if (t.type === 'EXPENSE') { try { setDetail((await api.get<Expense>(`/expenses/${t.id}`)).data) } catch { /* keep summary */ } }
  }
  const reset = () => { setFrom(''); setTo(''); setCat(''); setGid(''); setType(''); setPage(0); setParams({}) }

  return (
    <>
      <PageHeader title="Expenses" subtitle="Every expense and settlement across your groups." />
      <form className="card mb-5 grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-6" onSubmit={(e) => { e.preventDefault(); setPage(0); setParams(text ? { q: text } : {}) }} role="search">
        <div className="lg:col-span-2"><TextInput label="Search" placeholder="Title or person" value={text} onChange={(e) => setText(e.target.value)} /></div>
        <Select label="Group" value={gid} onChange={(e) => { setGid(e.target.value); setPage(0) }}><option value="">All groups</option>{groups.data?.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}</Select>
        <Select label="Category" value={cat} onChange={(e) => { setCat(e.target.value); setPage(0) }}><option value="">All</option>{CATEGORIES.map((c) => <option key={c} value={c}>{label(c)}</option>)}</Select>
        <TextInput label="From" type="date" value={from} onChange={(e) => { setFrom(e.target.value); setPage(0) }} />
        <TextInput label="To" type="date" value={to} onChange={(e) => { setTo(e.target.value); setPage(0) }} />
        <Select label="Type" value={type} onChange={(e) => { setType(e.target.value); setPage(0) }}><option value="">Expenses and settlements</option><option value="EXPENSE">Expenses</option><option value="SETTLEMENT">Settlements</option></Select>
        <div className="flex items-end gap-2 lg:col-span-2"><button className="btn-dark">Search</button><button type="button" className="btn-ghost" onClick={reset}>Clear filters</button></div>
      </form>
      {loading ? <Skeleton className="h-64" /> : error ? <ErrorState message={error} onRetry={reload} /> : !data?.items.length ?
        <EmptyState title="Nothing matches" body="Try clearing the filters, or add an expense from one of your groups." /> : (
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[34rem] text-sm"><thead className="text-left text-xs text-ink-soft"><tr><th className="p-3">Description</th><th className="p-3">Group</th><th className="p-3">Date</th><th className="p-3 text-right">Amount</th></tr></thead>
            <tbody className="divide-y divide-slate-100">{data.items.map((t) => (
              <tr key={`${t.type}-${t.id}`} className="cursor-pointer hover:bg-slate-50" tabIndex={0} onClick={() => open(t)} onKeyDown={(e) => e.key === 'Enter' && open(t)}>
                <td className="p-3"><p className="font-semibold">{t.title}</p><p className="text-xs text-ink-soft">{t.type === 'EXPENSE' ? `${label(t.category)} · ${t.actorName}` : <>Settlement · {label(t.category)} <Badge tone={t.status === 'CONFIRMED' ? 'green' : t.status === 'PENDING' ? 'amber' : 'red'}>{label(t.status)}</Badge></>}</p></td>
                <td className="p-3">{t.groupName}</td><td className="p-3 whitespace-nowrap">{shortDate(t.date)}</td><td className="p-3 text-right"><Amount value={t.amount} currency={t.currency} /></td></tr>))}</tbody></table>
          {data.totalPages > 1 && <div className="flex items-center justify-center gap-3 border-t border-slate-100 p-3"><button className="btn-ghost" disabled={page === 0} onClick={() => setPage(page - 1)}>Previous</button><span className="text-sm text-ink-soft">Page {page + 1} of {data.totalPages}</span><button className="btn-ghost" disabled={page + 1 >= data.totalPages} onClick={() => setPage(page + 1)}>Next</button></div>}
        </div>)}
      <Modal open={!!detailTxn} onClose={() => setDetailTxn(null)} title={detailTxn?.title ?? ''}>
        {detailTxn && (
          <div className="space-y-3 text-sm">
            <p className="text-ink-soft">{detailTxn.groupName} · {shortDate(detailTxn.date)}</p>
            <p className="text-2xl"><Amount value={detailTxn.amount} currency={detailTxn.currency} /></p>
            {detail ? (<>
              <p><b>{detail.paidByName}</b> paid. Split {label(detail.splitMethod).toLowerCase()} between {detail.participants.length} people.</p>
              <ul className="space-y-1">{detail.participants.map((p) => <li key={p.userId} className="flex justify-between rounded-lg bg-slate-50 px-3 py-1.5"><span>{p.fullName}</span><span className="font-semibold">{money(p.share, detail.currency)}</span></li>)}</ul>
              {detail.owes.length > 0 && <ul className="text-xs text-ink-soft">{detail.owes.map((o, i) => <li key={i}>{o.fromName} owes {o.toName} {money(o.amount, detail.currency)}</li>)}</ul>}
              {detail.notes && <p className="text-ink-soft">Notes: {detail.notes}</p>}
            </>) : detailTxn.type === 'EXPENSE' ? <Skeleton className="h-24" /> : <p>Status: {label(detailTxn.status)} · Method: {label(detailTxn.category)}</p>}
          </div>)}
      </Modal>
    </>
  )
}
