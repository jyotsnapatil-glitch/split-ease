import { Link } from 'react-router-dom'
import { Calculator, Scale, ShieldCheck, Users, BarChart3, HandCoins } from 'lucide-react'
import { Logo } from '../components/Logo'
import { useAuth } from '../lib/auth'

const FEATURES = [
  { icon: Users, t: 'Groups for every situation', d: 'Trips, flats, classes and couples. Each group has its own members and currency.' },
  { icon: Calculator, t: 'Four ways to split', d: 'Equal, exact amounts, percentages or shares. Rounding is handled so totals always add up to the paisa.' },
  { icon: Scale, t: 'Balances from real records', d: 'Nobody edits a balance by hand. It is calculated from expenses and confirmed payments.' },
  { icon: HandCoins, t: 'Fewer payments to settle', d: 'If Alice owes Bob and Bob owes Charlie, we suggest Alice pays Charlie once.' },
  { icon: BarChart3, t: 'Spending you can read', d: 'Monthly, category and group views of your own share.' },
  { icon: ShieldCheck, t: 'Private by default', d: 'Only group members can see a group. Passwords are hashed and sessions use secure cookies.' },
]

export default function Landing() {
  const { user } = useAuth()
  return (
    <div>
      <header className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
        <Logo />
        <nav aria-label="Primary" className="flex items-center gap-2 text-sm font-semibold">
          <a className="hidden px-3 py-2 text-ink-soft hover:text-ink sm:block" href="#features">Features</a>
          <a className="hidden px-3 py-2 text-ink-soft hover:text-ink sm:block" href="#how">How it works</a>
          {user ? <Link className="btn-primary" to="/dashboard">Open dashboard</Link> : <><Link className="btn-ghost" to="/login">Sign in</Link><Link className="btn-primary" to="/register">Get started</Link></>}
        </nav>
      </header>

      <section className="mx-auto grid max-w-6xl items-center gap-10 px-4 pb-16 pt-8 lg:grid-cols-[1.1fr_1fr] lg:pt-16">
        <div>
          <h1 className="text-4xl font-extrabold leading-[1.08] tracking-tight sm:text-5xl lg:text-6xl">Split bills. Share fairly. Stay friends.</h1>
          <p className="mt-5 max-w-lg text-lg text-ink-soft">SplitEase keeps one honest record of who paid, who owes, and what is left to settle, for trips, flats and every dinner in between.</p>
          <div className="mt-8 flex flex-wrap gap-3"><Link to="/register" className="btn-primary !px-6 !py-3 text-base">Get started</Link><a href="#features" className="btn-ghost !px-6 !py-3 text-base">Explore features</a></div>
        </div>
        <figure aria-label="Example: dinner for three" className="relative mx-auto w-full max-w-sm rotate-1 bg-white p-6 shadow-card [clip-path:polygon(0_0,100%_0,100%_calc(100%-10px),95%_100%,90%_calc(100%-10px),85%_100%,80%_calc(100%-10px),75%_100%,70%_calc(100%-10px),65%_100%,60%_calc(100%-10px),55%_100%,50%_calc(100%-10px),45%_100%,40%_calc(100%-10px),35%_100%,30%_calc(100%-10px),25%_100%,20%_calc(100%-10px),15%_100%,10%_calc(100%-10px),5%_100%,0_calc(100%-10px))]">
          <figcaption className="flex items-baseline justify-between border-b border-dashed border-slate-300 pb-3"><span className="font-bold">Dinner</span><span className="text-xl font-extrabold tabular-nums">₹900.00</span></figcaption>
          <p className="py-3 text-sm text-ink-soft">Alice paid. Split equally between three.</p>
          <ul className="space-y-2 text-sm">{[['Alice', '₹300.00', '+₹600.00', 'text-mint-700'], ['Bob', '₹300.00', '−₹300.00', 'text-rose-600'], ['Charlie', '₹300.00', '−₹300.00', 'text-rose-600']].map(([n, s, net, c]) => (
            <li key={n} className="flex items-center justify-between"><span className="font-semibold">{n}</span><span className="text-ink-soft tabular-nums">share {s}</span><span className={`w-24 text-right font-bold tabular-nums ${c}`}>{net}</span></li>))}</ul>
          <p className="mt-4 border-t border-dashed border-slate-300 pt-3 text-sm">Bob and Charlie each pay Alice <b>₹300.00</b>.</p>
          <p className="mt-2 text-xs text-ink-mute">Illustrative example</p>
        </figure>
      </section>

      <section id="features" className="mx-auto max-w-6xl px-4 py-14">
        <h2 className="max-w-xl text-3xl font-extrabold tracking-tight">Everything a shared wallet needs, nothing it doesn’t</h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{FEATURES.map(({ icon: I, t, d }) => (
          <div key={t} className="card p-5"><I className="mb-3 h-6 w-6 text-mint-600" aria-hidden /><h3 className="font-bold">{t}</h3><p className="mt-1 text-sm text-ink-soft">{d}</p></div>))}</div>
      </section>

      <section id="how" className="bg-ink py-14 text-white">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="text-3xl font-extrabold tracking-tight">How splitting works</h2>
          <ol className="mt-8 grid gap-6 md:grid-cols-3">
            <li><h3 className="font-bold text-mint-500">Log the expense</h3><p className="mt-1 text-sm text-slate-300">Pick who paid, who shared it and how to split. Shares always add up exactly to the total.</p></li>
            <li><h3 className="font-bold text-mint-500">Balances update</h3><p className="mt-1 text-sm text-slate-300">Net balance is what a person paid minus what they owe. Positive means they should receive money.</p></li>
            <li><h3 className="font-bold text-mint-500">Settle once</h3><p className="mt-1 text-sm text-slate-300">Pay however you like, then record it. The receiver confirms, and only then do balances change.</p></li>
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14">
        <h2 className="text-3xl font-extrabold tracking-tight">Honest about money</h2>
        <ul className="mt-6 grid gap-4 text-sm text-ink-soft md:grid-cols-3">
          <li className="card p-5"><b className="block text-ink">We never move money</b>Suggested payments are suggestions. A settlement only counts once the receiver confirms it.</li>
          <li className="card p-5"><b className="block text-ink">Your groups stay yours</b>Access is checked on every request, so guessing a link shows nothing.</li>
          <li className="card p-5"><b className="block text-ink">Currencies stay consistent</b>A group keeps its currency, so past expenses are never silently rewritten.</li>
        </ul>
        <div className="mt-10"><Link to="/register" className="btn-primary !px-6 !py-3 text-base">Create your free account</Link></div>
      </section>

      <footer className="border-t border-slate-200 bg-white">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-4 py-8 text-sm text-ink-soft">
          <Logo />
          <nav aria-label="Footer" className="flex gap-4"><a href="#features">Features</a><a href="#how">How it works</a><Link to="/login">Sign in</Link><Link to="/register">Register</Link></nav>
          <p>Contact: <a className="font-semibold text-ink" href="mailto:hello@splitease.example">hello@splitease.example</a></p>
        </div>
      </footer>
    </div>
  )
}
