import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { api, errMsg, fieldErrs } from '../lib/api'
import { useAuth } from '../lib/auth'
import { Logo } from '../components/Logo'
import { Spinner, TextInput } from '../components/ui'
import { User } from '../lib/types'

export const registerSchema = z.object({
  fullName: z.string().trim().min(1, 'Enter your full name').max(100),
  email: z.string().trim().email('Enter a valid email address'),
  password: z.string().min(8, 'Use at least 8 characters').regex(/[A-Za-z]/, 'Include a letter').regex(/\d/, 'Include a number'),
  confirmPassword: z.string(),
}).refine((d) => d.password === d.confirmPassword, { path: ['confirmPassword'], message: 'Passwords do not match' })

export const loginSchema = z.object({ email: z.string().trim().email('Enter a valid email address'), password: z.string().min(1, 'Enter your password') })

function AuthFrame({ title, sub, children, foot }: { title: string; sub: string; children: React.ReactNode; foot: React.ReactNode }) {
  return (
    <div className="grid min-h-screen place-items-center px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-6 flex justify-center"><Logo /></div>
        <div className="card p-6 sm:p-8">
          <h1 className="text-2xl font-extrabold tracking-tight">{title}</h1><p className="mb-6 mt-1 text-sm text-ink-soft">{sub}</p>
          {children}
        </div>
        <p className="mt-5 text-center text-sm text-ink-soft">{foot}</p>
      </div>
    </div>
  )
}

export function Login() {
  const { setUser } = useAuth(); const nav = useNavigate(); const [err, setErr] = useState('')
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<z.infer<typeof loginSchema>>({ resolver: zodResolver(loginSchema) })
  const submit = handleSubmit(async (v) => {
    setErr('')
    try { const r = await api.post<{ user: User }>('/auth/login', v); setUser(r.data.user); nav('/dashboard') }
    catch (e) { setErr(errMsg(e)) }
  })
  return (
    <AuthFrame title="Welcome back" sub="Sign in to see who owes what." foot={<>New here? <Link className="font-bold text-mint-700" to="/register">Create an account</Link></>}>
      <form onSubmit={submit} className="space-y-4" noValidate>
        {err && <p role="alert" className="rounded-xl bg-rose-50 p-3 text-sm font-medium text-rose-700">{err}</p>}
        <TextInput label="Email" type="email" autoComplete="email" error={errors.email?.message} {...register('email')} />
        <TextInput label="Password" type="password" autoComplete="current-password" error={errors.password?.message} {...register('password')} />
        <button className="btn-primary w-full" disabled={isSubmitting}>{isSubmitting && <Spinner />}Sign in</button>
      </form>
    </AuthFrame>
  )
}

export function Register() {
  const { setUser } = useAuth(); const nav = useNavigate(); const [err, setErr] = useState('')
  const { register, handleSubmit, setError, formState: { errors, isSubmitting } } = useForm<z.infer<typeof registerSchema>>({ resolver: zodResolver(registerSchema) })
  const submit = handleSubmit(async (v) => {
    setErr('')
    try { const r = await api.post<{ user: User }>('/auth/register', v); setUser(r.data.user); nav('/onboarding') }
    catch (e) {
      const fe = fieldErrs(e)
      Object.entries(fe).forEach(([k, m]) => setError(k as keyof typeof v, { message: m }))
      const msg = errMsg(e)
      if (msg.includes('email already exists')) setError('email', { message: msg }); else if (!Object.keys(fe).length) setErr(msg)
    }
  })
  return (
    <AuthFrame title="Create your account" sub="Free for friends, roommates and trips." foot={<>Already have an account? <Link className="font-bold text-mint-700" to="/login">Sign in</Link></>}>
      <form onSubmit={submit} className="space-y-4" noValidate>
        {err && <p role="alert" className="rounded-xl bg-rose-50 p-3 text-sm font-medium text-rose-700">{err}</p>}
        <TextInput label="Full name" autoComplete="name" error={errors.fullName?.message} {...register('fullName')} />
        <TextInput label="Email" type="email" autoComplete="email" error={errors.email?.message} {...register('email')} />
        <TextInput label="Password" type="password" autoComplete="new-password" error={errors.password?.message} {...register('password')} />
        <TextInput label="Confirm password" type="password" autoComplete="new-password" error={errors.confirmPassword?.message} {...register('confirmPassword')} />
        <button className="btn-primary w-full" disabled={isSubmitting}>{isSubmitting && <Spinner />}Create account</button>
      </form>
    </AuthFrame>
  )
}
