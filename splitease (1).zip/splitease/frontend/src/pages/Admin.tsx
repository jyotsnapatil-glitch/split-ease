import { useState } from 'react'
import { api, errMsg } from '../lib/api'
import { useFetch } from '../lib/useFetch'
import { Page } from '../lib/types'
import { Badge, ConfirmDialog, ErrorState, PageHeader, Skeleton } from '../components/ui'
import { shortDate } from '../lib/format'
import { useToast } from '../components/Toast'

interface AdminUser { id: number; fullName: string; email: string; role: string; status: string; createdAt: string }

export default function Admin() {
  const [page, setPage] = useState(0); const toast = useToast()
  const stats = useFetch<Record<string, number>>('/admin/stats'); const users = useFetch<Page<AdminUser>>(`/admin/users?page=${page}&size=15`)
  const [target, setTarget] = useState<AdminUser | null>(null); const [busy, setBusy] = useState(false)
  const toggle = async () => {
    if (!target) return; setBusy(true)
    try { await api.put(`/admin/users/${target.id}/status`, { status: target.status === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE' }); toast.push('Account updated'); setTarget(null); users.reload(); stats.reload() }
    catch (e) { toast.push(errMsg(e), 'error'); setTarget(null) } finally { setBusy(false) }
  }
  const cards: [string, string][] = [['users', 'Users'], ['activeUsers', 'Active'], ['suspendedUsers', 'Suspended'], ['groups', 'Groups'], ['activeExpenses', 'Expenses'], ['settlements', 'Settlements']]
  return (<>
    <PageHeader title="Admin" subtitle="Application statistics and account status." />
    {stats.error ? <ErrorState message={stats.error} onRetry={stats.reload} /> : <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-6">{cards.map(([k, l]) => <div key={k} className="card p-4"><p className="text-xs font-semibold text-ink-soft">{l}</p><p className="text-2xl font-extrabold">{stats.data?.[k] ?? '…'}</p></div>)}</div>}
    {users.loading ? <Skeleton className="h-48" /> : users.error || !users.data ? <ErrorState message={users.error} onRetry={users.reload} /> : (
      <div className="card overflow-x-auto"><table className="w-full min-w-[36rem] text-sm"><thead className="text-left text-xs text-ink-soft"><tr><th className="p-3">User</th><th className="p-3">Role</th><th className="p-3">Status</th><th className="p-3">Joined</th><th className="p-3" /></tr></thead>
        <tbody className="divide-y divide-slate-100">{users.data.items.map((u) => (
          <tr key={u.id}><td className="p-3"><p className="font-semibold">{u.fullName}</p><p className="text-xs text-ink-soft">{u.email}</p></td><td className="p-3">{u.role}</td><td className="p-3"><Badge tone={u.status === 'ACTIVE' ? 'green' : 'red'}>{u.status === 'ACTIVE' ? 'Active' : 'Suspended'}</Badge></td><td className="p-3">{shortDate(u.createdAt.slice(0, 10))}</td>
            <td className="p-3 text-right">{u.role !== 'ADMIN' && <button className="btn-ghost !py-1.5" onClick={() => setTarget(u)}>{u.status === 'ACTIVE' ? 'Suspend' : 'Reactivate'}</button>}</td></tr>))}</tbody></table>
        {users.data.totalPages > 1 && <div className="flex items-center justify-center gap-3 border-t border-slate-100 p-3"><button className="btn-ghost" disabled={page === 0} onClick={() => setPage(page - 1)}>Previous</button><span className="text-sm text-ink-soft">Page {page + 1} of {users.data.totalPages}</span><button className="btn-ghost" disabled={page + 1 >= users.data.totalPages} onClick={() => setPage(page + 1)}>Next</button></div>}</div>)}
    <ConfirmDialog open={!!target} title={target?.status === 'ACTIVE' ? 'Suspend this account?' : 'Reactivate this account?'} body={target?.status === 'ACTIVE' ? `${target?.fullName} will be signed out and unable to log in until reactivated.` : `${target?.fullName} will be able to sign in again.`} confirmLabel={target?.status === 'ACTIVE' ? 'Suspend' : 'Reactivate'} danger={target?.status === 'ACTIVE'} busy={busy} onConfirm={toggle} onClose={() => setTarget(null)} />
  </>)
}
