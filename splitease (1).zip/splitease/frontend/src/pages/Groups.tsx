import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { Plus, UserPlus, LogOut, Pencil, Trash2, Receipt } from 'lucide-react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { api, errMsg } from '../lib/api'
import { useFetch } from '../lib/useFetch'
import { useAuth } from '../lib/auth'
import { CURRENCIES, Expense, GROUP_CATEGORIES, GroupBalances, GroupDetail, GroupSummary, Page, Settlement } from '../lib/types'
import { Amount, Badge, ConfirmDialog, EmptyState, ErrorState, Modal, PageHeader, Select, Skeleton, Spinner, Tabs, TextInput } from '../components/ui'
import { label, money, shortDate } from '../lib/format'
import ExpenseModal from '../components/ExpenseModal'
import SettleModal, { Preset } from '../components/SettleModal'
import { useToast } from '../components/Toast'

const groupSchema = z.object({
  name: z.string().trim().min(1, 'Name your group').max(100), description: z.string().max(500).optional(),
  category: z.string().min(1), currency: z.string().min(1), memberEmails: z.string().optional(),
})

export function Groups() {
  const { data, loading, error, reload } = useFetch<GroupSummary[]>('/groups')
  const [params, setParams] = useSearchParams(); const nav = useNavigate(); const [err, setErr] = useState('')
  const open = params.get('new') === '1'
  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm<z.infer<typeof groupSchema>>({ resolver: zodResolver(groupSchema), defaultValues: { category: 'TRIP', currency: 'INR' } })
  const { user } = useAuth()
  useEffect(() => { if (open) reset({ name: '', description: '', category: 'TRIP', currency: user?.preferredCurrency ?? 'INR', memberEmails: '' }) }, [open, reset, user])
  const close = () => { setErr(''); setParams({}) }
  const create = handleSubmit(async (v) => {
    setErr('')
    const emails = (v.memberEmails ?? '').split(/[,\s]+/).filter(Boolean)
    try { const r = await api.post<GroupDetail>('/groups', { ...v, memberEmails: emails }); close(); nav(`/groups/${r.data.id}`) } catch (e) { setErr(errMsg(e)) }
  })
  return (
    <>
      <PageHeader title="My groups" subtitle="Every group keeps its own currency and balances." action={<button className="btn-primary" onClick={() => setParams({ new: '1' })}><Plus className="h-4 w-4" />New group</button>} />
      {loading ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-32" />)}</div>
        : error ? <ErrorState message={error} onRetry={reload} />
        : !data?.length ? <EmptyState title="No groups yet" body="Create a group for your trip, flat or class project, then add members who already have a SplitEase account." action={<button className="btn-primary mt-2" onClick={() => setParams({ new: '1' })}>Create a group</button>} />
        : <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{data.map((g) => (
          <Link key={g.id} to={`/groups/${g.id}`} className="card p-5 hover:border-mint-600"><div className="flex items-start justify-between"><h2 className="font-bold">{g.name}</h2><Badge tone="slate">{label(g.category)}</Badge></div>
            <p className="mt-1 line-clamp-2 min-h-[2.5rem] text-sm text-ink-soft">{g.description || `${g.memberCount} members · ${g.currency}`}</p>
            <div className="mt-3 flex items-center justify-between text-sm"><span className="text-ink-soft">Your balance</span><Amount value={g.myBalance} currency={g.currency} signed /></div></Link>))}</div>}
      <Modal open={open} onClose={close} title="Create group">
        <form onSubmit={create} className="space-y-4" noValidate>
          {err && <p role="alert" className="rounded-xl bg-rose-50 p-3 text-sm font-medium text-rose-700">{err}</p>}
          <TextInput label="Group name" error={errors.name?.message} {...register('name')} />
          <TextInput label="Description (optional)" {...register('description')} />
          <div className="grid grid-cols-2 gap-3">
            <Select label="Category" {...register('category')}>{GROUP_CATEGORIES.map((c) => <option key={c} value={c}>{label(c)}</option>)}</Select>
            <Select label="Currency" {...register('currency')}>{CURRENCIES.map((c) => <option key={c}>{c}</option>)}</Select>
          </div>
          <TextInput label="Member emails (optional)" placeholder="bob@example.com, charlie@example.com" {...register('memberEmails')} />
          <p className="-mt-2 text-xs text-ink-soft">Members must already have a SplitEase account. The group currency can’t be changed later.</p>
          <div className="flex justify-end gap-2"><button type="button" className="btn-ghost" onClick={close}>Cancel</button><button className="btn-primary" disabled={isSubmitting}>{isSubmitting && <Spinner />}Create group</button></div>
        </form>
      </Modal>
    </>
  )
}

type Tab = 'expenses' | 'balances' | 'settlements' | 'members'

export function GroupDetailPage() {
  const id = Number(useParams().id); const { user } = useAuth(); const nav = useNavigate(); const toast = useToast()
  const [params, setParams] = useSearchParams()
  const [tab, setTab] = useState<Tab>('expenses'); const [rev, setRev] = useState(0); const [page, setPage] = useState(0)
  const g = useFetch<GroupDetail>(`/groups/${id}`, [rev])
  const ex = useFetch<Page<Expense>>(`/groups/${id}/expenses?page=${page}&size=10`, [rev])
  const bal = useFetch<GroupBalances>(`/groups/${id}/balances`, [rev])
  const st = useFetch<Settlement[]>(`/groups/${id}/settlements`, [rev])
  const [editing, setEditing] = useState<Expense | null>(null); const [expOpen, setExpOpen] = useState(false)
  const [deleting, setDeleting] = useState<Expense | null>(null); const [busy, setBusy] = useState(false)
  const [settleOpen, setSettleOpen] = useState(false); const [preset, setPreset] = useState<Preset | null>(null)
  const [memberOpen, setMemberOpen] = useState(false); const [email, setEmail] = useState(''); const [memErr, setMemErr] = useState('')
  const [leaveOpen, setLeaveOpen] = useState(false); const [editOpen, setEditOpen] = useState(false); const [eName, setEName] = useState(''); const [eDesc, setEDesc] = useState(''); const [eCat, setECat] = useState('OTHER')
  const refresh = () => setRev((r) => r + 1)

  useEffect(() => { if (params.get('add') === '1' && g.data) { setEditing(null); setExpOpen(true); setParams({}, { replace: true }) } }, [params, g.data, setParams])

  if (g.loading && !g.data) return <div className="space-y-3"><Skeleton className="h-10 w-64" /><Skeleton className="h-64" /></div>
  if (g.error || !g.data) return <ErrorState message={g.error === 'Group not found' ? 'This group does not exist or you are not a member.' : g.error || 'Could not load group'} onRetry={g.reload} />
  const group = g.data; const me = user!.id; const isAdmin = group.myRole !== 'MEMBER'
  const myNet = group.members.find((m) => m.userId === me)?.balance ?? 0

  const doDelete = async () => { if (!deleting) return; setBusy(true); try { await api.delete(`/expenses/${deleting.id}`); toast.push('Expense deleted'); setDeleting(null); refresh() } catch (e) { toast.push(errMsg(e), 'error') } finally { setBusy(false) } }
  const addMember = async (e: React.FormEvent) => { e.preventDefault(); setMemErr(''); setBusy(true); try { await api.post(`/groups/${id}/members`, { email }); toast.push('Member added'); setMemberOpen(false); setEmail(''); refresh() } catch (er) { setMemErr(errMsg(er)) } finally { setBusy(false) } }
  const leave = async () => { setBusy(true); try { await api.post(`/groups/${id}/leave`); toast.push('You left the group'); nav('/groups') } catch (e) { toast.push(errMsg(e), 'error'); setLeaveOpen(false) } finally { setBusy(false) } }
  const saveEdit = async (e: React.FormEvent) => { e.preventDefault(); setBusy(true); try { await api.put(`/groups/${id}`, { name: eName, description: eDesc, category: eCat }); toast.push('Group updated'); setEditOpen(false); refresh() } catch (er) { toast.push(errMsg(er), 'error') } finally { setBusy(false) } }
  const act = async (sid: number, what: 'confirm' | 'reject') => { try { await api.post(`/settlements/${sid}/${what}`); toast.push(what === 'confirm' ? 'Settlement confirmed' : 'Settlement rejected'); refresh() } catch (e) { toast.push(errMsg(e), 'error'); refresh() } }

  return (
    <>
      <PageHeader title={group.name} subtitle={`${label(group.category)} · ${group.currency} · ${group.members.length} members${group.description ? ` · ${group.description}` : ''}`} action={
        <div className="flex flex-wrap gap-2">
          {isAdmin && <button className="btn-ghost" onClick={() => { setEName(group.name); setEDesc(group.description ?? ''); setECat(group.category); setEditOpen(true) }}><Pencil className="h-4 w-4" />Edit</button>}
          <button className="btn-ghost" onClick={() => setLeaveOpen(true)}><LogOut className="h-4 w-4" />Leave</button>
          <button className="btn-primary" onClick={() => { setEditing(null); setExpOpen(true) }}><Plus className="h-4 w-4" />Add expense</button>
        </div>} />
      <div className="card mb-5 flex flex-wrap items-center justify-between gap-3 p-4"><span className="text-sm font-semibold text-ink-soft">Your balance in this group</span><span className="text-xl"><Amount value={myNet} currency={group.currency} signed /></span></div>
      <Tabs value={tab} onChange={setTab} tabs={[{ id: 'expenses', label: 'Expenses' }, { id: 'balances', label: 'Balances' }, { id: 'settlements', label: 'Settlements' }, { id: 'members', label: 'Members' }]} />

      {tab === 'expenses' && (ex.loading && !ex.data ? <Skeleton className="h-40" /> : ex.error ? <ErrorState message={ex.error} onRetry={ex.reload} /> : !ex.data?.items.length ?
        <EmptyState title="No expenses yet" body="Add the first expense and choose how to split it." action={<button className="btn-primary mt-2" onClick={() => setExpOpen(true)}>Add expense</button>} /> : (
        <div className="space-y-3">
          {ex.data.items.map((e) => (
            <article key={e.id} className="card p-4">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div><h3 className="font-bold">{e.title}</h3><p className="text-xs text-ink-soft">{label(e.category)} · {shortDate(e.date)} · {e.paidByName} paid · split {label(e.splitMethod).toLowerCase()}</p></div>
                <div className="flex items-center gap-2"><span className="text-lg"><Amount value={e.amount} currency={e.currency} /></span>
                  {e.canEdit && <><button aria-label={`Edit ${e.title}`} className="btn-ghost !p-2" onClick={() => { setEditing(e); setExpOpen(true) }}><Pencil className="h-4 w-4" /></button>
                    <button aria-label={`Delete ${e.title}`} className="btn-ghost !p-2 text-rose-600" onClick={() => setDeleting(e)}><Trash2 className="h-4 w-4" /></button></>}</div>
              </div>
              <ul className="mt-3 grid gap-1 text-sm sm:grid-cols-2">
                {e.participants.map((p) => <li key={p.userId} className="flex justify-between rounded-lg bg-slate-50 px-3 py-1.5"><span>{p.fullName}</span><span className="font-semibold tabular-nums">{money(p.share, e.currency)}</span></li>)}
              </ul>
              {e.owes.length > 0 && <p className="mt-2 text-xs text-ink-soft">{e.owes.map((o) => `${o.fromName} owes ${o.toName} ${money(o.amount, e.currency)}`).join(' · ')}</p>}
            </article>))}
          {ex.data.totalPages > 1 && <div className="flex items-center justify-center gap-3 pt-2"><button className="btn-ghost" disabled={page === 0} onClick={() => setPage(page - 1)}>Previous</button><span className="text-sm text-ink-soft">Page {page + 1} of {ex.data.totalPages}</span><button className="btn-ghost" disabled={page + 1 >= ex.data.totalPages} onClick={() => setPage(page + 1)}>Next</button></div>}
        </div>))}

      {tab === 'balances' && (bal.loading && !bal.data ? <Skeleton className="h-40" /> : bal.error || !bal.data ? <ErrorState message={bal.error} onRetry={bal.reload} /> : (
        <div className="grid gap-4 lg:grid-cols-2">
          <section className="card p-5"><h2 className="mb-3 font-bold">Net balances</h2><ul className="divide-y divide-slate-100">{bal.data.members.map((m) => <li key={m.userId} className="flex justify-between py-2.5"><span className="font-medium">{m.fullName}{m.userId === me && ' (you)'}</span><Amount value={m.net} currency={bal.data!.currency} signed /></li>)}</ul>
            <p className="mt-3 text-xs text-ink-soft">Positive means they should receive money. Negative means they owe money. Only confirmed settlements are counted.</p></section>
          <section className="card p-5"><h2 className="mb-1 font-bold">Suggested payments</h2><p className="mb-3 text-xs text-ink-soft">The fewest transfers that settle everyone. These are suggestions, not payments.</p>
            {bal.data.suggestions.length === 0 ? <p className="text-sm text-ink-soft">Everyone is settled up.</p> : <ul className="space-y-2">{bal.data.suggestions.map((s, i) => (
              <li key={i} className="flex items-center justify-between gap-2 rounded-xl bg-slate-50 px-3 py-2 text-sm"><span><b>{s.fromName}</b> pays <b>{s.toName}</b> {money(s.amount, bal.data!.currency)}</span>
                {(s.fromUserId === me || s.toUserId === me) && <button className="btn-ghost !py-1.5" onClick={() => { setPreset({ payerId: s.fromUserId, receiverId: s.toUserId, amount: s.amount }); setSettleOpen(true) }}>Record</button>}</li>))}</ul>}</section>
        </div>))}

      {tab === 'settlements' && (<div className="space-y-3">
        <div className="flex justify-end"><button className="btn-primary" onClick={() => { setPreset(null); setSettleOpen(true) }}><Receipt className="h-4 w-4" />Record settlement</button></div>
        {st.loading && !st.data ? <Skeleton className="h-32" /> : !st.data?.length ? <EmptyState title="No settlements yet" body="When someone pays someone back outside the app, record it here." /> :
          st.data.map((s) => <SettlementRow key={s.id} s={s} onAct={act} />)}</div>)}

      {tab === 'members' && (<section className="card p-5">
        <div className="mb-3 flex items-center justify-between"><h2 className="font-bold">Members</h2>{isAdmin && <button className="btn-ghost" onClick={() => setMemberOpen(true)}><UserPlus className="h-4 w-4" />Add member</button>}</div>
        <ul className="divide-y divide-slate-100">{group.members.map((m) => <li key={m.userId} className="flex flex-wrap items-center justify-between gap-2 py-2.5"><div><p className="font-semibold">{m.fullName}{m.userId === me && ' (you)'}</p><p className="text-xs text-ink-soft">{m.email}</p></div><div className="flex items-center gap-3">{m.role !== 'MEMBER' && <Badge tone="green">{label(m.role)}</Badge>}<Amount value={m.balance} currency={group.currency} signed /></div></li>)}</ul></section>)}

      <ExpenseModal open={expOpen} groupId={id} members={group.members} currency={group.currency} initial={editing} onClose={() => setExpOpen(false)} onSaved={refresh} />
      <SettleModal open={settleOpen} groupId={id} currency={group.currency} me={me} people={group.members} preset={preset} onClose={() => setSettleOpen(false)} onSaved={refresh} />
      <ConfirmDialog open={!!deleting} title="Delete this expense?" body={`“${deleting?.title}” will be removed and balances will be recalculated. The deletion stays in the activity log.`} confirmLabel="Delete expense" danger busy={busy} onConfirm={doDelete} onClose={() => setDeleting(null)} />
      <ConfirmDialog open={leaveOpen} title="Leave this group?" body="You can only leave when your confirmed balance is zero. An admin can add you back later." confirmLabel="Leave group" danger busy={busy} onConfirm={leave} onClose={() => setLeaveOpen(false)} />
      <Modal open={memberOpen} onClose={() => setMemberOpen(false)} title="Add a member">
        <form onSubmit={addMember} className="space-y-4"><p className="text-sm text-ink-soft">They need an existing SplitEase account. They are added right away and will see the group on their dashboard.</p>
          {memErr && <p role="alert" className="rounded-xl bg-rose-50 p-3 text-sm font-medium text-rose-700">{memErr}</p>}
          <TextInput label="Email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          <div className="flex justify-end gap-2"><button type="button" className="btn-ghost" onClick={() => setMemberOpen(false)}>Cancel</button><button className="btn-primary" disabled={busy}>{busy && <Spinner />}Add member</button></div></form>
      </Modal>
      <Modal open={editOpen} onClose={() => setEditOpen(false)} title="Edit group">
        <form onSubmit={saveEdit} className="space-y-4"><TextInput label="Name" required value={eName} onChange={(e) => setEName(e.target.value)} /><TextInput label="Description" value={eDesc} onChange={(e) => setEDesc(e.target.value)} />
          <Select label="Category" value={eCat} onChange={(e) => setECat(e.target.value)}>{GROUP_CATEGORIES.map((c) => <option key={c} value={c}>{label(c)}</option>)}</Select>
          <p className="text-xs text-ink-soft">Currency ({group.currency}) is fixed so existing amounts stay consistent.</p>
          <div className="flex justify-end gap-2"><button type="button" className="btn-ghost" onClick={() => setEditOpen(false)}>Cancel</button><button className="btn-primary" disabled={busy}>Save changes</button></div></form>
      </Modal>
    </>
  )
}

export function SettlementRow({ s, onAct }: { s: Settlement; onAct: (id: number, w: 'confirm' | 'reject') => void }) {
  const tone = s.status === 'CONFIRMED' ? 'green' : s.status === 'PENDING' ? 'amber' : 'red'
  return (
    <article className="card flex flex-wrap items-center justify-between gap-3 p-4">
      <div><p className="font-semibold">{s.payerName} paid {s.receiverName}</p><p className="text-xs text-ink-soft">{s.groupName} · {label(s.method)} · {shortDate(s.date)}</p></div>
      <div className="flex flex-wrap items-center gap-2"><span className="text-lg"><Amount value={s.amount} currency={s.currency} /></span><Badge tone={tone}>{label(s.status)}</Badge>
        {s.canConfirm && <button className="btn-primary !py-1.5" onClick={() => onAct(s.id, 'confirm')}>Confirm received</button>}
        {s.canReject && <button className="btn-ghost !py-1.5" onClick={() => onAct(s.id, 'reject')}>Reject</button>}</div>
    </article>
  )
}
