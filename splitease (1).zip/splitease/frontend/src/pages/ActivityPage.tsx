import { useState } from 'react'
import { useFetch } from '../lib/useFetch'
import { Activity, Page } from '../lib/types'
import { EmptyState, ErrorState, PageHeader, Skeleton } from '../components/ui'

export default function ActivityPage() {
  const [page, setPage] = useState(0)
  const { data, loading, error, reload } = useFetch<Page<Activity>>(`/activity?page=${page}&size=15`)
  return (<>
    <PageHeader title="Activity" subtitle="An audit trail of important financial actions in your groups." />
    {loading ? <Skeleton className="h-64" /> : error ? <ErrorState message={error} onRetry={reload} /> : !data?.items.length ? <EmptyState title="No activity yet" body="Creating groups, adding expenses and recording settlements will show up here." /> : (
      <div className="card divide-y divide-slate-100">{data.items.map((a) => (
        <div key={a.id} className="flex items-start justify-between gap-3 p-4"><div><p className="text-sm"><b>{a.actorName}</b> · {a.summary}</p></div><time className="shrink-0 text-xs text-ink-soft" dateTime={a.createdAt}>{new Date(a.createdAt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}</time></div>))}
        {data.totalPages > 1 && <div className="flex items-center justify-center gap-3 p-3"><button className="btn-ghost" disabled={page === 0} onClick={() => setPage(page - 1)}>Previous</button><span className="text-sm text-ink-soft">Page {page + 1} of {data.totalPages}</span><button className="btn-ghost" disabled={page + 1 >= data.totalPages} onClick={() => setPage(page + 1)}>Next</button></div>}
      </div>)}
  </>)
}
