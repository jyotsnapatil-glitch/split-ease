import { useState } from 'react'
import { Link } from 'react-router-dom'
import { api, errMsg } from '../lib/api'
import { useFetch } from '../lib/useFetch'
import { GroupBalances, GroupSummary, Settlement } from '../lib/types'
import { Amount, EmptyState, ErrorState, PageHeader, Skeleton } from '../components/ui'
import { money } from '../lib/format'
import { useToast } from '../components/Toast'
import { SettlementRow } from './Groups'

function GroupBalanceCard({ g }: { g: GroupSummary }) {
  const { data, loading, error, reload } = useFetch<GroupBalances>(`/groups/${g.id}/balances`)
  return (
    <section className="card p-5">
      <div className="mb-3 flex items-center justify-between"><h2 className="font-bold">{g.name}</h2><Link className="text-sm font-semibold text-mint-700" to={`/groups/${g.id}`}>Open group</Link></div>
      {loading ? <Skeleton className="h-24" /> : error || !data ? <ErrorState message={error} onRetry={reload} /> : (<>
        <ul className="divide-y divide-slate-100">{data.members.map((m) => <li key={m.userId} className="flex justify-between py-2 text-sm"><span>{m.fullName}</span><Amount value={m.net} currency={data.currency} signed /></li>)}</ul>
        <div className="mt-3 border-t border-slate-100 pt-3 text-sm">{data.suggestions.length === 0 ? <span className="text-ink-soft">Everyone is settled up.</span> : data.suggestions.map((s, i) => <p key={i}><b>{s.fromName}</b> pays <b>{s.toName}</b> {money(s.amount, data.currency)}</p>)}</div></>)}
    </section>
  )
}

export function Balances() {
  const { data, loading, error, reload } = useFetch<GroupSummary[]>('/groups')
  return (<>
    <PageHeader title="Balances" subtitle="Who owes whom in each group, using confirmed settlements only." />
    {loading ? <Skeleton className="h-48" /> : error ? <ErrorState message={error} onRetry={reload} /> : !data?.length ? <EmptyState title="No balances yet" body="Balances appear once you add expenses to a group." action={<Link to="/groups?new=1" className="btn-primary mt-2">Create a group</Link>} /> :
      <div className="grid gap-4 lg:grid-cols-2">{data.map((g) => <GroupBalanceCard key={g.id} g={g} />)}</div>}
  </>)
}

export function Settlements() {
  const { data, loading, error, reload } = useFetch<Settlement[]>('/settlements'); const toast = useToast(); const [filter, setFilter] = useState<'ALL' | 'PENDING' | 'CONFIRMED'>('ALL')
  const act = async (id: number, w: 'confirm' | 'reject') => { try { await api.post(`/settlements/${id}/${w}`); toast.push(w === 'confirm' ? 'Settlement confirmed. Balances updated' : 'Settlement rejected'); reload() } catch (e) { toast.push(errMsg(e), 'error'); reload() } }
  const list = (data ?? []).filter((s) => filter === 'ALL' || s.status === filter)
  const waiting = (data ?? []).filter((s) => s.canConfirm)
  return (<>
    <PageHeader title="Settlements" subtitle="Payments are made outside SplitEase. Here you record and confirm them." />
    {waiting.length > 0 && <p className="mb-4 rounded-xl bg-amber-50 p-3 text-sm font-semibold text-amber-800">{waiting.length} payment{waiting.length > 1 ? 's' : ''} waiting for your confirmation.</p>}
    <div className="mb-4 flex gap-2">{(['ALL', 'PENDING', 'CONFIRMED'] as const).map((f) => <button key={f} onClick={() => setFilter(f)} className={filter === f ? 'btn-dark' : 'btn-ghost'}>{f === 'ALL' ? 'All' : f === 'PENDING' ? 'Pending' : 'Confirmed'}</button>)}</div>
    {loading ? <Skeleton className="h-40" /> : error ? <ErrorState message={error} onRetry={reload} /> : !list.length ? <EmptyState title="No settlements" body="Open a group’s Balances tab and tap Record next to a suggested payment." /> :
      <div className="space-y-3">{list.map((s) => <SettlementRow key={s.id} s={s} onAct={act} />)}</div>}
  </>)
}
