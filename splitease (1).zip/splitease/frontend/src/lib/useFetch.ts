import { DependencyList, useCallback, useEffect, useState } from 'react'
import { api, errMsg } from './api'

/** Small data hook: loading / error / reload for GET endpoints. */
export function useFetch<T>(url: string | null, deps: DependencyList = []) {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const load = useCallback(() => {
    if (!url) return
    setLoading(true); setError('')
    api.get<T>(url).then((r) => setData(r.data)).catch((e) => setError(errMsg(e))).finally(() => setLoading(false))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url, ...deps])
  useEffect(load, [load])
  return { data, loading, error, reload: load }
}
