export function money(amount: number | undefined | null, currency = 'INR'): string {
  const n = Number(amount ?? 0)
  try { return new Intl.NumberFormat('en-IN', { style: 'currency', currency, maximumFractionDigits: 2 }).format(n) }
  catch { return `${currency} ${n.toFixed(2)}` }
}
export function shortDate(d: string): string {
  return new Date(d + (d.length === 10 ? 'T00:00:00' : '')).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
}
export function label(s: string): string { return s.charAt(0) + s.slice(1).toLowerCase().replace(/_/g, ' ') }
export function today(): string { return new Date().toISOString().slice(0, 10) }
/** Mirrors the server's deterministic remainder rule for the live preview only; the API is the source of truth. */
export function previewEqual(total: number, ids: number[]): Record<number, number> {
  const cents = Math.round(total * 100), sorted = [...ids].sort((a, b) => a - b), base = Math.floor(cents / (sorted.length || 1))
  let rem = cents - base * sorted.length
  const out: Record<number, number> = {}
  sorted.forEach((id) => { out[id] = (base + (rem-- > 0 ? 1 : 0)) / 100 })
  return out
}
