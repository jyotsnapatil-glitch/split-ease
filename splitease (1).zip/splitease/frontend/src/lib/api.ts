import axios, { AxiosError } from 'axios'

const base = (import.meta.env.VITE_API_URL as string | undefined) ?? ''

/** Cookie-based auth: the JWT lives in an HttpOnly cookie the browser sends automatically. X-Requested-With is the CSRF guard the API expects. */
export const api = axios.create({ baseURL: `${base}/api`, withCredentials: true, headers: { 'X-Requested-With': 'SplitEase' } })

api.interceptors.response.use(
  (r) => r,
  (err: AxiosError) => {
    const url = err.config?.url ?? ''
    if (err.response?.status === 401 && !url.startsWith('/auth/')) window.dispatchEvent(new Event('auth:expired'))
    return Promise.reject(err)
  },
)

export function errMsg(e: unknown, fallback = 'Something went wrong. Try again.'): string {
  const ax = e as AxiosError<{ message?: string }>
  if (ax.response?.data?.message) return ax.response.data.message
  if (ax.code === 'ERR_NETWORK') return 'Cannot reach the server. Check your connection and try again.'
  return fallback
}

export function fieldErrs(e: unknown): Record<string, string> {
  return ((e as AxiosError<{ fieldErrors?: Record<string, string> }>).response?.data?.fieldErrors) ?? {}
}
