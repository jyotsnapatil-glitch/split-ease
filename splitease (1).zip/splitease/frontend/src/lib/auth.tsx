import { createContext, useCallback, useContext, useEffect, useState, ReactNode } from 'react'
import { api } from './api'
import { User } from './types'
import { useToast } from '../components/Toast'

interface AuthCtx { user: User | null; loading: boolean; setUser: (u: User | null) => void; logout: () => Promise<void> }
const Ctx = createContext<AuthCtx>(null as unknown as AuthCtx)
export const useAuth = () => useContext(Ctx)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const toast = useToast()

  useEffect(() => {
    api.get<User>('/users/me').then((r) => setUser(r.data)).catch(() => setUser(null)).finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    const h = () => { setUser((u) => { if (u) toast.push('Your session expired. Sign in again.', 'error'); return null }) }
    window.addEventListener('auth:expired', h)
    return () => window.removeEventListener('auth:expired', h)
  }, [toast])

  const logout = useCallback(async () => { try { await api.post('/auth/logout') } finally { setUser(null) } }, [])
  return <Ctx.Provider value={{ user, loading, setUser, logout }}>{children}</Ctx.Provider>
}
