export type Role = 'USER' | 'ADMIN'
export interface User { id: number; fullName: string; email: string; role: Role; preferredCurrency: string; onboarded: boolean }
export type GroupCategory = 'TRIP' | 'HOME' | 'COLLEGE' | 'COUPLE' | 'OTHER'
export type ExpenseCategory = 'FOOD' | 'GROCERIES' | 'RENT' | 'TRAVEL' | 'TRANSPORT' | 'SHOPPING' | 'ENTERTAINMENT' | 'UTILITIES' | 'EDUCATION' | 'OTHER'
export type SplitMethod = 'EQUAL' | 'EXACT' | 'PERCENTAGE' | 'SHARES'
export type PayMethod = 'CASH' | 'BANK_TRANSFER' | 'UPI'
export type SettlementStatus = 'PENDING' | 'CONFIRMED' | 'REJECTED'

export interface Page<T> { items: T[]; page: number; size: number; totalItems: number; totalPages: number }
export interface GroupSummary { id: number; name: string; description?: string; category: GroupCategory; currency: string; memberCount: number; myBalance: number; createdAt: string }
export interface Member { userId: number; fullName: string; email: string; role: 'OWNER' | 'ADMIN' | 'MEMBER'; balance: number }
export interface GroupDetail { id: number; name: string; description?: string; category: GroupCategory; currency: string; myRole: string; members: Member[]; createdAt: string }
export interface ParticipantDto { userId: number; fullName: string; share: number; percentage?: number; shareUnits?: number }
export interface Owes { fromUserId: number; fromName: string; toUserId: number; toName: string; amount: number }
export interface Expense {
  id: number; groupId: number; groupName: string; title: string; description?: string; notes?: string; amount: number; currency: string
  paidBy: number; paidByName: string; category: ExpenseCategory; splitMethod: SplitMethod; date: string
  participants: ParticipantDto[]; owes: Owes[]; canEdit: boolean; createdAt: string
}
export interface Suggested { fromUserId: number; fromName: string; toUserId: number; toName: string; amount: number }
export interface GroupBalances { groupId: number; currency: string; members: { userId: number; fullName: string; net: number }[]; suggestions: Suggested[] }
export interface Settlement {
  id: number; groupId: number; groupName: string; currency: string; payerId: number; payerName: string; receiverId: number; receiverName: string
  amount: number; method: PayMethod; status: SettlementStatus; date: string; createdAt: string; confirmedAt?: string; canConfirm: boolean; canReject: boolean
}
export interface Txn { type: 'EXPENSE' | 'SETTLEMENT'; id: number; groupId: number; groupName: string; currency: string; title: string; category: string; amount: number; date: string; status: string; actorName: string; createdAt: string }
export interface Dashboard {
  currency: string; totalPaid: number; totalOwed: number; owedToMe: number; netBalance: number; otherCurrencyGroups: number
  recent: Txn[]; groups: GroupSummary[]; unsettled: { groupId: number; groupName: string; currency: string; net: number }[]
  pendingSettlements: Settlement[]; monthly: { month: string; amount: number }[]; categories: { category: string; amount: number }[]
}
export interface Activity { id: number; actorName: string; actionType: string; summary: string; createdAt: string; groupId?: number }

export const CATEGORIES: ExpenseCategory[] = ['FOOD', 'GROCERIES', 'RENT', 'TRAVEL', 'TRANSPORT', 'SHOPPING', 'ENTERTAINMENT', 'UTILITIES', 'EDUCATION', 'OTHER']
export const GROUP_CATEGORIES: GroupCategory[] = ['TRIP', 'HOME', 'COLLEGE', 'COUPLE', 'OTHER']
export const CURRENCIES = ['INR', 'USD', 'EUR', 'GBP', 'AED', 'SGD', 'AUD', 'CAD', 'JPY']
