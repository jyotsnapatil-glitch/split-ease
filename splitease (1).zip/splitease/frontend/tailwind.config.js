/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['Manrope', 'system-ui', 'Segoe UI', 'sans-serif'] },
      colors: {
        ink: { DEFAULT: '#0b1f3a', soft: '#3d5170', mute: '#6b7c93' },
        mint: { 50: '#ecfdf5', 100: '#d1fae5', 500: '#10b981', 600: '#059669', 700: '#047857' },
        paper: '#f6f9fb',
      },
      boxShadow: { card: '0 1px 2px rgba(11,31,58,.04), 0 4px 14px rgba(11,31,58,.05)' },
    },
  },
  plugins: [],
}
