# Deploying SplitEase

Nothing here has been deployed yet: it needs accounts and approvals only you can give. Total time is about 20-30 minutes.

## 0. Push to GitHub
```bash
cd splitease && git init && git add . && git commit -m "SplitEase" 
gh repo create splitease --public --source=. --push     # or create the repo in the browser and `git push`
```

## 1. Database (managed MySQL with persistent storage)
Render does not host MySQL. Pick one: **Aiven for MySQL** (free tier), **TiDB Cloud Serverless** (MySQL-compatible, free tier) or **AWS RDS MySQL**.
Create a database called `splitease` and note host, port, user and password. Your JDBC URL looks like:
`jdbc:mysql://HOST:PORT/splitease?sslMode=REQUIRED&serverTimezone=UTC`
Flyway creates every table automatically on first backend start (migration `V1__init_schema.sql`).

## 2. Backend on Render
1. Render → New → Blueprint → select the repo (it reads `render.yaml`). Or New → Web Service → Docker, root `backend`.
2. Set env vars: `DB_URL`, `DB_USERNAME`, `DB_PASSWORD`, `CORS_ALLOWED_ORIGINS` (fill after step 3), optional `ADMIN_EMAIL`/`ADMIN_PASSWORD` (12+ chars). `JWT_SECRET` is generated for you.
3. Deploy. Check `https://YOUR-API.onrender.com/actuator/health` returns `{"status":"UP"}` and Swagger loads at `/swagger-ui.html`.

## 3. Frontend on Vercel
1. Edit `frontend/vercel.json`: replace `YOUR-BACKEND.onrender.com` with your Render hostname. This rewrite proxies `/api/*` through Vercel, so the browser talks to one origin and the login cookie is first-party (works despite third-party-cookie blocking).
2. Vercel → Add New Project → import the repo, **Root Directory = `frontend`**, framework Vite. Leave `VITE_API_URL` empty.
3. Deploy, then set Render's `CORS_ALLOWED_ORIGINS=https://YOUR-APP.vercel.app` and redeploy the backend.

Alternative without the rewrite: set `VITE_API_URL=https://YOUR-API.onrender.com`, and on Render `COOKIE_SAMESITE=None`, `COOKIE_SECURE=true`. Some browsers block such third-party cookies, so the rewrite is preferred.

## 4. Smoke test (do this on the live URLs)
Register → onboarding → create group → add a member (they must be registered) → add expense → check balances → record settlement → confirm as receiver → balances change. Check the browser console and Render logs.

## Notes
- Render free web services sleep when idle: the first request can take ~50 s.
- Never enable `SPRING_PROFILES_ACTIVE=dev` in production (it seeds demo users and disables secure cookies).
- First admin: set `ADMIN_EMAIL` + `ADMIN_PASSWORD` once, deploy, log in, then remove the password variable.
